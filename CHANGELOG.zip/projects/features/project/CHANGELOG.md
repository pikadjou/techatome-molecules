# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [3.16.0-beta.4](https://dev.azure.com/compare/v3.16.0-beta.3...v3.16.0-beta.4) (2025-06-10)

**Note:** Version bump only for package @camelot/project





# [3.16.0-beta.3](https://dev.azure.com/compare/v3.16.0-beta.2...v3.16.0-beta.3) (2025-06-05)

**Note:** Version bump only for package @camelot/project





# [3.16.0-beta.2](https://dev.azure.com/compare/v3.16.0-beta.1...v3.16.0-beta.2) (2025-06-04)

**Note:** Version bump only for package @camelot/project





# [3.16.0-beta.1](https://dev.azure.com/compare/v3.16.0-beta.0...v3.16.0-beta.1) (2025-06-04)

**Note:** Version bump only for package @camelot/project





# [3.16.0-beta.0](https://dev.azure.com/compare/v3.15.1-beta.1...v3.16.0-beta.0) (2025-06-04)

**Note:** Version bump only for package @camelot/project





## [3.15.1-beta.1](https://dev.azure.com/compare/v3.15.1-beta.0...v3.15.1-beta.1) (2025-05-27)

**Note:** Version bump only for package @camelot/project





## [3.15.1-beta.0](https://dev.azure.com/compare/v3.15.0...v3.15.1-beta.0) (2025-05-26)

**Note:** Version bump only for package @camelot/project





# [3.15.0](https://dev.azure.com/compare/v3.15.0-beta.7...v3.15.0) (2025-05-22)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.7](https://dev.azure.com/compare/v3.15.0-beta.6...v3.15.0-beta.7) (2025-05-22)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.6](https://dev.azure.com/compare/v3.15.0-beta.5...v3.15.0-beta.6) (2025-05-22)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.5](https://dev.azure.com/compare/v3.15.0-beta.4...v3.15.0-beta.5) (2025-05-21)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.4](https://dev.azure.com/compare/v3.15.0-beta.3...v3.15.0-beta.4) (2025-05-21)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.3](https://dev.azure.com/compare/v3.15.0-beta.2...v3.15.0-beta.3) (2025-05-21)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.2](https://dev.azure.com/compare/v3.15.0-beta.1...v3.15.0-beta.2) (2025-05-21)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.1](https://dev.azure.com/compare/v3.15.0-beta.0...v3.15.0-beta.1) (2025-05-15)

**Note:** Version bump only for package @camelot/project





# [3.15.0-beta.0](https://dev.azure.com/compare/v3.14.0...v3.15.0-beta.0) (2025-05-07)

**Note:** Version bump only for package @camelot/project





# [3.14.0](https://dev.azure.com/compare/v3.14.0-beta.10...v3.14.0) (2025-05-06)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.10](https://dev.azure.com/compare/v3.14.0-beta.9...v3.14.0-beta.10) (2025-04-29)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.9](https://dev.azure.com/compare/v3.14.0-beta.8...v3.14.0-beta.9) (2025-04-28)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.8](https://dev.azure.com/compare/v3.14.0-beta.7...v3.14.0-beta.8) (2025-04-25)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.7](https://dev.azure.com/compare/v3.14.0-beta.6...v3.14.0-beta.7) (2025-04-25)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.6](https://dev.azure.com/compare/v3.14.0-beta.5...v3.14.0-beta.6) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.5](https://dev.azure.com/compare/v3.14.0-beta.4...v3.14.0-beta.5) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.4](https://dev.azure.com/compare/v3.14.0-beta.3...v3.14.0-beta.4) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.3](https://dev.azure.com/compare/v3.14.0-beta.2...v3.14.0-beta.3) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.2](https://dev.azure.com/compare/v3.14.0-beta.1...v3.14.0-beta.2) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.1](https://dev.azure.com/compare/v3.14.0-beta.0...v3.14.0-beta.1) (2025-04-24)

**Note:** Version bump only for package @camelot/project





# [3.14.0-beta.0](https://dev.azure.com/compare/v3.13.1-beta.2...v3.14.0-beta.0) (2025-04-17)

**Note:** Version bump only for package @camelot/project





## [3.13.1-beta.2](https://dev.azure.com/compare/v3.13.1-beta.1...v3.13.1-beta.2) (2025-04-16)

**Note:** Version bump only for package @camelot/project





## [3.13.1-beta.1](https://dev.azure.com/compare/v3.13.1-beta.0...v3.13.1-beta.1) (2025-04-16)

**Note:** Version bump only for package @camelot/project





## [3.13.1-beta.0](https://dev.azure.com/compare/v3.13.0...v3.13.1-beta.0) (2025-04-11)

**Note:** Version bump only for package @camelot/project





# [3.13.0](https://dev.azure.com/compare/v3.13.0-beta.5...v3.13.0) (2025-04-11)



## [3.12.4](https://dev.azure.com/compare/v3.12.3-beta.0...v3.12.4) (2025-04-08)



## [3.12.3](https://dev.azure.com/compare/v3.12.1...v3.12.3) (2025-04-04)

**Note:** Version bump only for package @camelot/project





# [3.13.0-beta.5](https://dev.azure.com/compare/v3.13.0-beta.4...v3.13.0-beta.5) (2025-04-11)

**Note:** Version bump only for package @camelot/project

# [3.13.0-beta.4](https://dev.azure.com/compare/v3.13.0-beta.3...v3.13.0-beta.4) (2025-04-11)

**Note:** Version bump only for package @camelot/project

# [3.13.0-beta.3](https://dev.azure.com/compare/v3.13.0-beta.2...v3.13.0-beta.3) (2025-04-11)

### Features

- ajout des services de maintenance et organization ([62d52bc](https://dev.azure.com/commits/62d52bcfec0ac35482122a7f81a0c3f491e53850))
- comments ([bf046a0](https://dev.azure.com/commits/bf046a0760ab2ef760df6360c7b88d589484016a))
- signals ([82afa8b](https://dev.azure.com/commits/82afa8b9dbc340ae586f3c92a567a63882a7e434))

# [3.13.0-beta.2](https://dev.azure.com/compare/v3.13.0-beta.1...v3.13.0-beta.2) (2025-04-11)

**Note:** Version bump only for package @camelot/project

# [3.13.0-beta.1](https://dev.azure.com/compare/v3.13.0-beta.0...v3.13.0-beta.1) (2025-04-11)

**Note:** Version bump only for package @camelot/project

# [3.13.0-beta.0](https://dev.azure.com/compare/v3.12.3-beta.0...v3.13.0-beta.0) (2025-04-09)

**Note:** Version bump only for package @camelot/project

## [3.12.3-beta.0](https://dev.azure.com/compare/v3.12.1...v3.12.3-beta.0) (2025-04-04)

## [3.12.1-beta.0](https://dev.azure.com/compare/v3.12.0...v3.12.1-beta.0) (2025-04-03)

**Note:** Version bump only for package @camelot/project

## [3.12.2](https://dev.azure.com/compare/v3.12.1...v3.12.2) (2025-04-04)

**Note:** Version bump only for package @camelot/project

## [3.12.1](https://dev.azure.com/compare/v3.12.0...v3.12.1) (2025-04-04)

**Note:** Version bump only for package @camelot/project

# [3.12.0](https://dev.azure.com/compare/v3.12.0-beta.3...v3.12.0) (2025-04-03)

**Note:** Version bump only for package @camelot/project

# [3.12.0-beta.3](https://dev.azure.com/compare/v3.12.0-beta.2...v3.12.0-beta.3) (2025-04-03)

**Note:** Version bump only for package @camelot/project

# [3.12.0-beta.2](https://dev.azure.com/compare/v3.12.0-beta.1...v3.12.0-beta.2) (2025-04-03)

**Note:** Version bump only for package @camelot/project

# [3.12.0-beta.1](https://dev.azure.com/compare/v3.12.0-beta.0...v3.12.0-beta.1) (2025-04-03)

**Note:** Version bump only for package @camelot/project

# [3.12.0-beta.0](https://dev.azure.com/compare/v3.11.1-beta.0...v3.12.0-beta.0) (2025-04-02)

**Note:** Version bump only for package @camelot/project

## [3.11.1-beta.0](https://dev.azure.com/compare/v3.11.0...v3.11.1-beta.0) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0](https://dev.azure.com/compare/v3.11.0-beta.8...v3.11.0) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.8](https://dev.azure.com/compare/v3.11.0-beta.7...v3.11.0-beta.8) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.7](https://dev.azure.com/compare/v3.11.0-beta.6...v3.11.0-beta.7) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.6](https://dev.azure.com/compare/v3.11.0-beta.5...v3.11.0-beta.6) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.5](https://dev.azure.com/compare/v3.11.0-beta.4...v3.11.0-beta.5) (2025-04-01)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.4](https://dev.azure.com/compare/v3.11.0-beta.3...v3.11.0-beta.4) (2025-03-27)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.3](https://dev.azure.com/compare/v3.11.0-beta.2...v3.11.0-beta.3) (2025-03-26)

### Features

- [#5746](https://dev.azure.com/issues/5746) add calls to services ([48c5e63](https://dev.azure.com/commits/48c5e6358a7744aa27fabc521c2726f12c6a36b3))

# [3.11.0-beta.2](https://dev.azure.com/compare/v3.11.0-beta.1...v3.11.0-beta.2) (2025-03-26)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.1](https://dev.azure.com/compare/v3.11.0-beta.0...v3.11.0-beta.1) (2025-03-25)

**Note:** Version bump only for package @camelot/project

# [3.11.0-beta.0](https://dev.azure.com/compare/v3.10.2-beta.0...v3.11.0-beta.0) (2025-03-24)

**Note:** Version bump only for package @camelot/project

## [3.10.2-beta.0](https://dev.azure.com/compare/v3.10.1-beta.1...v3.10.2-beta.0) (2025-03-20)

## [3.10.1](https://dev.azure.com/compare/v3.10.1-beta.0...v3.10.1) (2025-03-19)

**Note:** Version bump only for package @camelot/project

## [3.10.1](https://dev.azure.com/compare/v3.10.0...v3.10.1) (2025-03-19)

**Note:** Version bump only for package @camelot/project

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.10.0-beta.2](https://dev.azure.com/compare/v3.10.0-beta.1...v3.10.0-beta.2) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.10.0-beta.1](https://dev.azure.com/compare/v3.10.0-beta.0...v3.10.0-beta.1) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.10.0-beta.0](https://dev.azure.com/compare/v3.9.1-beta.0...v3.10.0-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/project

## [3.9.1-beta.0](https://dev.azure.com/compare/v3.9.0...v3.9.1-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.9.0](https://dev.azure.com/compare/v3.9.0-beta.2...v3.9.0) (2025-03-05)

**Note:** Version bump only for package @camelot/project

# [3.9.0-beta.2](https://dev.azure.com/compare/v3.9.0-beta.1...v3.9.0-beta.2) (2025-03-04)

**Note:** Version bump only for package @camelot/project

# [3.9.0-beta.1](https://dev.azure.com/compare/v3.9.0-beta.0...v3.9.0-beta.1) (2025-03-04)

**Note:** Version bump only for package @camelot/project

# [3.9.0-beta.0](https://dev.azure.com/compare/v3.8.1-beta.0...v3.9.0-beta.0) (2025-03-04)

**Note:** Version bump only for package @camelot/project

## [3.8.1-beta.0](https://dev.azure.com/compare/v3.8.0...v3.8.1-beta.0) (2025-03-03)

**Note:** Version bump only for package @camelot/project

# [3.8.0](https://dev.azure.com/compare/v3.8.0-beta.6...v3.8.0) (2025-03-01)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.6](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.6) (2025-02-28)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.5](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.5) (2025-02-28)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.4](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.4) (2025-02-28)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.3](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.3) (2025-02-28)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.2](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.2) (2025-02-28)

### Features

- quotation service + retire choices bottom ([de98ca3](https://dev.azure.com/commits/de98ca32034ea13b00ef6c9923c22c1aad2bbc7b))

# [3.8.0-beta.1](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.1) (2025-02-28)

**Note:** Version bump only for package @camelot/project

# [3.8.0-beta.0](https://dev.azure.com/compare/v3.7.1-beta.6...v3.8.0-beta.0) (2025-02-27)

### Features

- comments ([fc5b11d](https://dev.azure.com/commits/fc5b11d028acf543c936691a748fa65f00ef6ec2))
- opti call ([5538a34](https://dev.azure.com/commits/5538a34ef2dc2aaa3b7ef82b31a13d96a25c24c7))
- opti des calls dans camelot ([2e3a710](https://dev.azure.com/commits/2e3a710e9de14f95b5359dae50e69e875fb21a63))

## [3.7.1-beta.10](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.10) (2025-02-26)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.9](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.9) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.8](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.8) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.7](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.7) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.6](https://dev.azure.com/compare/v3.7.1-beta.5...v3.7.1-beta.6) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.5](https://dev.azure.com/compare/v3.7.1-beta.4...v3.7.1-beta.5) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.4](https://dev.azure.com/compare/v3.7.1-beta.3...v3.7.1-beta.4) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.3](https://dev.azure.com/compare/v3.7.1-beta.2...v3.7.1-beta.3) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.2](https://dev.azure.com/compare/v3.7.1-beta.1...v3.7.1-beta.2) (2025-02-25)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.1](https://dev.azure.com/compare/v3.7.1-beta.0...v3.7.1-beta.1) (2025-02-24)

**Note:** Version bump only for package @camelot/project

## [3.7.1-beta.0](https://dev.azure.com/compare/v3.7.0...v3.7.1-beta.0) (2025-02-24)

**Note:** Version bump only for package @camelot/project

# [3.7.0](https://dev.azure.com/compare/v3.5.0-beta.4...v3.7.0) (2025-02-24)

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0-beta.1](https://dev.azure.com/compare/v3.5.0-beta.0...v3.5.0-beta.1) (2025-02-20)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/project

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/project

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/project

# [3.4.0](https://dev.azure.com/compare/v3.3.0...v3.4.0) (2025-02-19)

**Note:** Version bump only for package @camelot/project

# [3.3.0](https://dev.azure.com/compare/v3.3.0-beta.2...v3.3.0) (2025-02-18)

**Note:** Version bump only for package @camelot/project

# [3.3.0-beta.2](https://dev.azure.com/compare/v3.3.0-beta.1...v3.3.0-beta.2) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/project

## [3.2.5-beta.0](https://dev.azure.com/compare/v3.3.0-beta.1...v3.2.5-beta.0) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/project

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/project

## [3.2.3](https://dev.azure.com/compare/v3.2.1...v3.2.3) (2025-02-17)

**Note:** Version bump only for package @camelot/project

# [3.3.0-beta.0](https://dev.azure.com/compare/v3.2.4-beta.0...v3.3.0-beta.0) (2025-02-17)

# [3.2.0-beta.0](https://dev.azure.com/compare/v3.1.1-beta.4...v3.2.0-beta.0) (2025-02-13)

**Note:** Version bump only for package @camelot/project

## [3.2.4-beta.0](https://dev.azure.com/compare/v3.2.1...v3.2.4-beta.0) (2025-02-17)

## [3.2.1-beta.0](https://dev.azure.com/compare/v3.2.0...v3.2.1-beta.0) (2025-02-17)

**Note:** Version bump only for package @camelot/project

# [3.2.0-beta.1](https://dev.azure.com/compare/v3.1.1-beta.7...v3.2.0-beta.1) (2025-02-14)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.7](https://dev.azure.com/compare/v3.1.1-beta.6...v3.1.1-beta.7) (2025-02-14)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.6](https://dev.azure.com/compare/v3.1.1-beta.5...v3.1.1-beta.6) (2025-02-13)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.5](https://dev.azure.com/compare/v3.1.1-beta.4...v3.1.1-beta.5) (2025-02-13)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.4](https://dev.azure.com/compare/v3.1.1-beta.3...v3.1.1-beta.4) (2025-02-12)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.3](https://dev.azure.com/compare/v3.1.1-beta.2...v3.1.1-beta.3) (2025-02-11)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.2](https://dev.azure.com/compare/v3.1.1...v3.1.1-beta.2) (2025-02-06)

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/project

## [3.1.1-beta.0](https://dev.azure.com/compare/v3.1.0...v3.1.1-beta.0) (2025-02-06)

**Note:** Version bump only for package @camelot/project

# [3.1.0](https://dev.azure.com/compare/v3.1.0-beta.12...v3.1.0) (2025-02-06)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.12](https://dev.azure.com/compare/v2.14.0-beta.1...v3.1.0-beta.12) (2025-02-06)

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

## [3.0.2](https://dev.azure.com/compare/v3.0.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.11](https://dev.azure.com/compare/v3.1.0-beta.10...v3.1.0-beta.11) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.10](https://dev.azure.com/compare/v3.1.0-beta.9...v3.1.0-beta.10) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.9](https://dev.azure.com/compare/v3.1.0-beta.8...v3.1.0-beta.9) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.8](https://dev.azure.com/compare/v3.1.0-beta.7...v3.1.0-beta.8) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.7](https://dev.azure.com/compare/v3.1.0-beta.6...v3.1.0-beta.7) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.6](https://dev.azure.com/compare/v3.1.0-beta.5...v3.1.0-beta.6) (2025-02-05)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.5](https://dev.azure.com/compare/v3.1.0-beta.4...v3.1.0-beta.5) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.4](https://dev.azure.com/compare/v3.1.0-beta.3...v3.1.0-beta.4) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

**Note:** Version bump only for package @camelot/project

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

# [2.14.0-beta.0](https://dev.azure.com/compare/v2.13.2-beta.0...v2.14.0-beta.0) (2025-02-04)

### Features

- ajout des services et composant lancelot ([105dbf4](https://dev.azure.com/commits/105dbf48fccc4dedcef8251d3dc674ee67cb31ce))
- ajout des urls ([b55c729](https://dev.azure.com/commits/b55c7290900c75184ae518f52e8a066249e2884f))

## [2.13.2-beta.0](https://dev.azure.com/compare/v2.13.1...v2.13.2-beta.0) (2025-01-28)

## [3.0.3](https://dev.azure.com/compare/v3.0.2...v3.0.3) (2025-02-04)

**Note:** Version bump only for package @camelot/project

## [3.0.2](https://dev.azure.com/compare/v2.13.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/project

## [3.0.1](https://dev.azure.com/compare/v2.13.1...v3.0.1) (2025-02-04)

**Note:** Version bump only for package @camelot/project

## [2.13.1](https://dev.azure.com/compare/v2.13.1-beta.10...v2.13.1) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.10](https://dev.azure.com/compare/v2.13.1-beta.9...v2.13.1-beta.10) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.9](https://dev.azure.com/compare/v2.13.1-beta.8...v2.13.1-beta.9) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.8](https://dev.azure.com/compare/v2.13.1-beta.7...v2.13.1-beta.8) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.7](https://dev.azure.com/compare/v2.13.1-beta.6...v2.13.1-beta.7) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.6](https://dev.azure.com/compare/v2.13.1-beta.5...v2.13.1-beta.6) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.5](https://dev.azure.com/compare/v2.13.1-beta.4...v2.13.1-beta.5) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.4](https://dev.azure.com/compare/v2.13.1-beta.3...v2.13.1-beta.4) (2025-01-28)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.3](https://dev.azure.com/compare/v2.13.1-beta.2...v2.13.1-beta.3) (2025-01-27)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.2](https://dev.azure.com/compare/v2.13.1-beta.1...v2.13.1-beta.2) (2025-01-27)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.1](https://dev.azure.com/compare/v2.13.1-beta.0...v2.13.1-beta.1) (2025-01-27)

**Note:** Version bump only for package @camelot/project

## [2.13.1-beta.0](https://dev.azure.com/compare/v2.13.0...v2.13.1-beta.0) (2025-01-23)

**Note:** Version bump only for package @camelot/project

# [2.13.0](https://dev.azure.com/compare/v2.12.9-beta.4...v2.13.0) (2025-01-23)

**Note:** Version bump only for package @camelot/project

## [2.12.9-beta.4](https://dev.azure.com/compare/v2.12.9-beta.3...v2.12.9-beta.4) (2025-01-23)

**Note:** Version bump only for package @camelot/project

## [2.12.9-beta.3](https://dev.azure.com/compare/v2.12.9-beta.2...v2.12.9-beta.3) (2025-01-23)

**Note:** Version bump only for package @camelot/project

## [2.12.9-beta.2](https://dev.azure.com/compare/v2.12.9-beta.1...v2.12.9-beta.2) (2025-01-23)

**Note:** Version bump only for package @camelot/project
