import { GraphSchema } from '@camelot/server';

import { Address } from './address';
import { Company } from './company';
import { WorkingOfficeProfession } from './working-office-profession';

export interface WorkingOffice {
  id: string;
  name: string;
  address: Address;
  companyId: string;
  company: Company;
  workingOfficeProfessions: WorkingOfficeProfession[];
  tenantName: string;
}

export const workingOfficeProps = new GraphSchema<WorkingOffice>([
  'id',
  'name',
  'address',
  'companyId',
  'company',
  'workingOfficeProfessions',
  'tenantName',
]);
