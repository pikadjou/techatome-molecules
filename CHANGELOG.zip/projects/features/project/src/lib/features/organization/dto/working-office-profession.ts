import { GraphSchema } from '@camelot/server';

import { Profession } from './profession';
import { WorkingOffice } from './working-office';

export interface WorkingOfficeProfession {
  workingOfficeId: string;
  workingOffice: WorkingOffice;
  professionId: string;
  profession: Profession;
}

export const workingOfficeProfessionProps = new GraphSchema<WorkingOfficeProfession>([
  'workingOfficeId',
  'workingOffice',
  'professionId',
  'profession',
]);
