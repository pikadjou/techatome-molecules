import { Injectable } from '@angular/core';

import { filter, map } from 'rxjs';

import { CamBaseService, GraphEndpoint, HandleComplexRequest } from '@camelot/server';
import { isNonNullable } from '@camelot/utils';

import { Department, departmentProps } from './dto/department';
import { WorkingOffice, workingOfficeProps } from './dto/working-office';
import { GET_DEPARTMENTS, GET_WORKING_OFFICES } from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'organizationService',
  endpoint: 'organization',
};

@Injectable({
  providedIn: 'root',
})
export class CamOrganizationsService extends CamBaseService {
  protected _graphEndpoint = graphEndpoint;
  public workingOffice = new HandleComplexRequest<WorkingOffice>();
  public department = new HandleComplexRequest<Department>();

  constructor() {
    super();
    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public fetchWorkingOffice$(id: string) {
    return this.workingOffice.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<WorkingOffice>(
          GET_WORKING_OFFICES(
            `where: { id: { eq: "${id}" }}`,
            `
              ${workingOfficeProps.get('id')}
              ${workingOfficeProps.get('name')}
              `
          ),
          'workingOffices',
          graphEndpoint.clientName
        )
        .pipe(
          map(data => (data.items && data.items.length === 1 ? data.items[0] : null)),
          filter(isNonNullable)
        )
    );
  }

  public fetchDepartment$(id: string) {
    return this.department.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<Department>(
          GET_DEPARTMENTS(
            `where: { id: { eq: "${id}" }}`,
            `
              ${departmentProps.get('id')}
              ${departmentProps.get('name')}
              `
          ),
          'departments',
          graphEndpoint.clientName
        )
        .pipe(
          map(data => (data.items && data.items.length === 1 ? data.items[0] : null)),
          filter(isNonNullable)
        )
    );
  }
}
