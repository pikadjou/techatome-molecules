import { GraphSchema } from '@camelot/server';

import { Address } from './address';
import { WorkingOffice } from './working-office';

export interface Company {
  id: string;
  name: string;
  vatNumber: string;
  pictureUrl: string;
  address: Address;
  workingOffices: WorkingOffice[];
  tenantId: number;
}

export const companyProps = new GraphSchema<Company>([
  'id',
  'name',
  'vatNumber',
  'pictureUrl',
  'address',
  'workingOffices',
  'tenantId',
]);
