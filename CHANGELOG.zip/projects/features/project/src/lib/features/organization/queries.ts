import { Apollo_gql, GraphQueryPayload, graphQlTake } from '@camelot/server';

export function GET_WORKING_OFFICES(where: string, props: string, take?: number): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query WorkingOffices {
        workingOffices(${where}, ${graphQlTake(take)}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_DEPARTMENTS(where: string, props: string, take?: number): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query Departments {
        departments(${where}, ${graphQlTake(take)}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}
