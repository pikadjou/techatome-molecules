import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, inject, signal } from '@angular/core';

import { Observable } from 'rxjs';

import { CamIconsModule } from '@camelot/icons';
import { CamContainerModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { Department } from '../../dto/department';
import { CamOrganizationsService } from '../../organizations.service';

@Component({
  selector: 'cam-department-name',
  templateUrl: './department-name.component.html',
  styleUrls: ['./department-name.component.scss'],
  standalone: true,
  imports: [CamDirectivePipeModule, CommonModule, CamContainerModule, CamIconsModule],
})
export class CamDepartmentNameComponent extends CamBaseComponent {
  @Input()
  departmentId!: string;

  readonly department$ = signal<Observable<Department | null> | null>(null);

  private _organizationsService = inject(CamOrganizationsService);

  constructor() {
    super();
  }

  ngOnInit() {
    this.department$.set(this._organizationsService.department.get$(this.departmentId));
    this._fetch();
  }

  private _fetch() {
    this.requestState.asked();
    this._organizationsService.fetchDepartment$(this.departmentId).subscribe({
      complete: () => {
        this.requestState.completed();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
