import { GraphSchema } from '@camelot/server';

import { Department } from './department';
import { WorkingOfficeProfession } from './working-office-profession';

export interface Profession {
  id: string;
  name: string;
  departmentId: string;
  department: Department;
  workingOfficeProfessions: WorkingOfficeProfession[];
  tenantId: number;
}

export const professionProps = new GraphSchema<Profession>([
  'id',
  'name',
  'departmentId',
  'department',
  'workingOfficeProfessions',
  'tenantId',
]);
