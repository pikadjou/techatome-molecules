import { GraphSchema } from '@camelot/server';

import { Profession } from './profession';

export interface Department {
  id: string;
  name: string;
  pictureUrl: string;
  professions: Profession[];
  tenantId: number;
}

export const departmentProps = new GraphSchema<Department>(['id', 'name', 'pictureUrl', 'professions', 'tenantId']);
