import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, inject, signal } from '@angular/core';

import { Observable } from 'rxjs';

import { CamIconsModule } from '@camelot/icons';
import { CamContainerModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { WorkingOffice } from '../../dto/working-office';
import { CamOrganizationsService } from '../../organizations.service';

@Component({
  selector: 'cam-working-office-name',
  templateUrl: './working-office-name.component.html',
  styleUrls: ['./working-office-name.component.scss'],
  standalone: true,
  imports: [CamDirectivePipeModule, CommonModule, CamContainerModule, CamIconsModule],
})
export class CamWorkingOfficeNameComponent extends CamBaseComponent {
  @Input()
  workingOfficeId!: string;

  public readonly workingOffice$ = signal<Observable<WorkingOffice | null> | null>(null);

  private _organizationsService = inject(CamOrganizationsService);

  constructor() {
    super();
  }

  ngOnInit() {
    this.workingOffice$.set(this._organizationsService.workingOffice.get$(this.workingOfficeId));
    this._fetch();
  }

  private _fetch() {
    this.requestState.asked();
    this._organizationsService.fetchWorkingOffice$(this.workingOfficeId).subscribe({
      complete: () => {
        this.requestState.completed();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
