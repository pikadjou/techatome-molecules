import { AsyncPipe, CommonModule } from '@angular/common';
import { CurrencyPipe } from '@angular/common';
import { Component, Input, inject } from '@angular/core';

import { map } from 'rxjs/operators';

import { of } from 'rxjs';

import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';
import { CamPermissionsService, CamUsersService, User } from '@camelot/user';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { IPrice } from '../../helpers/price';

export type Display = 'label' | 'amount' | 'both';

@Component({
  selector: 'cam-billing-amount',
  templateUrl: './amount.component.html',
  styleUrls: ['./amount.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, AsyncPipe, CurrencyPipe, CommonModule, TranslatePipe],
})
export class CamAmountComponent extends CamBaseComponent {
  @Input()
  amount!: IPrice;

  @Input()
  display: Display = 'both';

  @Input()
  inverse = false;

  @Input()
  forceTTC = false;

  public readonly _permissionsService = inject(CamPermissionsService);

  private _userService = inject(CamUsersService);

  get label$() {
    if (!this._permissionsService.isAuthenticated) {
      return of('billings.amount.label.tva');
    }
    return this._userService.currentUser
      .get$()
      .pipe(map(user => (this._hideTva(user) ? 'billings.amount.label.htva' : 'billings.amount.label.tva')));
  }
  get amount$() {
    if (!this._permissionsService.isAuthenticated) {
      return of(this.amount.incl);
    }
    return this._userService.currentUser
      .get$()
      .pipe(map(user => (this._hideTva(user) ? this.amount.excl : this.amount.incl)));
  }

  private _hideTva(user: User | null) {
    const isCompany = this.forceTTC ? user?.isCompany : false;

    return this.inverse ? !isCompany : isCompany;
  }
}
