import { Component, inject, Input } from '@angular/core';
import { CamContainerModule, CamUiModule } from '@camelot/ui';
import {
  CamBaseComponent,
  CamDirectivePipeModule,
  openExternalUrl,
} from '@camelot/utils';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { CamInvoicesService } from '../../services/invoices.service';
import { CamIconsModule } from '@camelot/icons';

@Component({
  selector: 'cam-invoice-tenant-url-displayer',
  templateUrl: './invoice-tenant-url-displayer.component.html',
  styleUrls: ['./invoice-tenant-url-displayer.component.scss'],
  standalone: true,
  imports: [
    CamUiModule,
    CamDirectivePipeModule,
    CommonModule,
    CamContainerModule,
    CamIconsModule,
  ],
})
export class CamInvoiceTenantUrlDisplayerComponent extends CamBaseComponent {
  @Input()
  invoiceId!: string;

  @Input()
  display: 'button' | 'icon' = 'icon';

  get tenantRoute$() {
    return this._invoiceService.tenantRoute.get$();
  }

  private _invoiceService = inject(CamInvoicesService);

  constructor() {
    super();
  }

  ngOnInit() {
    this._fetch();
  }

  public navigateToTenant(url: string) {
    openExternalUrl(url);
  }

  private _fetch() {
    this.requestState.asked();
    this._invoiceService.fetchTenantRoute$(this.invoiceId).subscribe({
      complete: () => {
        this.requestState.completed();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
