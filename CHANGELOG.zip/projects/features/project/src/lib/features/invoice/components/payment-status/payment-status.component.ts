import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

import { ColorType } from '@camelot/styles';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { PaymentStatus } from '../../services/dto/payment-status';

@Component({
  selector: 'cam-billings-payment-status',
  templateUrl: './payment-status.component.html',
  styleUrls: ['./payment-status.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, CommonModule, TranslatePipe],
})
export class CamPaymentStatusComponent extends CamBaseComponent {
  @Input()
  status!: PaymentStatus;

  @Input()
  noLabel = false;

  @Input()
  isCreditNote = false;

  constructor() {
    super();
  }

  public getType(): ColorType {
    switch (this.status) {
      case PaymentStatus.NotPaid:
        return !this.isCreditNote ? 'default' : 'purple';
      case PaymentStatus.Paid:
        return 'success';
      case PaymentStatus.PartiallyPaid:
        return 'warning';
      case PaymentStatus.Late:
        return 'alert';
      default:
        return 'default';
    }
  }

  public getTranslate() {
    if (this.noLabel) {
      return '';
    }
    if (this.status == PaymentStatus.NotPaid && this.isCreditNote) {
      return `billings.payment-status.to-payback`;
    }
    return `billings.payment-status.${PaymentStatus[this.status].toLocaleLowerCase()}`;
  }
}
