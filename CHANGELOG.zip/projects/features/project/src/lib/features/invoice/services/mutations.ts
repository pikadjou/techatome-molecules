import { Apollo_gql, GraphMutationPayload } from '@camelot/server';

import { invoiceProps } from './dto/invoice';

export function READ_INVOICE(id: string): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
      mutation InvoiceRead($id: UUID!) {
        invoiceRead(invoiceId: $id) {
            ${invoiceProps.get('id')}
            ${invoiceProps.get('isNew')}
        }
      }
    `,
    variables: {
      id,
    },
  };
}
