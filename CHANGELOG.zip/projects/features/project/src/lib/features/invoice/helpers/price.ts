export interface IPrice {
  excl: number;
  incl: number;
}
