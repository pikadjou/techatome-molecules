import { Injectable } from '@angular/core';

import { Observable, filter, map, tap } from 'rxjs';

import { CamBaseService, GraphEndpoint, HandleComplexRequest, HandleSimpleRequest } from '@camelot/server';
import { isNonNullable } from '@camelot/utils';

import { invoiceAddressProps } from './dto/address';
import { Invoice, invoiceProps } from './dto/invoice';
import { PaymentLink } from './dto/payment-link';
import { progressStatementsProps } from './dto/progress-statements';
import { InvoiceRow, invoiceRowProps } from './dto/row';
import { READ_INVOICE } from './mutations';
import { GET_INVOICES, GET_INVOICE_ROWS, GET_INVOICE_TENANT_ROUTE, GET_PAYMENT_LINK } from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'invoiceService',
  endpoint: 'invoice',
};

@Injectable({
  providedIn: 'root',
})
export class CamInvoicesService extends CamBaseService {
  protected _graphEndpoint = graphEndpoint;

  public invoices = new HandleSimpleRequest<Invoice[]>();
  public invoice = new HandleComplexRequest<Invoice>();
  public invoiceContext = new HandleComplexRequest<Invoice>();
  public invoicesByProject = new HandleComplexRequest<Invoice[]>();
  public invoicesByContact = new HandleComplexRequest<Invoice[]>();
  public invoiceRows = new HandleComplexRequest<InvoiceRow[]>();

  public tenantRoute = new HandleSimpleRequest<string>();

  public paymentLink = new HandleComplexRequest<PaymentLink | null>();

  constructor() {
    super();
    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public fetchInvoices$() {
    return this.invoices.fetch(
      this._graphService
        .fetchPagedQueryList<Invoice>(
          GET_INVOICES(
            '',
            `
            ${invoiceProps.get('id')}
            ${invoiceProps.get('reference')}
            ${invoiceProps.get('inclVatTotal')}
            ${invoiceProps.get('exclVatTotal')}
            ${invoiceProps.get('paymentStatus')}
            ${invoiceProps.get('isCreditNote')}
            ${invoiceProps.get('dueDate')}
            ${invoiceProps.get('beneficiaryIban')}
            ${invoiceProps.get('beneficiaryBic')}
            ${invoiceProps.get('beneficiaryName')}
            ${invoiceProps.get('structuredCommunication')}
            ${invoiceProps.get('isNew')}
          `
          ),
          'invoices',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchInvoicesByContact$(contactId: string) {
    return this.invoicesByContact.fetch(
      contactId,
      this._graphService
        .fetchPagedQueryList<Invoice>(
          GET_INVOICES(
            `where: { contactId: { eq: "${contactId}" } }`,
            `
            ${invoiceProps.get('id')}
            ${invoiceProps.get('reference')}
            ${invoiceProps.get('contactId')}
            ${invoiceProps.get('projectId')}
          `
          ),
          'invoices',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchInvoicesByProject$(projectId: string) {
    return this.invoicesByProject.fetch(
      projectId,
      this._graphService
        .fetchPagedQueryList<Invoice>(
          GET_INVOICES(
            `where: { projectId: { eq: "${projectId}" }}`,
            `
            ${invoiceProps.get('id')}
            ${invoiceProps.get('reference')}
            ${invoiceProps.get('inclVatTotal')}
            ${invoiceProps.get('exclVatTotal')}
            ${invoiceProps.get('paymentStatus')}
            ${invoiceProps.get('isCreditNote')}
            ${invoiceProps.get('dueDate')}
            ${invoiceProps.get('beneficiaryIban')}
            ${invoiceProps.get('beneficiaryBic')}
            ${invoiceProps.get('beneficiaryName')}
            ${invoiceProps.get('structuredCommunication')}
            ${invoiceProps.get('isNew')}
            `
          ),
          'invoices',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchInvoice$(id: string) {
    return this.invoice.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<Invoice>(
          GET_INVOICES(
            `where: { id: { eq: "${id}" }}`,
            `
        ${invoiceProps.get('id')}
        ${invoiceProps.get('reference')}
        ${invoiceProps.get('description')}
        ${invoiceProps.get('downloadUriPDF')}
        ${invoiceProps.get('rowsCount')}
        ${invoiceProps.get('inclVatTotal')}
        ${invoiceProps.get('exclVatTotal')}
        ${invoiceProps.get('dueDate')}
        ${invoiceProps.get('validationDate')}
        ${invoiceProps.get('invoiceNumber')}
        ${invoiceProps.get('paymentStatus')}
        ${invoiceProps.get('contactId')}
        ${invoiceProps.get('hiddenDetails')}
        ${invoiceProps.get('isNew')}
        ${invoiceProps.get('isCreditNote')}
        ${invoiceProps.get('invoiceAddress')} {
          ${invoiceAddressProps.get('id')}
          ${invoiceAddressProps.get('country')}
          ${invoiceAddressProps.get('city')}
          ${invoiceAddressProps.get('postCode')}
          ${invoiceAddressProps.get('street')}
        }
        ${invoiceProps.get('progressStatements')} {
          ${progressStatementsProps.get('id')}
          ${progressStatementsProps.get('quotationVersionId')}
          ${progressStatementsProps.get('isFinal')}
          ${progressStatementsProps.get('isDeposit')}
        }
        ${invoiceProps.get('beneficiaryIban')}
        ${invoiceProps.get('beneficiaryBic')}
        ${invoiceProps.get('beneficiaryName')}
        ${invoiceProps.get('structuredCommunication')}
        `
          ),
          'invoices',
          graphEndpoint.clientName
        )
        .pipe(
          map(data => (data.items && data.items.length === 1 ? data.items[0] : null)),
          filter(isNonNullable),
          tap(invoice => this.isRead$(invoice.id).subscribe())
        )
    );
  }

  public fetchInvoiceContext$(id: string) {
    return this.invoiceContext.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<Invoice>(
          GET_INVOICES(
            `where: { id: { eq: "${id}" }}`,
            `
        ${invoiceProps.get('id')}
        ${invoiceProps.get('reference')}
        ${invoiceProps.get('description')}
        ${invoiceProps.get('downloadUriPDF')}
        ${invoiceProps.get('inclVatTotal')}
        ${invoiceProps.get('exclVatTotal')}
        ${invoiceProps.get('dueDate')}
        ${invoiceProps.get('validationDate')}
        ${invoiceProps.get('paymentStatus')}
        ${invoiceProps.get('projectId')}
        `
          ),
          'invoices',
          graphEndpoint.clientName
        )
        .pipe(
          map(data => (data.items && data.items.length === 1 ? data.items[0] : null)),
          filter(isNonNullable)
        )
    );
  }

  public isRead$(id: string) {
    return this._graphService.mutate<boolean>(READ_INVOICE(id), 'invoiceRead', graphEndpoint.clientName);
  }

  public fetchInvoiceRows$(invoiceId: string) {
    return this.invoiceRows.fetch(
      invoiceId,
      this._graphService
        .fetchPagedQueryList<InvoiceRow>(
          GET_INVOICE_ROWS(
            `where: { parent: { eq: null }, invoiceId: { eq: "${invoiceId}" }}`,
            `
              ${invoiceRowProps.get('id')}
              ${invoiceRowProps.get('index')}
              ${invoiceRowProps.get('parent')}
              ${invoiceRowProps.get('hidden')}
              ${invoiceRowProps.get('rowType')}
              ${invoiceRowProps.get('sourceRef')}
              ${invoiceRowProps.get('description')}
              ${invoiceRowProps.get('itemType')}
              ${invoiceRowProps.get('quantity')}
              ${invoiceRowProps.get('unit')}
              ${invoiceRowProps.get('unitDescription')}
              ${invoiceRowProps.get('unitSellingPrice')}
              ${invoiceRowProps.get('vatPercentage')}
              ${invoiceRowProps.get('exclVatTotal')}
              ${invoiceRowProps.get('inclVatTotal')}
              ${invoiceRowProps.get('chapterExclVatTotal')}
              ${invoiceRowProps.get('chapterInclVatTotal')}
              ${invoiceRowProps.get('childrenRowsCount')}
            `
          ),
          'filteredInvoiceRows',
          graphEndpoint.clientName
        )
        .pipe(
          map(list => (list.items ? list.items : [])),
          map(list =>
            list.map(item => ({
              ...item,
              ...{ label: item.index.toString() },
            }))
          )
        )
    );
  }

  public fetchInvoiceRowChildren$(parentId: string, parent?: InvoiceRow) {
    return this.invoiceRows.fetch(
      parentId,
      this._graphService
        .fetchPagedQueryList<InvoiceRow>(
          GET_INVOICE_ROWS(
            `where: { parent: { eq: "${parentId}" }}`,
            `
            ${invoiceRowProps.get('id')}
            ${invoiceRowProps.get('index')}
            ${invoiceRowProps.get('parent')}
            ${invoiceRowProps.get('hidden')}
            ${invoiceRowProps.get('rowType')}
            ${invoiceRowProps.get('sourceRef')}
            ${invoiceRowProps.get('description')}
            ${invoiceRowProps.get('itemType')}
            ${invoiceRowProps.get('quantity')}
            ${invoiceRowProps.get('unit')}
            ${invoiceRowProps.get('unitDescription')}
            ${invoiceRowProps.get('unitSellingPrice')}
            ${invoiceRowProps.get('vatPercentage')}
            ${invoiceRowProps.get('exclVatTotal')}
            ${invoiceRowProps.get('inclVatTotal')}
            ${invoiceRowProps.get('chapterExclVatTotal')}
            ${invoiceRowProps.get('chapterInclVatTotal')}
            ${invoiceRowProps.get('childrenRowsCount')}
          `
          ),
          'filteredInvoiceRows',
          graphEndpoint.clientName
        )
        .pipe(
          map(list => (list.items ? list.items : [])),
          map(list =>
            list.map(item => ({
              ...item,
              ...{ label: `${parent?.label}.${item.index}` },
            }))
          )
        )
        .pipe(map(invoice => invoice))
    );
  }

  public getPaymentLink$(
    id: string,
    qrCode: boolean,
    confirmationUrl: string,
    cancelUrl: string,
    errorUrl: string
  ): Observable<PaymentLink | null> {
    return this.paymentLink.fetch(
      id,
      this._graphService.fetchQuery<PaymentLink | null>(
        GET_PAYMENT_LINK(id, qrCode, confirmationUrl, cancelUrl, errorUrl),
        'paymentLink',
        graphEndpoint.clientName
      )
    );
  }

  public getInvoicesLightInfo$(ids: string[]) {
    return this._graphService
      .fetchPagedQueryList<Invoice>(
        GET_INVOICES(
          `where: { id: { in: [${ids.map(id => `"${id}"`).join(', ')}] } }`,
          `
            ${invoiceProps.get('id')}
            ${invoiceProps.get('reference')}
          `
        ),
        'invoices',
        graphEndpoint.clientName
      )
      .pipe(map(data => data.items ?? []));
  }

  public fetchTenantRoute$(invoiceId: string) {
    return this.tenantRoute.fetch(
      this._graphService
        .fetchQuery<string>(GET_INVOICE_TENANT_ROUTE(invoiceId), 'invoiceTenantRoute', graphEndpoint.clientName)
        .pipe(filter(isNonNullable))
    );
  }
}
