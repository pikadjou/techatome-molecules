import { Apollo_gql, GraphQueryPayload, graphQlTake } from '@camelot/server';

import { paymentLinkProps } from './dto/payment-link';

export function GET_INVOICES(where: string, props: string, take?: number): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query Invoices {
        invoices(${where}, ${graphQlTake(take)}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_INVOICE_ROWS(where: string, props: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query FilteredInvoiceRows {
        filteredInvoiceRows(${where}, ${graphQlTake()}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_PAYMENT_LINK(
  id: string,
  qrCode: boolean,
  confirmationUrl: string,
  cancelUrl: string,
  errorUrl: string
): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query PaymentLink($id: UUID!, $qrCode: Boolean!) {
        paymentLink(invoiceId: $id, qrCode: $qrCode) {
          ${paymentLinkProps.get('executeLink')}
          ${paymentLinkProps.get('executeQrLink')}
          ${paymentLinkProps.get('imageLink')}
        }
      }
    `,
    variables: {
      id: id,
      qrCode: qrCode,
      confirmationUrl: confirmationUrl,
      cancelUrl: cancelUrl,
      errorUrl: errorUrl,
    },
  };
}

export function GET_INVOICE_TENANT_ROUTE(invoiceId: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
        query InvoiceTenantRoute($invoiceId: UUID!) {
          invoiceTenantRoute(invoiceId: $invoiceId)
        }
      `,
    variables: {
      invoiceId: invoiceId,
    },
  };
}
