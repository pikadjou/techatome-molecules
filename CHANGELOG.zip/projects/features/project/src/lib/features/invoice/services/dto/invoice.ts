import { GraphSchema } from '@camelot/server';

import { InvoiceAddress } from './address';
import { PaymentStatus } from './payment-status';
import { ProgressStatements } from './progress-statements';
import {
  billingItemProps,
  BillingItem,
} from '../../../../common/services/dto/item';

export interface Invoice extends BillingItem {
  reference: string;
  invoiceNumber: number;

  paymentStatus: PaymentStatus;
  validationDate: string;

  invoiceAddress: InvoiceAddress;
  progressStatements: ProgressStatements[];

  contactId: string;
  projectId: string;

  structuredCommunication: string;
  beneficiaryName: string;
  beneficiaryIban: string;
  beneficiaryBic: string;
  isCreditNote: boolean;

  hiddenDetails: boolean;
}

const props: (keyof Invoice)[] = [
  'reference',
  'validationDate',
  'invoiceNumber',
  'invoiceAddress',
  'progressStatements',
  'contactId',
  'projectId',
  'paymentStatus',
  'isCreditNote',
  'structuredCommunication',
  'beneficiaryName',
  'beneficiaryIban',
  'beneficiaryBic',
  'paymentStatus',
  'hiddenDetails',
];

export const invoiceProps = new GraphSchema<Invoice>(
  props.concat(billingItemProps)
);
