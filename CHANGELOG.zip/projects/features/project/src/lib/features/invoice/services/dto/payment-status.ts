export enum PaymentStatus {
  Unknown = 0,
  NotPaid = 1,
  Paid = 2,
  PartiallyPaid = 3,
  Late = 4,
  Transaction = 5,
}
