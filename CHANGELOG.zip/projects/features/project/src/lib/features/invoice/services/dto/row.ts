import { GraphSchema } from '@camelot/server';
import {
  BillingRow,
  billingRowProps,
} from '../../../../common/services/dto/row';

export interface InvoiceRow extends BillingRow {}

export const invoiceRowProps = new GraphSchema<InvoiceRow>(billingRowProps);
