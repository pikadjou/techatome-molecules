import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, inject } from '@angular/core';

import { CamIconsModule } from '@camelot/icons';
import { CamContainerModule, CamUiModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule, openExternalUrl } from '@camelot/utils';

import { CamMaintenancesService } from '../../services/maintenances.service';

@Component({
  selector: 'cam-maintenance-tenant-url-displayer',
  templateUrl: './maintenance-tenant-url-displayer.component.html',
  styleUrls: ['./maintenance-tenant-url-displayer.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, CommonModule, CamContainerModule, CamIconsModule],
})
export class CamMaintenanceTenantUrlDisplayerComponent extends CamBaseComponent {
  @Input()
  maintenanceId!: string;

  @Input()
  display: 'button' | 'icon' = 'icon';

  get tenantRoute$() {
    return this._maintenancesService.tenantRoute.get$();
  }

  private _maintenancesService = inject(CamMaintenancesService);

  constructor() {
    super();
  }

  ngOnInit() {
    this._fetch();
  }

  public navigateToTenant(url: string) {
    openExternalUrl(url);
  }

  private _fetch() {
    this.requestState.asked();
    this._maintenancesService.fetchTenantRoute$(this.maintenanceId).subscribe({
      complete: () => {
        this.requestState.completed();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
