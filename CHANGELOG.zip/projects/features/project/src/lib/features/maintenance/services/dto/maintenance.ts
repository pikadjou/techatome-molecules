import { GraphSchema } from '@camelot/server';

import { MaintenanceStatus } from './maintenance-status';

export interface Maintenance {
  id: string;
  title: string;
  description: string;
  status: MaintenanceStatus;
  contactId: string;
  projectId: string;
  workingOfficeId: string;
  departmentId: string;
  tenantName: string;
}

export const maintenanceProps = new GraphSchema<Maintenance>([
  'id',
  'title',
  'description',
  'status',
  'contactId',
  'projectId',
  'workingOfficeId',
  'departmentId',
  'tenantName',
]);
