import { Apollo_gql, GraphQueryPayload, graphQlTake } from '@camelot/server';

export function GET_MAINTENANCES(where: string, props: string, take?: number): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query Maintenances {
        maintenances(${where}, ${graphQlTake(take)}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_MAINTENANCE_TENANT_ROUTE(maintenanceId: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
          query MaintenanceTenantRoute($maintenanceId: UUID!) {
            maintenanceTenantRoute(maintenanceId: $maintenanceId)
          }
        `,
    variables: {
      maintenanceId: maintenanceId,
    },
  };
}
