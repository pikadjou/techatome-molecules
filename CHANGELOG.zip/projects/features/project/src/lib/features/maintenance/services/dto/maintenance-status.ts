export enum MaintenanceStatus {
  Unknown,
  Draft,
  Active,
  Terminated,
  Cancelled,
  Inactive,
}
