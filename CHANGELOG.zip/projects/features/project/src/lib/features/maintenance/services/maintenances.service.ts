import { Injectable } from '@angular/core';

import { filter, map } from 'rxjs';

import { CamBaseService, GraphEndpoint, HandleComplexRequest, HandleSimpleRequest } from '@camelot/server';
import { isNonNullable } from '@camelot/utils';

import { Maintenance, maintenanceProps } from './dto/maintenance';
import { GET_MAINTENANCES, GET_MAINTENANCE_TENANT_ROUTE } from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'maintenanceService',
  endpoint: 'maintenance',
};

@Injectable({
  providedIn: 'root',
})
export class CamMaintenancesService extends CamBaseService {
  protected _graphEndpoint = graphEndpoint;
  public maintenances = new HandleSimpleRequest<Maintenance[]>();
  public maintenance = new HandleComplexRequest<Maintenance>();
  public maintenancesByContact = new HandleComplexRequest<Maintenance[]>();

  public tenantRoute = new HandleSimpleRequest<string>();

  constructor() {
    super();
    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public fetchMaintenance$(id: string) {
    return this.maintenance.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<Maintenance>(
          GET_MAINTENANCES(
            `where: { id: { eq: "${id}" }}`,
            `
            ${maintenanceProps.get('id')}
            ${maintenanceProps.get('title')}
            ${maintenanceProps.get('description')}
            ${maintenanceProps.get('status')}
            ${maintenanceProps.get('tenantName')}
            ${maintenanceProps.get('projectId')}
            ${maintenanceProps.get('workingOfficeId')}
            ${maintenanceProps.get('departmentId')}
            `
          ),
          'maintenances',
          graphEndpoint.clientName
        )
        .pipe(
          map(data => (data.items && data.items.length === 1 ? data.items[0] : null)),
          filter(isNonNullable)
        )
    );
  }

  public fetchMaintenances$() {
    return this.maintenances.fetch(
      this._graphService
        .fetchPagedQueryList<Maintenance>(
          GET_MAINTENANCES(
            '',
            `
              ${maintenanceProps.get('id')}
              ${maintenanceProps.get('title')}
              ${maintenanceProps.get('description')}
              ${maintenanceProps.get('status')}
              ${maintenanceProps.get('tenantName')}
              ${maintenanceProps.get('projectId')}
            `
          ),
          'maintenances',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchMaintenancesByContact$(contactId: string) {
    return this.maintenancesByContact.fetch(
      contactId,
      this._graphService
        .fetchPagedQueryList<Maintenance>(
          GET_MAINTENANCES(
            `where: { contactId: { eq: "${contactId}" } }`,
            `
            ${maintenanceProps.get('id')}
            ${maintenanceProps.get('title')}
            ${maintenanceProps.get('contactId')}
            ${maintenanceProps.get('projectId')}
          `
          ),
          'maintenances',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchTenantRoute$(maintenanceId: string) {
    return this.tenantRoute.fetch(
      this._graphService
        .fetchQuery<string>(
          GET_MAINTENANCE_TENANT_ROUTE(maintenanceId),
          'maintenanceTenantRoute',
          graphEndpoint.clientName
        )
        .pipe(filter(isNonNullable))
    );
  }

  public getMaintenancesLightInfo$(ids: string[]) {
    return this._graphService
      .fetchPagedQueryList<Maintenance>(
        GET_MAINTENANCES(
          `where: { id: { in: [${ids.map(id => `"${id}"`).join(', ')}] } }`,
          `
              ${maintenanceProps.get('id')}
              ${maintenanceProps.get('title')}
            `
        ),
        'maintenances',
        graphEndpoint.clientName
      )
      .pipe(map(data => data.items ?? []));
  }
}
