import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

import { ColorType } from '@camelot/styles';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { MaintenanceStatus } from '../../services/dto/maintenance-status';

@Component({
  selector: 'cam-maintenance-status',
  templateUrl: './maintenance-status.component.html',
  styleUrls: ['./maintenance-status.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, CommonModule, TranslatePipe],
})
export class CamMaintenanceStatusComponent extends CamBaseComponent {
  @Input()
  status!: MaintenanceStatus;

  @Input()
  noLabel = false;

  get color(): ColorType {
    switch (this.status) {
      case MaintenanceStatus.Active:
        return 'success';
      case MaintenanceStatus.Draft:
        return 'purple';
      case MaintenanceStatus.Inactive:
        return 'default';
      case MaintenanceStatus.Cancelled:
        return 'alert';
      case MaintenanceStatus.Terminated:
        return 'secondary';
      default:
        return 'purple';
    }
  }

  get label(): string {
    if (this.noLabel) {
      return '';
    }

    return `maintenances.status.${MaintenanceStatus[this.status]?.toLowerCase() ?? 'unknown'}`;
  }
}
