import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

import { ProjectStatus } from '@camelot/services';
import { ColorType } from '@camelot/styles';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

@Component({
  selector: 'cam-project-status',
  templateUrl: './project-status.component.html',
  styleUrls: ['./project-status.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, CommonModule, TranslatePipe],
})
export class CamProjectStatusComponent extends CamBaseComponent {
  @Input()
  status!: ProjectStatus;

  @Input()
  noLabel = false;

  get color(): ColorType {
    switch (this.status) {
      case ProjectStatus.Done:
        return 'success';
      case ProjectStatus.Pending:
        return 'purple';
      case ProjectStatus.InProgress:
        return 'default';
      case ProjectStatus.Cancelled:
        return 'secondary';
      default:
        return 'purple';
    }
  }

  get label(): string {
    if (this.noLabel) {
      return '';
    }

    const statusKey = ProjectStatus[Number(this.status)];
    return `projects.status.${statusKey?.toLowerCase() ?? 'unknown'}`;
  }
}
