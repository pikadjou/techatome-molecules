export enum ProjectStatus {
  Unknown = 0,
  InProgress = 1,
  Pending = 2,
  Done = 3,
  Cancelled = 4,
}
