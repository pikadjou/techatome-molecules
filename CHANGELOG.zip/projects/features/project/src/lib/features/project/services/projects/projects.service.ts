import { Injectable } from '@angular/core';

import { filter, map } from 'rxjs';

import {
  CamBaseService,
  GraphEndpoint,
  HandleComplexRequest,
  HandleSimpleRequest,
} from '@camelot/server';

import { Project, projectProps } from './dto/project';
import {
  GET_LIGHT_PROJECTS,
  GET_MY_PROJECTS,
  GET_PROJECTS,
  GET_PROJECT_BY_ID,
  GET_PROJECT_TENANT_ROUTE,
  GET_PROJECT_DOCUMENT_IDS,
} from './queries';
import { isNonNullable } from '@camelot/utils';

const graphEndpoint: GraphEndpoint = {
  clientName: 'projectService',
  endpoint: 'project',
};

@Injectable({
  providedIn: 'root',
})
export class CamProjectsService extends CamBaseService {
  protected _graphEndpoint = graphEndpoint;
  public projects = new HandleSimpleRequest<Project[]>();
  public project = new HandleComplexRequest<Project>();

  public tenantRoute = new HandleSimpleRequest<string>();

  public projectByContact = new HandleComplexRequest<Project[]>();

  public projectDocumentIds = new HandleComplexRequest<string[]>();

  constructor() {
    super();
    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public getProjectsLightInfo$(ids: string[]) {
    return this._graphService
      .fetchPagedQueryList<Project>(
        GET_LIGHT_PROJECTS(ids),
        'projects',
        graphEndpoint.clientName
      )
      .pipe(map((data) => data.items ?? []));
  }

  public fetchProjectsByContact$(contactId: string) {
    return this.projectByContact.fetch(
      contactId,
      this._graphService
        .fetchPagedQueryList<Project>(
          GET_PROJECTS(
            `where: { contactId: { eq: "${contactId}" } }`,
            `
              ${projectProps.get('id')}
              ${projectProps.get('name')}
            `
          ),
          'projects',
          graphEndpoint.clientName
        )
        .pipe(map((data) => data.items ?? []))
    );
  }

  public fetchProjects$() {
    return this.projects.fetch(
      this._graphService
        .fetchPagedQueryList<Project>(
          GET_MY_PROJECTS(),
          'projects',
          graphEndpoint.clientName
        )
        .pipe(map((data) => data.items))
    );
  }

  public fetchProject$(id: string) {
    return this.project.fetch(
      id,
      this._graphService.fetchQuery<Project>(
        GET_PROJECT_BY_ID(id),
        'projectById',
        graphEndpoint.clientName
      )
    );
  }

  public fetchTenantRoute$(projectId: string) {
    return this.tenantRoute.fetch(
      this._graphService
        .fetchQuery<string>(
          GET_PROJECT_TENANT_ROUTE(projectId),
          'projectTenantRoute',
          graphEndpoint.clientName
        )
        .pipe(filter(isNonNullable))
    );
  }

  public fetchProjectDocumentIds$(projectId: string){
    return this.projectDocumentIds.fetch(
      projectId,
      this._graphService.fetchQuery<string[]>(GET_PROJECT_DOCUMENT_IDS(projectId), 'projectDocumentIds', graphEndpoint.clientName)
    );
  }
}
