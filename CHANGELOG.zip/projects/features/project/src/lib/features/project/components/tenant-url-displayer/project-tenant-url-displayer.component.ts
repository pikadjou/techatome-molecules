import { Component, inject, Input } from '@angular/core';
import { CamContainerModule, CamUiModule } from '@camelot/ui';
import {
  CamBaseComponent,
  CamDirectivePipeModule,
  openExternalUrl,
} from '@camelot/utils';
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { CamProjectsService } from '../../services/projects/projects.service';
import { CamIconsModule } from '@camelot/icons';

@Component({
  selector: 'cam-project-tenant-url-displayer',
  templateUrl: './project-tenant-url-displayer.component.html',
  styleUrls: ['./project-tenant-url-displayer.component.scss'],
  standalone: true,
  imports: [
    CamUiModule,
    CamDirectivePipeModule,
    CommonModule,
    CamContainerModule,
    CamIconsModule,
  ],
})
export class CamProjectTenantUrlDisplayerComponent extends CamBaseComponent {
  @Input()
  projectId!: string;

  @Input()
  display: 'button' | 'icon' = 'icon';

  get tenantRoute$() {
    return this._projectService.tenantRoute.get$();
  }

  private _projectService = inject(CamProjectsService);

  constructor() {
    super();
  }

  ngOnInit() {
    this._fetch();
  }

  public navigateToTenant(url: string) {
    openExternalUrl(url);
  }

  private _fetch() {
    this.requestState.asked();
    this._projectService.fetchTenantRoute$(this.projectId).subscribe({
      complete: () => {
        this.requestState.completed();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
