import { Observable } from 'rxjs';

import { HandleComplexRequest } from '@camelot/server';

import { RefusalInfos } from './dto/RefusalInfos';
import { QuotationSignature } from './dto/quotation-signature';
import { QuotationRow } from './dto/row';
import { QuotationVersion } from './dto/version';

export interface IQuotationsService {
  version: HandleComplexRequest<QuotationVersion>;
  quotationParentRows: HandleComplexRequest<QuotationRow[]>;
  fetchQuotationParentRows$: (id: string) => Observable<QuotationRow[]>;
  fetchQuotationRowChildren$: (id: string, parent?: QuotationRow) => Observable<QuotationRow[]>;
  fetchVersions$: (ids: string[]) => Observable<QuotationVersion[]>;
  setQuotationVersionSigned$: (quotationVersionId: string) => Observable<QuotationVersion>;
  setQuotationVersionRefused$: (quotationVersionId: string, refusalInfos: RefusalInfos) => Observable<QuotationVersion>;
  getSignatureLink$: (
    quotationVersionId: string,
    successUri: string,
    errorUri: string,
    declineUri: string
  ) => Observable<QuotationSignature>;
  quotationSignature: HandleComplexRequest<QuotationSignature>;
}
