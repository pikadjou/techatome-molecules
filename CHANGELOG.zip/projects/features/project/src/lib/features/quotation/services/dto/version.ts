import { GraphSchema } from '@camelot/server';
import { User } from '@camelot/user';

import { Quotation } from './quotation';
import { QuotationStatus } from './quotation-status';
import {
  BillingItem,
  billingItemProps,
} from '../../../../common/services/dto/item';

export interface QuotationVersion extends BillingItem {
  version: number;
  status: QuotationStatus;
  date: string;
  acceptanceDate: string;
  paymentTerm: string;

  downloadUriExcel: string;

  rowsMigratedCount: number;
  fullyMigrated: number;

  discount: number;

  quotation?: Quotation;

  isSignatureRequired: boolean;
  canBeSigned: boolean;
}

export interface QuotationVersionExtended extends QuotationVersion {
  devisor?: User;
}

const props: (keyof QuotationVersion)[] = [
  'version',
  'status',
  'date',
  'acceptanceDate',
  'paymentTerm',
  'downloadUriExcel',
  'rowsMigratedCount',
  'fullyMigrated',
  'discount',
  'quotation',
  'isSignatureRequired',
  'canBeSigned',
  'devisorId',
];
export const quotationVersionProps = new GraphSchema<QuotationVersion>(
  props.concat(billingItemProps)
);
