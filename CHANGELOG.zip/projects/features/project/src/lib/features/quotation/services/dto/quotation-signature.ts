import { GraphSchema } from '@camelot/server';

export interface QuotationSignature {
  link: string;
}

export const quotationSignatureProps = new GraphSchema<QuotationSignature>([
  'link',
]);
