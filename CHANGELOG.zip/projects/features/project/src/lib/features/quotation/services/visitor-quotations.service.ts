import { Injectable } from '@angular/core';

import { GraphEndpoint } from '@camelot/server';

import { IQuotationsService } from './IQuotationsService';
import { CamQuotationsService } from './quotations.service';

const graphEndpoint: GraphEndpoint = {
  clientName: 'quotationVisitorService',
  endpoint: 'quotation',
};

@Injectable({
  providedIn: 'root',
})
export class CamQuotationsVisitorService extends CamQuotationsService implements IQuotationsService {
  public clientName = graphEndpoint.clientName;

  constructor() {
    super();

    super.registerRoutes({ graphEndpoint: graphEndpoint }, { visitor: true });
  }
}
