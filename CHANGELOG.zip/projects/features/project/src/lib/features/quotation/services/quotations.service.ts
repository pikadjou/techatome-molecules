import { Injectable, inject } from '@angular/core';

import { combineLatest, filter, map, mergeMap, of, tap } from 'rxjs';

import { CamBaseService, GraphEndpoint, HandleComplexRequest, HandleSimpleRequest } from '@camelot/server';
import { CamUsersService } from '@camelot/user';
import { isNonNullable } from '@camelot/utils';

import { IQuotationsService } from './IQuotationsService';
import { RefusalInfos } from './dto/RefusalInfos';
import { Quotation, quotationProps } from './dto/quotation';
import { QuotationSignature } from './dto/quotation-signature';
import { QuotationRow, quotationRowProps } from './dto/row';
import { QuotationVersion, QuotationVersionExtended, quotationVersionProps } from './dto/version';
import { QUOTATION_VERSION_REFUSED, QUOTATION_VERSION_SIGNED, READ_QUOTATION_VERSION } from './mutations';
import {
  GET_QUOTATIONS,
  GET_QUOTATION_ROWS,
  GET_QUOTATION_SIGNATURE_LINK,
  GET_QUOTATION_VERSIONS,
  GET_VERSION_TENANT_ROUTE,
} from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'quotationService',
  endpoint: 'quotation',
};

@Injectable({
  providedIn: 'root',
})
export class CamQuotationsService extends CamBaseService implements IQuotationsService {
  protected _graphEndpoint = graphEndpoint;
  public quotationsByProject = new HandleComplexRequest<Quotation[]>();
  public quotationsByContact = new HandleComplexRequest<Quotation[]>();
  public quotations = new HandleSimpleRequest<Quotation[]>();
  public quotation = new HandleComplexRequest<Quotation>();
  public quotationRows = new HandleComplexRequest<QuotationRow[]>();
  public quotationParentRows = new HandleComplexRequest<QuotationRow[]>();
  public quotationSignature = new HandleComplexRequest<QuotationSignature>();

  public version = new HandleComplexRequest<QuotationVersionExtended>();
  public versions = new HandleSimpleRequest<QuotationVersion[]>();
  public versionsByQuotation = new HandleSimpleRequest<QuotationVersion[]>();
  public versionsByContact = new HandleSimpleRequest<QuotationVersion[]>();

  public tenantRoute = new HandleSimpleRequest<string>();

  private _usersService = inject(CamUsersService);

  constructor() {
    super();
    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public fetchQuotationsByProject$(projectId: string) {
    return this.quotationsByProject.fetch(
      projectId,
      this._graphService
        .fetchPagedQueryList<Quotation>(
          GET_QUOTATIONS(
            `where: { projectId: { eq: "${projectId}" } }`,
            `
          ${quotationProps.get('id')}
          ${quotationProps.get('name')}
          ${quotationProps.get('projectId')}
          ${quotationProps.get('tenantQuotationId')}
          ${quotationProps.get('status')}
          ${quotationProps.get('dueDate')}
          ${quotationProps.get('exclVatTotal')}
          ${quotationProps.get('inclVatTotal')}
          ${quotationProps.get('rowsCount')}
          ${quotationProps.get('rowsMigratedCount')}
          ${quotationProps.get('versions')} {
            ${quotationVersionProps.get('id')}
            ${quotationVersionProps.get('version')}
            ${quotationVersionProps.get('status')}
            ${quotationVersionProps.get('dueDate')}
            ${quotationVersionProps.get('exclVatTotal')}
            ${quotationVersionProps.get('inclVatTotal')}
            ${quotationVersionProps.get('isNew')}
          }
          `
          ),
          'filteredQuotations',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchQuotationsByContact$(contactId: string) {
    return this.quotationsByContact.fetch(
      contactId,
      this._graphService
        .fetchPagedQueryList<Quotation>(
          GET_QUOTATIONS(
            `where: { contactId: { eq: "${contactId}" } }`,
            `
            ${quotationProps.get('id')}
            ${quotationProps.get('name')}
            ${quotationProps.get('contactId')}
          `
          ),
          'filteredQuotations',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchQuotations$() {
    return this.quotations.fetch(
      this._graphService
        .fetchPagedQueryList<Quotation>(
          GET_QUOTATIONS(
            ``,
            `
            ${quotationProps.get('id')}
            ${quotationProps.get('name')}
            ${quotationProps.get('contactId')}
            ${quotationProps.get('projectId')}
          `
          ),
          'filteredQuotations',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchQuotation$(id: string) {
    return this.quotation.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<Quotation>(
          GET_QUOTATIONS(
            `where: { id: { eq: "${id}" } }`,
            `
            ${quotationProps.get('id')}
            ${quotationProps.get('name')}
            ${quotationProps.get('versions')} {
              ${quotationVersionProps.get('id')}
              ${quotationVersionProps.get('version')}
              ${quotationVersionProps.get('status')}
              ${quotationVersionProps.get('isNew')}
              ${quotationVersionProps.get('date')}
              ${quotationVersionProps.get('devisorId')}
            }
            `
          ),
          'filteredQuotations',
          graphEndpoint.clientName
        )
        .pipe(
          filter(isNonNullable),
          map(data => data.items),
          filter(isNonNullable),
          filter(items => items.length > 0),
          map(items => items[0])
        )
    );
  }

  public fetchQuotationRows$(versionId: string) {
    return this.quotationRows.fetch(
      versionId,
      this._graphService.fetchQuery<QuotationRow[]>(
        GET_QUOTATION_ROWS(
          `where: { documentIds: { any: true }, quotationVersionId: { eq: "${versionId}" } }`,
          `
            ${quotationRowProps.get('id')}
            ${quotationRowProps.get('description')}
            ${quotationRowProps.get('documentIds')}
          `
        ),
        'filteredQuotationRows',
        graphEndpoint.clientName
      )
    );
  }

  public fetchQuotationVersionsByContact$(contactId: string) {
    return this.versionsByContact.fetch(
      this._graphService
        .fetchPagedQueryList<QuotationVersion>(
          GET_QUOTATION_VERSIONS(
            `where: { quotation: { contactId: { eq: "${contactId}" } } }`,
            `
          ${quotationVersionProps.get('id')}
          ${quotationVersionProps.get('version')}
          ${quotationVersionProps.get('quotation')} {
            ${quotationProps.get('name')}
          }
          `
          ),
          'quotationVersions',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchQuotationVersions$() {
    return this.versions.fetch(
      this._graphService
        .fetchPagedQueryList<QuotationVersion>(
          GET_QUOTATION_VERSIONS(
            ``,
            `
            ${quotationVersionProps.get('id')}
            ${quotationVersionProps.get('version')}
            ${quotationVersionProps.get('status')}
            ${quotationVersionProps.get('description')}
            ${quotationVersionProps.get('date')}
            ${quotationVersionProps.get('dueDate')}
            ${quotationVersionProps.get('acceptanceDate')}
            ${quotationVersionProps.get('paymentTerm')}
            ${quotationVersionProps.get('downloadUriPDF')}
            ${quotationVersionProps.get('downloadUriExcel')}
            ${quotationVersionProps.get('devisorId')}
            ${quotationVersionProps.get('rowsCount')}
            ${quotationVersionProps.get('rowsMigratedCount')}
            ${quotationVersionProps.get('fullyMigrated')}
            ${quotationVersionProps.get('exclVatTotal')}
            ${quotationVersionProps.get('inclVatTotal')}
            ${quotationVersionProps.get('discount')}
            ${quotationVersionProps.get('isNew')}
            ${quotationVersionProps.get('isSignatureRequired')}
            ${quotationVersionProps.get('canBeSigned')}
            ${quotationVersionProps.get('quotation')} {
              ${quotationProps.get('id')}
              ${quotationProps.get('name')}
              ${quotationProps.get('tenantQuotationId')}
            }
          `
          ),
          'quotationVersions',
          graphEndpoint.clientName
        )
        .pipe(map(data => data.items ?? []))
    );
  }

  public fetchVersions$(ids: string[]) {
    return combineLatest(ids.map(id => this.fetchQuotationVersion$(id)));
  }

  public fetchQuotationVersion$(id: string) {
    return this.version.fetch(
      id,
      this._graphService
        .fetchPagedQueryList<QuotationVersionExtended>(
          GET_QUOTATION_VERSIONS(
            `where: { id: { eq: "${id}" }}`,
            `
            ${quotationVersionProps.get('id')}
            ${quotationVersionProps.get('version')}
            ${quotationVersionProps.get('status')}
            ${quotationVersionProps.get('description')}
            ${quotationVersionProps.get('date')}
            ${quotationVersionProps.get('dueDate')}
            ${quotationVersionProps.get('acceptanceDate')}
            ${quotationVersionProps.get('paymentTerm')}
            ${quotationVersionProps.get('downloadUriPDF')}
            ${quotationVersionProps.get('downloadUriExcel')}
            ${quotationVersionProps.get('devisorId')}
            ${quotationVersionProps.get('rowsCount')}
            ${quotationVersionProps.get('rowsMigratedCount')}
            ${quotationVersionProps.get('fullyMigrated')}
            ${quotationVersionProps.get('exclVatTotal')}
            ${quotationVersionProps.get('inclVatTotal')}
            ${quotationVersionProps.get('discount')}
            ${quotationVersionProps.get('isNew')}
            ${quotationVersionProps.get('isSignatureRequired')}
            ${quotationVersionProps.get('canBeSigned')}
            ${quotationVersionProps.get('quotation')} {
              ${quotationProps.get('id')}
              ${quotationProps.get('name')}
              ${quotationProps.get('projectId')}
            }
          `
          ),
          'quotationVersions',
          graphEndpoint.clientName
        )
        .pipe(
          filter(isNonNullable),
          map(data => (data.items ? data.items[0] : null)),
          filter(isNonNullable),
          mergeMap(entity => {
            if (entity.devisorId === null) {
              return of(entity);
            }
            return this._usersService.fetchUser$(entity.devisorId).pipe(
              map(data => ({
                ...entity,
                ...{ devisor: data },
              }))
            );
          })
        )
    );
  }

  public fetchQuotationVersionsByQuotation$(quotationId: string) {
    return this.versionsByQuotation.fetch(
      this._graphService.fetchQuery<QuotationVersion[]>(
        GET_QUOTATION_VERSIONS(
          `where: { quotation: { id: { eq: "${quotationId}" } }`,
          `
          ${quotationVersionProps.get('id')}
          ${quotationVersionProps.get('version')}
          ${quotationVersionProps.get('status')}
          ${quotationVersionProps.get('description')}
          ${quotationVersionProps.get('date')}
          ${quotationVersionProps.get('dueDate')}
          ${quotationVersionProps.get('acceptanceDate')}
          ${quotationVersionProps.get('paymentTerm')}
          ${quotationVersionProps.get('downloadUriPDF')}
          ${quotationVersionProps.get('downloadUriExcel')}
          ${quotationVersionProps.get('devisorId')}
          ${quotationVersionProps.get('rowsCount')}
          ${quotationVersionProps.get('rowsMigratedCount')}
          ${quotationVersionProps.get('fullyMigrated')}
          ${quotationVersionProps.get('exclVatTotal')}
          ${quotationVersionProps.get('inclVatTotal')}
          ${quotationVersionProps.get('discount')}
          ${quotationVersionProps.get('isNew')}
          ${quotationVersionProps.get('isSignatureRequired')}
          ${quotationVersionProps.get('canBeSigned')}
          ${quotationVersionProps.get('devisorId')}
          `
        ),
        'quotationVersions',
        graphEndpoint.clientName
      )
    );
  }

  public getVersions(ids: string[]) {
    return combineLatest(ids.map(id => this.version.get$(id)));
  }

  public fetchQuotationParentRows$(versionId: string) {
    return this.quotationParentRows.fetch(
      versionId,
      this._graphService
        .fetchPagedQueryList<QuotationRow>(
          GET_QUOTATION_ROWS(
            `where: { parent: { eq: null }, quotationVersionId: { eq: "${versionId}" } }`,
            `
            ${quotationRowProps.get('id')}
            ${quotationRowProps.get('index')}
            ${quotationRowProps.get('parent')}
            ${quotationRowProps.get('hidden')}
            ${quotationRowProps.get('rowType')}
            ${quotationRowProps.get('sourceRef')}
            ${quotationRowProps.get('description')}
            ${quotationRowProps.get('itemType')}
            ${quotationRowProps.get('quantity')}
            ${quotationRowProps.get('unit')}
            ${quotationRowProps.get('unitDescription')}
            ${quotationRowProps.get('unitSellingPrice')}
            ${quotationRowProps.get('vatPercentage')}
            ${quotationRowProps.get('exclVatTotal')}
            ${quotationRowProps.get('inclVatTotal')}
            ${quotationRowProps.get('chapterExclVatTotal')}
            ${quotationRowProps.get('chapterInclVatTotal')}
            ${quotationRowProps.get('childrenRowsCount')}
            ${quotationRowProps.get('documentIds')}
          `
          ),
          'filteredQuotationRows',
          graphEndpoint.clientName
        )
        .pipe(
          map(list => (list.items ? list.items : [])),
          map(list =>
            list.map(item => ({
              ...item,
              ...{ label: item.index.toString() },
            }))
          )
        )
    );
  }

  public fetchQuotationRowChildren$(parentId: string, parent?: QuotationRow) {
    return this.quotationParentRows.fetch(
      parentId,
      this._graphService
        .fetchPagedQueryList<QuotationRow>(
          GET_QUOTATION_ROWS(
            `where: { parent: { eq: "${parentId}" }}`,
            `
          ${quotationRowProps.get('id')}
          ${quotationRowProps.get('index')}
          ${quotationRowProps.get('parent')}
          ${quotationRowProps.get('hidden')}
          ${quotationRowProps.get('rowType')}
          ${quotationRowProps.get('sourceRef')}
          ${quotationRowProps.get('description')}
          ${quotationRowProps.get('itemType')}
          ${quotationRowProps.get('quantity')}
          ${quotationRowProps.get('unit')}
          ${quotationRowProps.get('unitDescription')}
          ${quotationRowProps.get('unitSellingPrice')}
          ${quotationRowProps.get('vatPercentage')}
          ${quotationRowProps.get('exclVatTotal')}
          ${quotationRowProps.get('inclVatTotal')}
          ${quotationRowProps.get('chapterExclVatTotal')}
          ${quotationRowProps.get('chapterInclVatTotal')}
          ${quotationRowProps.get('childrenRowsCount')}
          ${quotationRowProps.get('documentIds')}
        `
          ),
          'filteredQuotationRows',
          graphEndpoint.clientName
        )
        .pipe(
          map(list => (list.items ? list.items : [])),
          map(list =>
            list.map(item => ({
              ...item,
              ...{ label: `${parent?.label}.${item.index}` },
            }))
          )
        )
    );
  }

  public setQuotationVersionSigned$(quotationVersionId: string) {
    return this._graphService
      .mutate<QuotationVersion>(
        QUOTATION_VERSION_SIGNED(quotationVersionId),
        'quotationVersionSigned',
        graphEndpoint.clientName
      )
      .pipe(tap(version => this.version.update(quotationVersionId, version)));
  }

  public setQuotationVersionRefused$(quotationVersionId: string, refusalInfos: RefusalInfos) {
    return this._graphService
      .mutate<QuotationVersion>(
        QUOTATION_VERSION_REFUSED(quotationVersionId, refusalInfos),
        'quotationVersionRefused',
        graphEndpoint.clientName
      )
      .pipe(tap(version => this.version.update(quotationVersionId, version)));
  }

  public isRead$(id: string) {
    return this._graphService.mutate<boolean>(
      READ_QUOTATION_VERSION(id),
      'quotationVersionRead',
      graphEndpoint.clientName
    );
  }

  public getSignatureLink$(quotationVersionId: string, successUri: string, errorUri: string, declineUri: string) {
    return this.quotationSignature.fetch(
      quotationVersionId,
      this._graphService.fetchQuery<QuotationSignature>(
        GET_QUOTATION_SIGNATURE_LINK(quotationVersionId, successUri, errorUri, declineUri),
        'signatureLink',
        graphEndpoint.clientName
      )
    );
  }

  public getVersionsLightInfo$(ids: string[]) {
    return this._graphService
      .fetchPagedQueryList<QuotationVersion>(
        GET_QUOTATION_VERSIONS(
          `where: { id: { in: [${ids.map(id => `"${id}"`).join(', ')}] } }`,
          `
            ${quotationVersionProps.get('id')}
            ${quotationVersionProps.get('version')}
            ${quotationVersionProps.get('quotation')} {
              ${quotationProps.get('name')}
              ${quotationProps.get('id')}
            }
          `
        ),
        'quotationVersions',
        graphEndpoint.clientName
      )
      .pipe(map(data => data.items ?? []));
  }

  public fetchVersionTenantRoute$(versionId: string) {
    return this.tenantRoute.fetch(
      this._graphService
        .fetchQuery<string>(
          GET_VERSION_TENANT_ROUTE(versionId),
          'quotationVersionTenantRoute',
          graphEndpoint.clientName
        )
        .pipe(filter(isNonNullable))
    );
  }
}
