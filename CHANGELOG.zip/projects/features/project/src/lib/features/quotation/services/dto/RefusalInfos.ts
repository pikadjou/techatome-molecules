export type RefusalInfos = { reason: number; content: string };
