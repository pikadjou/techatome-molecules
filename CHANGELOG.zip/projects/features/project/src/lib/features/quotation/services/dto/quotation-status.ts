export enum QuotationStatus {
  Unknown = 0,
  Sent = 1,
  Signed = 2,

  Expired = 10,
  Refused = 11,
  Canceled = 12,
}
