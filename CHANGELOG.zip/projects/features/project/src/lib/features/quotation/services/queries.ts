import { Apollo_gql, GraphQueryPayload, graphQlTake } from '@camelot/server';

import { quotationSignatureProps } from './dto/quotation-signature';

export function GET_QUOTATIONS(where: string, props: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query FilteredQuotations {
        filteredQuotations(${where}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_QUOTATION_ROWS(where: string, props: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
        query FilteredQuotationRows {
          filteredQuotationRows(${where}, ${graphQlTake()}) {
            items {
              ${props}
            }
          }
        }
    `,
    variables: {},
  };
}

export function GET_QUOTATION_VERSIONS(where: string, props: string, take?: number): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query QuotationVersions {
        quotationVersions(${where}, ${graphQlTake(take)}) {
          items {
            ${props}
          }
        }
      }
    `,
    variables: {},
  };
}

export function GET_QUOTATION_SIGNATURE_LINK(
  quotationVersionId: string,
  successUri: string,
  errorUri: string,
  declineUri: string
): GraphQueryPayload {
  return {
    query: Apollo_gql`
      query signatureLink($quotationVersionId: UUID!, $successUri: URL, $errorUri: URL, $declineUri: URL) {
        signatureLink(quotationVersionId: $quotationVersionId, successUri: $successUri, errorUri: $errorUri, declineUri: $declineUri) {
          ${quotationSignatureProps.get('link')}
        }
      }
    `,
    variables: {
      quotationVersionId: quotationVersionId,
      successUri: successUri,
      errorUri: errorUri,
      declineUri: declineUri,
    },
  };
}

export function GET_VERSION_TENANT_ROUTE(quotationId: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
        query QuotationVersionTenantRoute($quotationId: UUID!) {
          quotationVersionTenantRoute(quotationId: $quotationId)
        }
      `,
    variables: {
      quotationId: quotationId,
    },
  };
}
