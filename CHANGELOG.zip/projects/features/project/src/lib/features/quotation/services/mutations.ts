import { Apollo_gql, GraphMutationPayload } from '@camelot/server';

import { RefusalInfos } from './dto/RefusalInfos';
import { quotationVersionProps } from './dto/version';

export function READ_QUOTATION_VERSION(id: string): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
      mutation QuotationVersionRead($id: UUID!) {
        quotationVersionRead(quotationVersionId: $id) {
          ${quotationVersionProps.get('id')}
          ${quotationVersionProps.get('isNew')}
        }
      }
    `,
    variables: {
      id,
    },
  };
}

export function QUOTATION_VERSION_REFUSED(
  quotationVersionId: string,
  refusalInfos: RefusalInfos
): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
        mutation QuotationVersionRefused($quotationVersionId: UUID!, $reason: Int!, $content: String!) {
            quotationVersionRefused(quotationVersionId: $quotationVersionId, refusalInfos: { reason: $reason, comment: $content }) {
                ${quotationVersionProps.get('id')}
                ${quotationVersionProps.get('status')}
            }
        }
      `,
    variables: {
      quotationVersionId,
      reason: refusalInfos.reason,
      content: refusalInfos.content,
    },
  };
}

export function QUOTATION_VERSION_SIGNED(
  quotationVersionId: string
): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
        mutation QuotationVersionRefused($quotationVersionId: UUID!) {
            quotationVersionSigned(quotationVersionId: $quotationVersionId) {
                ${quotationVersionProps.get('id')}
                ${quotationVersionProps.get('status')}
            }
        }
      `,
    variables: {
      quotationVersionId,
    },
  };
}
