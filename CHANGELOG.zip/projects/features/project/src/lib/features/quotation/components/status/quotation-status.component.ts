import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

import { ColorType } from '@camelot/styles';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';
import { CamBaseComponent, CamDirectivePipeModule } from '@camelot/utils';

import { QuotationStatus } from '../../services/dto/quotation-status';

@Component({
  selector: 'cam-quotation-status',
  templateUrl: './quotation-status.component.html',
  styleUrls: ['./quotation-status.component.scss'],
  standalone: true,
  imports: [CamUiModule, CamDirectivePipeModule, CommonModule, TranslatePipe],
})
export class CamQuotationStatusComponent extends CamBaseComponent {
  @Input()
  status!: QuotationStatus;

  get color(): ColorType {
    switch (this.status) {
      case QuotationStatus.Signed:
        return 'success';
      case QuotationStatus.Refused:
        return 'purple';
      case QuotationStatus.Sent:
        return 'default';
      case QuotationStatus.Canceled:
        return 'secondary';
      case QuotationStatus.Expired:
        return 'secondary';
      default:
        return 'purple';
    }
  }

  get label(): string {
    const statusKey = QuotationStatus[Number(this.status)];
    return `quotation.status.${statusKey?.toLowerCase() ?? 'unknown'}`;
  }
}
