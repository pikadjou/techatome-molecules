export enum ERefusalReason {
  Unknown = 0,
  TooExpensive = 1,
  ProjectPostposed = 2,
  ProjectCanceled = 3,
  SignedWithCompetitor = 4,
  Other = 5,
}
