export enum RowType {
  Unknown = 0,
  Chapter = 1,
  Item = 2,
  Comment = 3,
}
