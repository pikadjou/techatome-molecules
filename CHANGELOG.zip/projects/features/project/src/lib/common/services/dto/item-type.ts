export enum ItemType {
  Unknown = 0,
  Normal = 1,
  Variant = 2,
  Options = 3,
  Omission = 4,
  Reduction = 5,
}
