/*
 * Public API Surface of cms
 */

export * from './lib/modules/strapi/public-api';
