# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [3.16.0-beta.4](https://dev.azure.com/compare/v3.16.0-beta.3...v3.16.0-beta.4) (2025-06-10)

**Note:** Version bump only for package @camelot/cms





# [3.16.0-beta.3](https://dev.azure.com/compare/v3.16.0-beta.2...v3.16.0-beta.3) (2025-06-05)

**Note:** Version bump only for package @camelot/cms





# [3.16.0-beta.2](https://dev.azure.com/compare/v3.16.0-beta.1...v3.16.0-beta.2) (2025-06-04)

**Note:** Version bump only for package @camelot/cms





# [3.16.0-beta.1](https://dev.azure.com/compare/v3.16.0-beta.0...v3.16.0-beta.1) (2025-06-04)

**Note:** Version bump only for package @camelot/cms





# [3.16.0-beta.0](https://dev.azure.com/compare/v3.15.1-beta.1...v3.16.0-beta.0) (2025-06-04)

**Note:** Version bump only for package @camelot/cms





## [3.15.1-beta.1](https://dev.azure.com/compare/v3.15.1-beta.0...v3.15.1-beta.1) (2025-05-27)

**Note:** Version bump only for package @camelot/cms





## [3.15.1-beta.0](https://dev.azure.com/compare/v3.15.0...v3.15.1-beta.0) (2025-05-26)

**Note:** Version bump only for package @camelot/cms





# [3.15.0](https://dev.azure.com/compare/v3.15.0-beta.7...v3.15.0) (2025-05-22)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.7](https://dev.azure.com/compare/v3.15.0-beta.6...v3.15.0-beta.7) (2025-05-22)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.6](https://dev.azure.com/compare/v3.15.0-beta.5...v3.15.0-beta.6) (2025-05-22)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.5](https://dev.azure.com/compare/v3.15.0-beta.4...v3.15.0-beta.5) (2025-05-21)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.4](https://dev.azure.com/compare/v3.15.0-beta.3...v3.15.0-beta.4) (2025-05-21)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.3](https://dev.azure.com/compare/v3.15.0-beta.2...v3.15.0-beta.3) (2025-05-21)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.2](https://dev.azure.com/compare/v3.15.0-beta.1...v3.15.0-beta.2) (2025-05-21)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.1](https://dev.azure.com/compare/v3.15.0-beta.0...v3.15.0-beta.1) (2025-05-15)

**Note:** Version bump only for package @camelot/cms





# [3.15.0-beta.0](https://dev.azure.com/compare/v3.14.0...v3.15.0-beta.0) (2025-05-07)

**Note:** Version bump only for package @camelot/cms





# [3.14.0](https://dev.azure.com/compare/v3.14.0-beta.10...v3.14.0) (2025-05-06)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.10](https://dev.azure.com/compare/v3.14.0-beta.9...v3.14.0-beta.10) (2025-04-29)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.9](https://dev.azure.com/compare/v3.14.0-beta.8...v3.14.0-beta.9) (2025-04-28)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.8](https://dev.azure.com/compare/v3.14.0-beta.7...v3.14.0-beta.8) (2025-04-25)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.7](https://dev.azure.com/compare/v3.14.0-beta.6...v3.14.0-beta.7) (2025-04-25)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.6](https://dev.azure.com/compare/v3.14.0-beta.5...v3.14.0-beta.6) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.5](https://dev.azure.com/compare/v3.14.0-beta.4...v3.14.0-beta.5) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.4](https://dev.azure.com/compare/v3.14.0-beta.3...v3.14.0-beta.4) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.3](https://dev.azure.com/compare/v3.14.0-beta.2...v3.14.0-beta.3) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.2](https://dev.azure.com/compare/v3.14.0-beta.1...v3.14.0-beta.2) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.1](https://dev.azure.com/compare/v3.14.0-beta.0...v3.14.0-beta.1) (2025-04-24)

**Note:** Version bump only for package @camelot/cms





# [3.14.0-beta.0](https://dev.azure.com/compare/v3.13.1-beta.2...v3.14.0-beta.0) (2025-04-17)

**Note:** Version bump only for package @camelot/cms





## [3.13.1-beta.2](https://dev.azure.com/compare/v3.13.1-beta.1...v3.13.1-beta.2) (2025-04-16)

**Note:** Version bump only for package @camelot/cms





## [3.13.1-beta.1](https://dev.azure.com/compare/v3.13.1-beta.0...v3.13.1-beta.1) (2025-04-16)

**Note:** Version bump only for package @camelot/cms





## [3.13.1-beta.0](https://dev.azure.com/compare/v3.13.0...v3.13.1-beta.0) (2025-04-11)

**Note:** Version bump only for package @camelot/cms





# [3.13.0](https://dev.azure.com/compare/v3.13.0-beta.5...v3.13.0) (2025-04-11)



## [3.12.4](https://dev.azure.com/compare/v3.12.3-beta.0...v3.12.4) (2025-04-08)



## [3.12.3](https://dev.azure.com/compare/v3.12.1...v3.12.3) (2025-04-04)

**Note:** Version bump only for package @camelot/cms





# [3.13.0-beta.5](https://dev.azure.com/compare/v3.13.0-beta.4...v3.13.0-beta.5) (2025-04-11)

**Note:** Version bump only for package @camelot/cms

# [3.13.0-beta.4](https://dev.azure.com/compare/v3.13.0-beta.3...v3.13.0-beta.4) (2025-04-11)

**Note:** Version bump only for package @camelot/cms

# [3.13.0-beta.3](https://dev.azure.com/compare/v3.13.0-beta.2...v3.13.0-beta.3) (2025-04-11)

**Note:** Version bump only for package @camelot/cms

# [3.13.0-beta.2](https://dev.azure.com/compare/v3.13.0-beta.1...v3.13.0-beta.2) (2025-04-11)

**Note:** Version bump only for package @camelot/cms

# [3.13.0-beta.1](https://dev.azure.com/compare/v3.13.0-beta.0...v3.13.0-beta.1) (2025-04-11)

**Note:** Version bump only for package @camelot/cms

# [3.13.0-beta.0](https://dev.azure.com/compare/v3.12.3-beta.0...v3.13.0-beta.0) (2025-04-09)

**Note:** Version bump only for package @camelot/cms

## [3.12.3-beta.0](https://dev.azure.com/compare/v3.12.1...v3.12.3-beta.0) (2025-04-04)

## [3.12.1-beta.0](https://dev.azure.com/compare/v3.12.0...v3.12.1-beta.0) (2025-04-03)

**Note:** Version bump only for package @camelot/cms

## [3.12.2](https://dev.azure.com/compare/v3.12.1...v3.12.2) (2025-04-04)

**Note:** Version bump only for package @camelot/cms

## [3.12.1](https://dev.azure.com/compare/v3.12.0...v3.12.1) (2025-04-04)

**Note:** Version bump only for package @camelot/cms

# [3.12.0](https://dev.azure.com/compare/v3.12.0-beta.3...v3.12.0) (2025-04-03)

**Note:** Version bump only for package @camelot/cms

# [3.12.0-beta.3](https://dev.azure.com/compare/v3.12.0-beta.2...v3.12.0-beta.3) (2025-04-03)

**Note:** Version bump only for package @camelot/cms

# [3.12.0-beta.2](https://dev.azure.com/compare/v3.12.0-beta.1...v3.12.0-beta.2) (2025-04-03)

**Note:** Version bump only for package @camelot/cms

# [3.12.0-beta.1](https://dev.azure.com/compare/v3.12.0-beta.0...v3.12.0-beta.1) (2025-04-03)

**Note:** Version bump only for package @camelot/cms

# [3.12.0-beta.0](https://dev.azure.com/compare/v3.11.1-beta.0...v3.12.0-beta.0) (2025-04-02)

**Note:** Version bump only for package @camelot/cms

## [3.11.1-beta.0](https://dev.azure.com/compare/v3.11.0...v3.11.1-beta.0) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0](https://dev.azure.com/compare/v3.11.0-beta.8...v3.11.0) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.8](https://dev.azure.com/compare/v3.11.0-beta.7...v3.11.0-beta.8) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.7](https://dev.azure.com/compare/v3.11.0-beta.6...v3.11.0-beta.7) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.6](https://dev.azure.com/compare/v3.11.0-beta.5...v3.11.0-beta.6) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.5](https://dev.azure.com/compare/v3.11.0-beta.4...v3.11.0-beta.5) (2025-04-01)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.4](https://dev.azure.com/compare/v3.11.0-beta.3...v3.11.0-beta.4) (2025-03-27)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.3](https://dev.azure.com/compare/v3.11.0-beta.2...v3.11.0-beta.3) (2025-03-26)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.2](https://dev.azure.com/compare/v3.11.0-beta.1...v3.11.0-beta.2) (2025-03-26)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.1](https://dev.azure.com/compare/v3.11.0-beta.0...v3.11.0-beta.1) (2025-03-25)

**Note:** Version bump only for package @camelot/cms

# [3.11.0-beta.0](https://dev.azure.com/compare/v3.10.2-beta.0...v3.11.0-beta.0) (2025-03-24)

**Note:** Version bump only for package @camelot/cms

## [3.10.2-beta.0](https://dev.azure.com/compare/v3.10.1-beta.1...v3.10.2-beta.0) (2025-03-20)

## [3.10.1](https://dev.azure.com/compare/v3.10.1-beta.0...v3.10.1) (2025-03-19)

**Note:** Version bump only for package @camelot/cms

## [3.10.1](https://dev.azure.com/compare/v3.10.0...v3.10.1) (2025-03-19)

**Note:** Version bump only for package @camelot/cms

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.10.0-beta.2](https://dev.azure.com/compare/v3.10.0-beta.1...v3.10.0-beta.2) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.10.0-beta.1](https://dev.azure.com/compare/v3.10.0-beta.0...v3.10.0-beta.1) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.10.0-beta.0](https://dev.azure.com/compare/v3.9.1-beta.0...v3.10.0-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

## [3.9.1-beta.0](https://dev.azure.com/compare/v3.9.0...v3.9.1-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.9.0](https://dev.azure.com/compare/v3.9.0-beta.2...v3.9.0) (2025-03-05)

**Note:** Version bump only for package @camelot/cms

# [3.9.0-beta.2](https://dev.azure.com/compare/v3.9.0-beta.1...v3.9.0-beta.2) (2025-03-04)

**Note:** Version bump only for package @camelot/cms

# [3.9.0-beta.1](https://dev.azure.com/compare/v3.9.0-beta.0...v3.9.0-beta.1) (2025-03-04)

**Note:** Version bump only for package @camelot/cms

# [3.9.0-beta.0](https://dev.azure.com/compare/v3.8.1-beta.0...v3.9.0-beta.0) (2025-03-04)

**Note:** Version bump only for package @camelot/cms

## [3.8.1-beta.0](https://dev.azure.com/compare/v3.8.0...v3.8.1-beta.0) (2025-03-03)

**Note:** Version bump only for package @camelot/cms

# [3.8.0](https://dev.azure.com/compare/v3.8.0-beta.6...v3.8.0) (2025-03-01)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.6](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.6) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.5](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.5) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.4](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.4) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.3](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.3) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.2](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.2) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.1](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.1) (2025-02-28)

**Note:** Version bump only for package @camelot/cms

# [3.8.0-beta.0](https://dev.azure.com/compare/v3.7.1-beta.6...v3.8.0-beta.0) (2025-02-27)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.10](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.10) (2025-02-26)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.9](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.9) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.8](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.8) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.7](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.7) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.6](https://dev.azure.com/compare/v3.7.1-beta.5...v3.7.1-beta.6) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.5](https://dev.azure.com/compare/v3.7.1-beta.4...v3.7.1-beta.5) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.4](https://dev.azure.com/compare/v3.7.1-beta.3...v3.7.1-beta.4) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.3](https://dev.azure.com/compare/v3.7.1-beta.2...v3.7.1-beta.3) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.2](https://dev.azure.com/compare/v3.7.1-beta.1...v3.7.1-beta.2) (2025-02-25)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.1](https://dev.azure.com/compare/v3.7.1-beta.0...v3.7.1-beta.1) (2025-02-24)

**Note:** Version bump only for package @camelot/cms

## [3.7.1-beta.0](https://dev.azure.com/compare/v3.7.0...v3.7.1-beta.0) (2025-02-24)

**Note:** Version bump only for package @camelot/cms

# [3.7.0](https://dev.azure.com/compare/v3.5.0-beta.4...v3.7.0) (2025-02-24)

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0-beta.1](https://dev.azure.com/compare/v3.5.0-beta.0...v3.5.0-beta.1) (2025-02-20)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/cms

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/cms

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/cms

# [3.4.0](https://dev.azure.com/compare/v3.3.0...v3.4.0) (2025-02-19)

**Note:** Version bump only for package @camelot/cms

# [3.3.0](https://dev.azure.com/compare/v3.3.0-beta.2...v3.3.0) (2025-02-18)

**Note:** Version bump only for package @camelot/cms

# [3.3.0-beta.2](https://dev.azure.com/compare/v3.3.0-beta.1...v3.3.0-beta.2) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/cms

## [3.2.5-beta.0](https://dev.azure.com/compare/v3.3.0-beta.1...v3.2.5-beta.0) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/cms

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/cms

## [3.2.3](https://dev.azure.com/compare/v3.2.1...v3.2.3) (2025-02-17)

**Note:** Version bump only for package @camelot/cms

# [3.3.0-beta.0](https://dev.azure.com/compare/v3.2.4-beta.0...v3.3.0-beta.0) (2025-02-17)

# [3.2.0-beta.0](https://dev.azure.com/compare/v3.1.1-beta.4...v3.2.0-beta.0) (2025-02-13)

**Note:** Version bump only for package @camelot/cms

## [3.2.4-beta.0](https://dev.azure.com/compare/v3.2.1...v3.2.4-beta.0) (2025-02-17)

## [3.2.1-beta.0](https://dev.azure.com/compare/v3.2.0...v3.2.1-beta.0) (2025-02-17)

**Note:** Version bump only for package @camelot/cms

# [3.2.0-beta.1](https://dev.azure.com/compare/v3.1.1-beta.7...v3.2.0-beta.1) (2025-02-14)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.7](https://dev.azure.com/compare/v3.1.1-beta.6...v3.1.1-beta.7) (2025-02-14)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.6](https://dev.azure.com/compare/v3.1.1-beta.5...v3.1.1-beta.6) (2025-02-13)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.5](https://dev.azure.com/compare/v3.1.1-beta.4...v3.1.1-beta.5) (2025-02-13)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.4](https://dev.azure.com/compare/v3.1.1-beta.3...v3.1.1-beta.4) (2025-02-12)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.3](https://dev.azure.com/compare/v3.1.1-beta.2...v3.1.1-beta.3) (2025-02-11)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.2](https://dev.azure.com/compare/v3.1.1...v3.1.1-beta.2) (2025-02-06)

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/cms

## [3.1.1-beta.0](https://dev.azure.com/compare/v3.1.0...v3.1.1-beta.0) (2025-02-06)

**Note:** Version bump only for package @camelot/cms

# [3.1.0](https://dev.azure.com/compare/v3.1.0-beta.12...v3.1.0) (2025-02-06)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.12](https://dev.azure.com/compare/v2.14.0-beta.1...v3.1.0-beta.12) (2025-02-06)

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

## [3.0.2](https://dev.azure.com/compare/v3.0.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.11](https://dev.azure.com/compare/v3.1.0-beta.10...v3.1.0-beta.11) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.10](https://dev.azure.com/compare/v3.1.0-beta.9...v3.1.0-beta.10) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.9](https://dev.azure.com/compare/v3.1.0-beta.8...v3.1.0-beta.9) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.8](https://dev.azure.com/compare/v3.1.0-beta.7...v3.1.0-beta.8) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.7](https://dev.azure.com/compare/v3.1.0-beta.6...v3.1.0-beta.7) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.6](https://dev.azure.com/compare/v3.1.0-beta.5...v3.1.0-beta.6) (2025-02-05)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.5](https://dev.azure.com/compare/v3.1.0-beta.4...v3.1.0-beta.5) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.4](https://dev.azure.com/compare/v3.1.0-beta.3...v3.1.0-beta.4) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

## [3.0.3](https://dev.azure.com/compare/v3.0.2...v3.0.3) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

## [3.0.2](https://dev.azure.com/compare/v2.13.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

## [3.0.1](https://dev.azure.com/compare/v2.13.1...v3.0.1) (2025-02-04)

**Note:** Version bump only for package @camelot/cms

## [2.13.1](https://dev.azure.com/compare/v2.13.1-beta.10...v2.13.1) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.10](https://dev.azure.com/compare/v2.13.1-beta.9...v2.13.1-beta.10) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.9](https://dev.azure.com/compare/v2.13.1-beta.8...v2.13.1-beta.9) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.8](https://dev.azure.com/compare/v2.13.1-beta.7...v2.13.1-beta.8) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.7](https://dev.azure.com/compare/v2.13.1-beta.6...v2.13.1-beta.7) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.6](https://dev.azure.com/compare/v2.13.1-beta.5...v2.13.1-beta.6) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.5](https://dev.azure.com/compare/v2.13.1-beta.4...v2.13.1-beta.5) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.4](https://dev.azure.com/compare/v2.13.1-beta.3...v2.13.1-beta.4) (2025-01-28)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.3](https://dev.azure.com/compare/v2.13.1-beta.2...v2.13.1-beta.3) (2025-01-27)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.2](https://dev.azure.com/compare/v2.13.1-beta.1...v2.13.1-beta.2) (2025-01-27)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.1](https://dev.azure.com/compare/v2.13.1-beta.0...v2.13.1-beta.1) (2025-01-27)

**Note:** Version bump only for package @camelot/cms

## [2.13.1-beta.0](https://dev.azure.com/compare/v2.13.0...v2.13.1-beta.0) (2025-01-23)

**Note:** Version bump only for package @camelot/cms

# [2.13.0](https://dev.azure.com/compare/v2.12.9-beta.4...v2.13.0) (2025-01-23)

**Note:** Version bump only for package @camelot/cms

## [2.12.9-beta.4](https://dev.azure.com/compare/v2.12.9-beta.3...v2.12.9-beta.4) (2025-01-23)

**Note:** Version bump only for package @camelot/cms

## [2.12.9-beta.3](https://dev.azure.com/compare/v2.12.9-beta.2...v2.12.9-beta.3) (2025-01-23)

**Note:** Version bump only for package @camelot/cms

## [2.12.9-beta.2](https://dev.azure.com/compare/v2.12.9-beta.1...v2.12.9-beta.2) (2025-01-23)

**Note:** Version bump only for package @camelot/cms

## [2.12.9-beta.1](https://dev.azure.com/compare/v2.12.9-beta.0...v2.12.9-beta.1) (2025-01-21)

**Note:** Version bump only for package @camelot/cms

## [2.12.9-beta.0](https://dev.azure.com/compare/v2.12.8...v2.12.9-beta.0) (2025-01-21)

**Note:** Version bump only for package @camelot/cms

## [2.12.8](https://dev.azure.com/compare/v2.12.8-beta.1...v2.12.8) (2025-01-21)

**Note:** Version bump only for package @camelot/cms

## [2.12.8-beta.1](https://dev.azure.com/compare/v2.12.8-beta.0...v2.12.8-beta.1) (2025-01-20)

**Note:** Version bump only for package @camelot/cms

## [2.12.8-beta.0](https://dev.azure.com/compare/v2.13.0-beta.0...v2.12.8-beta.0) (2025-01-20)

## [2.12.7](https://dev.azure.com/compare/v2.12.5...v2.12.7) (2025-01-17)

## [2.12.4](https://dev.azure.com/compare/v2.12.4-beta.0...v2.12.4) (2025-01-17)

**Note:** Version bump only for package @camelot/cms

## [2.12.7](https://dev.azure.com/compare/v2.12.5...v2.12.7) (2025-01-17)

**Note:** Version bump only for package @camelot/cms

## [2.12.6](https://dev.azure.com/compare/v2.12.5...v2.12.6) (2025-01-17)

**Note:** Version bump only for package @camelot/cms

## [2.12.4](https://dev.azure.com/compare/v2.12.3...v2.12.4) (2025-01-17)

**Note:** Version bump only for package @camelot/cms

## [2.12.3](https://dev.azure.com/compare/v2.12.1...v2.12.3) (2025-01-17)

**Note:** Version bump only for package @camelot/cms

## [2.12.2](https://dev.azure.com/compare/v2.12.0...v2.12.2) (2025-01-16)

**Note:** Version bump only for package @camelot/cms

## [2.12.1](https://dev.azure.com/compare/v2.12.0...v2.12.1) (2025-01-16)

**Note:** Version bump only for package @camelot/cms

# [2.12.0](https://dev.azure.com/compare/v2.12.0-beta.5...v2.12.0) (2025-01-16)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.5](https://dev.azure.com/compare/v2.12.0-beta.4...v2.12.0-beta.5) (2025-01-16)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.4](https://dev.azure.com/compare/v2.12.0-beta.3...v2.12.0-beta.4) (2025-01-16)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.3](https://dev.azure.com/compare/v2.12.0-beta.2...v2.12.0-beta.3) (2025-01-15)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.2](https://dev.azure.com/compare/v2.12.0-beta.1...v2.12.0-beta.2) (2025-01-15)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.1](https://dev.azure.com/compare/v2.12.0-beta.0...v2.12.0-beta.1) (2025-01-15)

**Note:** Version bump only for package @camelot/cms

# [2.12.0-beta.0](https://dev.azure.com/compare/v2.11.1-beta.0...v2.12.0-beta.0) (2025-01-10)

**Note:** Version bump only for package @camelot/cms

## [2.11.1-beta.0](https://dev.azure.com/compare/v2.11.0-beta.3...v2.11.1-beta.0) (2025-01-10)

# [2.11.0](https://dev.azure.com/compare/v2.11.0-beta.0...v2.11.0) (2025-01-09)

**Note:** Version bump only for package @camelot/cms

# [2.11.0](https://dev.azure.com/compare/v2.11.0-beta.0...v2.11.0) (2025-01-09)

**Note:** Version bump only for package @camelot/cms

# [2.11.0-beta.0](https://dev.azure.com/compare/v2.10.2-beta.2...v2.11.0-beta.0) (2025-01-07)

**Note:** Version bump only for package @camelot/cms

## [2.10.2-beta.2](https://dev.azure.com/compare/v2.10.2-beta.1...v2.10.2-beta.2) (2024-12-13)

**Note:** Version bump only for package @camelot/cms

## [2.10.2-beta.1](https://dev.azure.com/compare/v2.10.2-beta.0...v2.10.2-beta.1) (2024-12-12)

**Note:** Version bump only for package @camelot/cms

## [2.10.2-beta.0](https://dev.azure.com/compare/v2.10.0-beta.13...v2.10.2-beta.0) (2024-12-11)

## [2.10.1](https://dev.azure.com/compare/v2.10.0-beta.12...v2.10.1) (2024-12-10)

**Note:** Version bump only for package @camelot/cms

## [2.10.1](https://dev.azure.com/compare/v2.10.0-beta.11...v2.10.1) (2024-12-10)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.11](https://dev.azure.com/compare/v2.10.0-beta.10...v2.10.0-beta.11) (2024-12-10)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.10](https://dev.azure.com/compare/v2.10.0-beta.9...v2.10.0-beta.10) (2024-12-10)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.9](https://dev.azure.com/compare/v2.10.0-beta.8...v2.10.0-beta.9) (2024-12-04)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.8](https://dev.azure.com/compare/v2.10.0-beta.7...v2.10.0-beta.8) (2024-12-04)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.7](https://dev.azure.com/compare/v2.10.0-beta.6...v2.10.0-beta.7) (2024-12-04)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.6](https://dev.azure.com/compare/v2.10.0-beta.5...v2.10.0-beta.6) (2024-12-04)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.5](https://dev.azure.com/compare/v2.10.0-beta.4...v2.10.0-beta.5) (2024-11-29)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.4](https://dev.azure.com/compare/v2.10.0-beta.3...v2.10.0-beta.4) (2024-11-28)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.3](https://dev.azure.com/compare/v2.10.0-beta.2...v2.10.0-beta.3) (2024-11-27)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.2](https://dev.azure.com/compare/v2.10.0-beta.1...v2.10.0-beta.2) (2024-11-26)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.1](https://dev.azure.com/compare/v2.10.0-beta.0...v2.10.0-beta.1) (2024-11-26)

**Note:** Version bump only for package @camelot/cms

# [2.10.0-beta.0](https://dev.azure.com/compare/v2.9.1-beta.1...v2.10.0-beta.0) (2024-11-22)

**Note:** Version bump only for package @camelot/cms

## [2.9.1-beta.1](https://dev.azure.com/compare/v2.9.1-beta.0...v2.9.1-beta.1) (2024-11-22)

**Note:** Version bump only for package @camelot/cms

## [2.9.1-beta.0](https://dev.azure.com/compare/v2.9.0...v2.9.1-beta.0) (2024-11-21)

**Note:** Version bump only for package @camelot/cms

# [2.9.0](https://dev.azure.com/compare/v2.9.0-beta.7...v2.9.0) (2024-11-21)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.7](https://dev.azure.com/compare/v2.9.0-beta.6...v2.9.0-beta.7) (2024-11-21)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.6](https://dev.azure.com/compare/v2.9.0-beta.5...v2.9.0-beta.6) (2024-11-21)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.5](https://dev.azure.com/compare/v2.9.0-beta.4...v2.9.0-beta.5) (2024-11-21)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.4](https://dev.azure.com/compare/v2.9.0-beta.3...v2.9.0-beta.4) (2024-11-20)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.3](https://dev.azure.com/compare/v2.9.0-beta.2...v2.9.0-beta.3) (2024-11-19)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.2](https://dev.azure.com/compare/v2.9.0-beta.1...v2.9.0-beta.2) (2024-11-19)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.1](https://dev.azure.com/compare/v2.9.0-beta.0...v2.9.0-beta.1) (2024-11-15)

**Note:** Version bump only for package @camelot/cms

# [2.9.0-beta.0](https://dev.azure.com/compare/v2.8.7-beta.0...v2.9.0-beta.0) (2024-11-14)

**Note:** Version bump only for package @camelot/cms

## [2.8.7-beta.0](https://dev.azure.com/compare/v2.8.6...v2.8.7-beta.0) (2024-11-13)

**Note:** Version bump only for package @camelot/cms

## [2.8.6](https://dev.azure.com/compare/v2.8.4...v2.8.6) (2024-11-13)

**Note:** Version bump only for package @camelot/cms

## [2.8.5](https://dev.azure.com/compare/v2.8.4...v2.8.5) (2024-11-13)

**Note:** Version bump only for package @camelot/cms

## [2.8.3](https://dev.azure.com/compare/v2.8.1...v2.8.3) (2024-11-13)

**Note:** Version bump only for package @camelot/cms

## [2.8.2](https://dev.azure.com/compare/v2.8.1...v2.8.2) (2024-11-13)

**Note:** Version bump only for package @camelot/cms

# [2.8.0](https://dev.azure.com/compare/v2.8.0-beta.16...v2.8.0) (2024-11-12)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.16](https://dev.azure.com/compare/v2.8.0-beta.15...v2.8.0-beta.16) (2024-11-12)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.15](https://dev.azure.com/compare/v2.8.0-beta.14...v2.8.0-beta.15) (2024-11-08)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.14](https://dev.azure.com/compare/v2.8.0-beta.13...v2.8.0-beta.14) (2024-11-08)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.13](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.13) (2024-11-07)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.12](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.12) (2024-11-07)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.11](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.11) (2024-11-07)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.10](https://dev.azure.com/compare/v2.8.0-beta.9...v2.8.0-beta.10) (2024-10-31)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.9](https://dev.azure.com/compare/v2.8.0-beta.8...v2.8.0-beta.9) (2024-10-30)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.8](https://dev.azure.com/compare/v2.8.0-beta.7...v2.8.0-beta.8) (2024-10-30)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.7](https://dev.azure.com/compare/v2.8.0-beta.6...v2.8.0-beta.7) (2024-10-30)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.6](https://dev.azure.com/compare/v2.8.0-beta.5...v2.8.0-beta.6) (2024-10-29)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.5](https://dev.azure.com/compare/v2.8.0-beta.4...v2.8.0-beta.5) (2024-10-25)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.4](https://dev.azure.com/compare/v2.8.0-beta.3...v2.8.0-beta.4) (2024-10-24)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.3](https://dev.azure.com/compare/v2.8.0-beta.2...v2.8.0-beta.3) (2024-10-23)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.2](https://dev.azure.com/compare/v2.8.0-beta.1...v2.8.0-beta.2) (2024-10-23)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.1](https://dev.azure.com/compare/v2.8.0-beta.0...v2.8.0-beta.1) (2024-10-18)

**Note:** Version bump only for package @camelot/cms

# [2.8.0-beta.0](https://dev.azure.com/compare/v2.7.8-beta.1...v2.8.0-beta.0) (2024-10-18)

**Note:** Version bump only for package @camelot/cms

## [2.7.8-beta.1](https://dev.azure.com/compare/v2.7.8-beta.0...v2.7.8-beta.1) (2024-10-16)

**Note:** Version bump only for package @camelot/cms

## [2.7.8-beta.0](https://dev.azure.com/compare/v2.7.6-beta.0...v2.7.8-beta.0) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.7](https://dev.azure.com/compare/v2.7.6...v2.7.7) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.6](https://dev.azure.com/compare/v2.7.5...v2.7.6) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.5](https://dev.azure.com/compare/v2.7.4...v2.7.5) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.4](https://dev.azure.com/compare/v2.7.2...v2.7.4) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.3](https://dev.azure.com/compare/v2.7.2...v2.7.3) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.2](https://dev.azure.com/compare/v2.7.1...v2.7.2) (2024-10-15)

**Note:** Version bump only for package @camelot/cms

## [2.7.1](https://dev.azure.com/compare/v2.7.1-beta.6...v2.7.1) (2024-10-09)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.6](https://dev.azure.com/compare/v2.7.1-beta.5...v2.7.1-beta.6) (2024-10-09)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.5](https://dev.azure.com/compare/v2.7.1-beta.4...v2.7.1-beta.5) (2024-10-09)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.4](https://dev.azure.com/compare/v2.7.1-beta.3...v2.7.1-beta.4) (2024-10-08)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.3](https://dev.azure.com/compare/v2.7.1-beta.2...v2.7.1-beta.3) (2024-10-08)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.2](https://dev.azure.com/compare/v2.7.1-beta.1...v2.7.1-beta.2) (2024-10-08)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.1](https://dev.azure.com/compare/v2.7.1-beta.0...v2.7.1-beta.1) (2024-10-07)

**Note:** Version bump only for package @camelot/cms

## [2.7.1-beta.0](https://dev.azure.com/compare/v2.7.0...v2.7.1-beta.0) (2024-10-04)

**Note:** Version bump only for package @camelot/cms

# [2.7.0](https://dev.azure.com/compare/v2.7.0-beta.13...v2.7.0) (2024-10-03)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.15](https://dev.azure.com/compare/v2.7.0-beta.14...v2.7.0-beta.15) (2024-10-03)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.14](https://dev.azure.com/compare/v2.7.0-beta.13...v2.7.0-beta.14) (2024-10-03)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.13](https://dev.azure.com/compare/v2.7.0-beta.12...v2.7.0-beta.13) (2024-10-03)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.12](https://dev.azure.com/compare/v2.7.0-beta.11...v2.7.0-beta.12) (2024-10-03)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.11](https://dev.azure.com/compare/v2.7.0-beta.10...v2.7.0-beta.11) (2024-09-27)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.10](https://dev.azure.com/compare/v2.7.0-beta.9...v2.7.0-beta.10) (2024-09-26)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.9](https://dev.azure.com/compare/v2.7.0-beta.8...v2.7.0-beta.9) (2024-09-25)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.8](https://dev.azure.com/compare/v2.7.0-beta.7...v2.7.0-beta.8) (2024-09-25)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.7](https://dev.azure.com/compare/v2.7.0-beta.6...v2.7.0-beta.7) (2024-09-25)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.6](https://dev.azure.com/compare/v2.7.0-beta.5...v2.7.0-beta.6) (2024-09-24)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.5](https://dev.azure.com/compare/v2.7.0-beta.4...v2.7.0-beta.5) (2024-09-19)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.4](https://dev.azure.com/compare/v2.7.0-beta.3...v2.7.0-beta.4) (2024-09-19)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.3](https://dev.azure.com/compare/v2.7.0-beta.2...v2.7.0-beta.3) (2024-09-17)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.2](https://dev.azure.com/compare/v2.7.0-beta.1...v2.7.0-beta.2) (2024-09-17)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.1](https://dev.azure.com/compare/v2.7.0-beta.0...v2.7.0-beta.1) (2024-09-17)

**Note:** Version bump only for package @camelot/cms

# [2.7.0-beta.0](https://dev.azure.com/compare/v2.6.1-beta.10...v2.7.0-beta.0) (2024-08-29)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.10](https://dev.azure.com/compare/v2.6.1-beta.9...v2.6.1-beta.10) (2024-08-29)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.9](https://dev.azure.com/compare/v2.6.1-beta.8...v2.6.1-beta.9) (2024-08-28)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.8](https://dev.azure.com/compare/v2.6.1-beta.7...v2.6.1-beta.8) (2024-08-21)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.7](https://dev.azure.com/compare/v2.6.1-beta.6...v2.6.1-beta.7) (2024-08-20)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.6](https://dev.azure.com/compare/v2.6.1-beta.5...v2.6.1-beta.6) (2024-08-20)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.5](https://dev.azure.com/compare/v2.6.1-beta.4...v2.6.1-beta.5) (2024-08-19)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.4](https://dev.azure.com/compare/v2.6.1-beta.2...v2.6.1-beta.4) (2024-08-19)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.3](https://dev.azure.com/compare/v2.6.1-beta.2...v2.6.1-beta.3) (2024-08-19)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.2](https://dev.azure.com/compare/v2.6.1-beta.1...v2.6.1-beta.2) (2024-08-19)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.1](https://dev.azure.com/compare/v2.6.1-beta.0...v2.6.1-beta.1) (2024-08-19)

**Note:** Version bump only for package @camelot/cms

## [2.6.1-beta.0](https://dev.azure.com/compare/v2.6.0...v2.6.1-beta.0) (2024-08-14)

**Note:** Version bump only for package @camelot/cms

# [2.6.0](https://dev.azure.com/compare/v2.4.1-beta.0...v2.6.0) (2024-08-14)

**Note:** Version bump only for package @camelot/cms

# [2.5.0](https://dev.azure.com/compare/v2.4.1-beta.0...v2.5.0) (2024-08-09)

## [2.4.1](https://dev.azure.com/compare/v2.4.0...v2.4.1) (2024-08-07)

**Note:** Version bump only for package @camelot/cms

## [2.4.1](https://dev.azure.com/compare/v2.4.0...v2.4.1) (2024-08-07)

**Note:** Version bump only for package @camelot/cms

# [2.4.0](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0) (2024-08-06)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.35](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.35) (2024-08-06)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.34](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.34) (2024-08-06)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.33](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.33) (2024-08-06)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.32](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.32) (2024-08-06)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.31](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.31) (2024-07-31)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.23](https://dev.azure.com/compare/v2.4.0-beta.22...v2.4.0-beta.23) (2024-07-30)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.22](https://dev.azure.com/compare/v2.4.0-beta.21...v2.4.0-beta.22) (2024-07-16)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.21](https://dev.azure.com/compare/v2.4.0-beta.20...v2.4.0-beta.21) (2024-07-16)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.20](https://dev.azure.com/compare/v2.4.0-beta.19...v2.4.0-beta.20) (2024-07-11)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.19](https://dev.azure.com/compare/v2.4.0-beta.18...v2.4.0-beta.19) (2024-07-11)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.18](https://dev.azure.com/compare/v2.4.0-beta.17...v2.4.0-beta.18) (2024-07-11)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.17](https://dev.azure.com/compare/v2.4.0-beta.16...v2.4.0-beta.17) (2024-07-11)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.16](https://dev.azure.com/compare/v2.4.0-beta.15...v2.4.0-beta.16) (2024-07-04)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.15](https://dev.azure.com/compare/v2.4.0-beta.14...v2.4.0-beta.15) (2024-06-28)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.14](https://dev.azure.com/compare/v2.4.0-beta.13...v2.4.0-beta.14) (2024-06-28)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.13](https://dev.azure.com/compare/v2.4.0-beta.12...v2.4.0-beta.13) (2024-06-27)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.12](https://dev.azure.com/compare/v2.4.0-beta.11...v2.4.0-beta.12) (2024-06-25)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.11](https://dev.azure.com/compare/v2.4.0-beta.10...v2.4.0-beta.11) (2024-06-18)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.10](https://dev.azure.com/compare/v2.4.0-beta.9...v2.4.0-beta.10) (2024-06-14)

### Features

- sale cgu + improvment link - button - layout - modal ([2448125](https://dev.azure.com/commits/2448125bd766714f49ba0ff35da6b3aeef32e6e1))

# [2.4.0-beta.9](https://dev.azure.com/compare/v2.4.0-beta.8...v2.4.0-beta.9) (2024-06-12)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.8](https://dev.azure.com/compare/v2.4.0-beta.7...v2.4.0-beta.8) (2024-06-11)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.7](https://dev.azure.com/compare/v2.4.0-beta.6...v2.4.0-beta.7) (2024-06-07)

### Features

- cms strapi multi tenant ([0cd3a17](https://dev.azure.com/commits/0cd3a176b0ac607c30c7cc95be4125c0cf376c4d))

# [2.4.0-beta.6](https://dev.azure.com/compare/v2.4.0-beta.5...v2.4.0-beta.6) (2024-06-07)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.5](https://dev.azure.com/compare/v2.4.0-beta.4...v2.4.0-beta.5) (2024-06-04)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.4](https://dev.azure.com/compare/v2.4.0-beta.3...v2.4.0-beta.4) (2024-05-27)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.3](https://dev.azure.com/compare/v2.4.0-beta.0...v2.4.0-beta.3) (2024-05-17)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.2](https://dev.azure.com/compare/v2.4.0-beta.1...v2.4.0-beta.2) (2024-05-17)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.1](https://dev.azure.com/compare/v2.4.0-beta.0...v2.4.0-beta.1) (2024-05-17)

**Note:** Version bump only for package @camelot/cms

# [2.4.0-beta.0](https://dev.azure.com/compare/v2.3.8-beta.0...v2.4.0-beta.0) (2024-05-17)

**Note:** Version bump only for package @camelot/cms

## [2.3.8-beta.0](https://dev.azure.com/compare/v2.3.6-beta.0...v2.3.8-beta.0) (2024-05-16)

**Note:** Version bump only for package @camelot/cms

## [2.3.7](https://dev.azure.com/compare/v2.3.6...v2.3.7) (2024-05-16)

**Note:** Version bump only for package @camelot/cms

## [2.3.6](https://dev.azure.com/compare/v2.3.5...v2.3.6) (2024-05-16)

**Note:** Version bump only for package @camelot/cms

## [2.3.5](https://dev.azure.com/compare/v2.3.1...v2.3.5) (2024-05-15)

**Note:** Version bump only for package @camelot/cms

## [2.3.5](https://dev.azure.com/compare/v2.3.1...v2.3.5) (2024-05-15)

**Note:** Version bump only for package @camelot/cms

## [2.3.4](https://dev.azure.com/compare/v2.3.3...v2.3.4) (2024-05-15)

**Note:** Version bump only for package @camelot/cms

## [2.3.3](https://dev.azure.com/compare/v2.3.2...v2.3.3) (2024-05-15)

**Note:** Version bump only for package @camelot/cms

## [2.3.2](https://dev.azure.com/compare/v2.3.0...v2.3.2) (2024-05-15)

**Note:** Version bump only for package @camelot/cms

## [2.3.1](https://dev.azure.com/compare/v2.3.0...v2.3.1) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

# [2.3.0](https://dev.azure.com/compare/v2.1.0...v2.3.0) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

## [2.2.4](https://dev.azure.com/compare/v2.2.3...v2.2.4) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

## [2.2.3](https://dev.azure.com/compare/v2.2.2...v2.2.3) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

## [2.2.2](https://dev.azure.com/compare/v2.2.1...v2.2.2) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

## [2.2.1](https://dev.azure.com/compare/v2.2.0...v2.2.1) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

# [2.2.0](https://dev.azure.com/compare/v2.1.1...v2.2.0) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

## [2.1.1](https://dev.azure.com/compare/v2.1.0...v2.1.1) (2024-05-14)

**Note:** Version bump only for package @camelot/cms

# [2.1.0](https://dev.azure.com/compare/v1.3.0-beta.36...v2.1.0) (2024-05-13)

**Note:** Version bump only for package @camelot/cms

# [2.0.0](https://dev.azure.com/compare/v1.3.0-beta.36...v2.0.0) (2024-05-13)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.36](https://dev.azure.com/compare/v1.3.0-beta.35...v1.3.0-beta.36) (2024-05-13)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.35](https://dev.azure.com/compare/v1.3.0-beta.34...v1.3.0-beta.35) (2024-05-06)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.34](https://dev.azure.com/compare/v1.3.0-beta.33...v1.3.0-beta.34) (2024-05-06)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.33](https://dev.azure.com/compare/v1.3.0-beta.27...v1.3.0-beta.33) (2024-05-06)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.27](https://dev.azure.com/compare/v1.3.0-beta.26...v1.3.0-beta.27) (2024-05-06)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.26](https://dev.azure.com/compare/v1.3.0-beta.16...v1.3.0-beta.26) (2024-04-29)

# [1.3.0-beta.32](https://dev.azure.com/compare/v1.3.0-beta.31...v1.3.0-beta.32) (2024-05-05)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.31](https://dev.azure.com/compare/v1.3.0-beta.30...v1.3.0-beta.31) (2024-05-05)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.30](https://dev.azure.com/compare/v1.3.0-beta.29...v1.3.0-beta.30) (2024-05-03)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.29](https://dev.azure.com/compare/v1.3.0-beta.28...v1.3.0-beta.29) (2024-05-02)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.28](https://dev.azure.com/compare/v1.3.0-beta.27...v1.3.0-beta.28) (2024-05-02)

# [1.3.0-beta.26](https://dev.azure.com/compare/v1.3.0-beta.25...v1.3.0-beta.26) (2024-04-29)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.27](https://dev.azure.com/compare/v1.3.0-beta.25...v1.3.0-beta.27) (2024-05-02)

# [1.3.0-beta.16](https://dev.azure.com/compare/v1.3.0-beta.15...v1.3.0-beta.16) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.26](https://dev.azure.com/compare/v1.3.0-beta.25...v1.3.0-beta.26) (2024-05-02)

# [1.3.0-beta.16](https://dev.azure.com/compare/v1.3.0-beta.15...v1.3.0-beta.16) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.25](https://dev.azure.com/compare/v1.3.0-beta.24...v1.3.0-beta.25) (2024-04-28)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.24](https://dev.azure.com/compare/v1.3.0-beta.23...v1.3.0-beta.24) (2024-04-28)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.23](https://dev.azure.com/compare/v1.3.0-beta.22...v1.3.0-beta.23) (2024-04-26)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.22](https://dev.azure.com/compare/v1.3.0-beta.21...v1.3.0-beta.22) (2024-04-26)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.21](https://dev.azure.com/compare/v1.3.0-beta.20...v1.3.0-beta.21) (2024-04-26)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.20](https://dev.azure.com/compare/v1.3.0-beta.19...v1.3.0-beta.20) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.19](https://dev.azure.com/compare/v1.3.0-beta.18...v1.3.0-beta.19) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.18](https://dev.azure.com/compare/v1.3.0-beta.17...v1.3.0-beta.18) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.17](https://dev.azure.com/compare/v1.3.0-beta.16...v1.3.0-beta.17) (2024-04-25)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.16](https://dev.azure.com/compare/v1.3.0-beta.15...v1.3.0-beta.16) (2024-04-24)

# [1.3.0-beta.2](https://dev.azure.com/compare/v1.3.0-beta.3...v1.3.0-beta.2) (2024-04-17)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.15](https://dev.azure.com/compare/v1.3.0-beta.14...v1.3.0-beta.15) (2024-04-22)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.14](https://dev.azure.com/compare/v1.3.0-beta.13...v1.3.0-beta.14) (2024-04-21)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.13](https://dev.azure.com/compare/v1.3.0-beta.12...v1.3.0-beta.13) (2024-04-21)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.12](https://dev.azure.com/compare/v1.3.0-beta.11...v1.3.0-beta.12) (2024-04-21)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.11](https://dev.azure.com/compare/v1.3.0-beta.10...v1.3.0-beta.11) (2024-04-21)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.10](https://dev.azure.com/compare/v1.3.0-beta.9...v1.3.0-beta.10) (2024-04-19)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.9](https://dev.azure.com/compare/v1.3.0-beta.8...v1.3.0-beta.9) (2024-04-19)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.8](https://dev.azure.com/compare/v1.3.0-beta.7...v1.3.0-beta.8) (2024-04-18)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.7](https://dev.azure.com/compare/v1.3.0-beta.6...v1.3.0-beta.7) (2024-04-18)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.6](https://dev.azure.com/compare/v1.3.0-beta.5...v1.3.0-beta.6) (2024-04-18)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.5](https://dev.azure.com/compare/v1.3.0-beta.4...v1.3.0-beta.5) (2024-04-18)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.4](https://dev.azure.com/compare/v1.3.0-beta.3...v1.3.0-beta.4) (2024-04-18)

**Note:** Version bump only for package @camelot/cms

# [1.3.0-beta.3](https://dev.azure.com/compare/v1.3.0-beta.2...v1.3.0-beta.3) (2024-04-17)

# [1.3.0-beta.1](https://dev.azure.com/compare/v1.3.0-beta.0...v1.3.0-beta.1) (2024-04-16)

# [1.3.0-beta.0](https://dev.azure.com/compare/v1.2.9-beta.12...v1.3.0-beta.0) (2024-04-16)

### Features

- linnk + italic ([57c744e](https://dev.azure.com/commits/57c744ed46eddf3276cf38849a8adefd5788fdbb))

## [1.2.9-beta.12](https://dev.azure.com/compare/v1.2.9-beta.11...v1.2.9-beta.12) (2024-04-15)

## [1.2.9-beta.11](https://dev.azure.com/compare/v1.2.9-beta.10...v1.2.9-beta.11) (2024-04-15)

## [1.2.9-beta.10](https://dev.azure.com/compare/v1.2.9-beta.9...v1.2.9-beta.10) (2024-04-15)

# [1.3.0-beta.2](https://dev.azure.com/compare/v1.2.9-beta.9...v1.3.0-beta.2) (2024-04-17)

**Note:** Version bump only for package @camelot/cms

## [1.3.0-beta.1](https://dev.azure.com/compare/v1.2.9-beta.9...v1.3.0-beta.1) (2024-04-17)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.11](https://dev.azure.com/compare/v1.2.9-beta.9...v1.2.9-beta.11) (2024-04-17)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.10](https://dev.azure.com/compare/v1.2.9-beta.9...v1.2.9-beta.10) (2024-04-17)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.9](https://dev.azure.com/compare/v1.2.9-beta.3...v1.2.9-beta.9) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.8](https://dev.azure.com/compare/v1.2.9-beta.7...v1.2.9-beta.8) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.7](https://dev.azure.com/compare/v1.2.9-beta.6...v1.2.9-beta.7) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.6](https://dev.azure.com/compare/v1.2.9-beta.5...v1.2.9-beta.6) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.5](https://dev.azure.com/compare/v1.2.9-beta.4...v1.2.9-beta.5) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.4](https://dev.azure.com/compare/v1.2.9-beta.2...v1.2.9-beta.4) (2024-04-15)

**Note:** Version bump only for package @camelot/cms

## [1.2.9-beta.3](https://dev.azure.com/compare/v1.2.9-beta.2...v1.2.9-beta.3) (2024-04-15)

**Note:** Version bump only for package @camelot/cms
