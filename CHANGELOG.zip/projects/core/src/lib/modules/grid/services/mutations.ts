import { Apollo_gql, GraphMutationPayload, graphQlUpdateFields } from '@camelot/server';

import { UpdateViewSettingInput } from './dto/post/view';
import { viewProps } from './dto/view';

export function CREATE_VIEW(view: Partial<UpdateViewSettingInput>): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
      mutation CreateSetting($view: CreateViewSettingInput!) {
        createViewSetting(payload: $view) {
          ${viewProps.get('id')}
        }
      }
    `,
    variables: {
      view,
    },
  };
}

export function UPDATE_VIEW(view: Partial<UpdateViewSettingInput>): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
      mutation UpdateSetting($view: UpdateViewSettingInput!) {
        updateViewSetting(payload: $view) {
          ${viewProps.get('id')}
        }
      }
    `,
    variables: {
      view: { ...view, ...graphQlUpdateFields(view) },
    },
  };
}

export function DELETE_VIEW(viewId: string): GraphMutationPayload {
  return {
    mutation: Apollo_gql`
      mutation DeleteViewSetting($id: UUID!) {
        deleteViewSetting(viewSettingId: $id)
      }
    `,
    variables: {
      id: viewId,
    },
  };
}
