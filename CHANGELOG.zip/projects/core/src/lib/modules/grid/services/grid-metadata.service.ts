import { Injectable } from '@angular/core';

import { filter, map } from 'rxjs/operators';

import { IServerSideGetRowsParams } from 'ag-grid-enterprise';

import { CamBaseService, GraphEndpoint, HandleComplexRequest } from '@camelot/server';
import { getUniqueArray, isNonNullable } from '@camelot/utils';

import { GridMetaData } from './dto/metadata';
import { GET_DATA, GET_FIELDS_DATA, GET_META_DATA } from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'viewService',
  endpoint: 'view',
};

@Injectable({
  providedIn: 'root',
})
export class CamGridMetaDataService extends CamBaseService {
  public metaData = new HandleComplexRequest<GridMetaData[]>();

  constructor() {
    super();

    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public fectMetaData$(dataId: string) {
    return this.metaData.fetch(
      dataId,
      this._graphService
        .fetchQueryList<GridMetaData>(GET_META_DATA(dataId), dataId + 'MetaData', graphEndpoint.clientName)
        .pipe(
          filter(isNonNullable),
          map(data => data)
        )
    );
  }

  public getFieldsData$(dataId: string, search: string, colId: string) {
    return this._graphService
      .fetchPagedQueryList<any>(GET_FIELDS_DATA(dataId, search, colId), dataId, graphEndpoint.clientName)
      .pipe(
        filter(isNonNullable),
        map(data => getUniqueArray(data.items?.map(item => item[colId]) ?? []))
      );
  }

  public getData$(dataId: string, params: IServerSideGetRowsParams<any, any>) {
    return this._graphService.fetchPagedQueryList<any>(GET_DATA(dataId, params), dataId, graphEndpoint.clientName).pipe(
      filter(isNonNullable),
      map(data => ({ ...{ items: [] }, ...data }))
    );
  }
}
