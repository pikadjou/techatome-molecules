import { Injectable } from '@angular/core';

import { CamGridData } from '../models/grid-data';
import { CamGridFormService } from './grid-form.service';

@Injectable({
  providedIn: 'root',
})
export class CamGridDataService<T> {
  public grids: { [index: string]: CamGridData<T> } = {};

  constructor(private _formService: CamGridFormService<T>) {}

  public create(key: string) {
    if (!this.has(key)) {
      this.grids[key] = new CamGridData<T>(key, this._formService);
    }
  }

  public get(key: string, create: boolean = false) {
    if (!this.has(key) && create) {
      this.create(key);
    }
    return this.grids[key];
  }

  public has(key: string) {
    return !!this.grids[key];
  }
}
