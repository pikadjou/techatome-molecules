import { Injectable, TemplateRef, inject } from '@angular/core';
import { Validators } from '@angular/forms';

import { filter, map, of } from 'rxjs';

import { InputBase, InputChoices, InputDropdown, InputPanel, InputTextBox } from '@camelot/form-model';
import { CamUsersService } from '@camelot/user';
import { extractEnum, fullName, isNonNullable } from '@camelot/utils';

import { getTypeTranslationKey } from '../helpers/type';
import { CamGridData } from '../models/grid-data';
import { UpdateViewSettingInput } from './dto/post/view';
import { FielOptions, View, ViewType } from './dto/view';

@Injectable({
  providedIn: 'root',
})
export class CamGridFormService<T> {
  private _usersService = inject(CamUsersService);

  constructor() {
    this._usersService.fetchUsers$().subscribe();
  }

  public getFiltersForm(model: CamGridData<T>): InputBase<any>[] {
    const keys = Object.keys(model.cols);
    if (!keys || keys.length === 0) {
      return [];
    }

    return [
      new InputPanel({
        key: 'main-panel',
        label: `grid.${model.scope}.title`,
        class: 'p-5',
        children: keys
          .filter(key => model.cols[key].enabledInFilter)
          .map(key => model.cols[key].getInputForm())
          .filter(isNonNullable),
      }),
    ];
  }

  public getViewForm(view: View | null, choiceTemplate: TemplateRef<any>): InputBase<any>[] {
    const typeDropdown = new InputDropdown({
      key: 'type',
      label: 'grid.settings.view.type',
      class: 'pb-2',
      options: of(
        extractEnum(ViewType)
          .map(item => ({
            id: item.value.toString(),
            name: getTypeTranslationKey(item.value),
          }))
          .filter(item => item.id !== '0')
      ),
      value: view?.type.toString(),
      validators: [Validators.required],
    });
    return [
      new InputTextBox({
        key: 'id',
        value: view?.id,
        visible$: of(false),
      }),
      new InputPanel({
        key: 'main-panel',
        label: `grid.settings.view.title`,
        class: 'p-5',
        children: [
          new InputTextBox({
            key: 'name',
            label: 'grid.settings.view.name',
            class: 'pb-2',
            validators: [Validators.required],
            value: view?.name,
          }),
        ],
      }),
      typeDropdown,
      new InputChoices({
        key: 'sharedWithUserIds',
        label: 'teams.form.users.label',
        multiple: true,
        withSearch: true,
        visible$: typeDropdown.changeValue$.pipe(map(type => Number(type) === ViewType.shared)),
        options: this._usersService.users.get$().pipe(
          filter(isNonNullable),
          map(users =>
            users.map(user => ({
              id: user.id,
              name: fullName({
                firstName: user.firstName,
                name: user.lastName,
              }),
              data: user,
            }))
          )
        ),
        choiceTemplate: { one: choiceTemplate },
      }),
    ];
  }

  public formatView(
    data: any,
    viewname: string,
    filterModel: string,
    selectedFields: string[],
    fieldOptions: FielOptions[]
  ): UpdateViewSettingInput {
    return {
      id: data['id'],
      name: data['name'],
      viewName: viewname,
      type: Number(data['type']),
      sharedWithUserIds: data['sharedWithUserIds'],
      filterModel,
      selectedFields,
      fieldOptions,
    };
  }
}
