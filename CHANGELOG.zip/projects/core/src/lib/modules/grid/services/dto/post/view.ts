import { FielOptions } from '../view';

export interface UpdateViewSettingInput {
  id?: string;
  name: string;
  viewName: string;
  type: number;
  sharedWithUserIds: string[];
  filterModel: string;
  selectedFields: string[];
  fieldOptions: FielOptions[];
}
