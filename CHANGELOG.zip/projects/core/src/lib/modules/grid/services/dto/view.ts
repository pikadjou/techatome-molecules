import { GraphSchema } from '@camelot/server';
import { User } from '@camelot/user';

export enum ViewType {
  unknown = 0,
  private = 1,
  shared = 2,
  public = 3,
}
export enum SortOption {
  Unknown = 0,
  Ascending = 1,
  Descending = 2,
}

export interface FielOptionsValue {
  sortOption: SortOption | null;
}
export const fielOptionsValueProps = new GraphSchema<FielOptionsValue>([
  'sortOption',
]);

export interface FielOptions {
  key: string;
  value: FielOptionsValue;
}
export const fielOptionsProps = new GraphSchema<FielOptions>(['key', 'value']);

export interface Views {
  privateViewSettings: View[];
  sharedViewSettings: View[];
  publicViewSettings: View[];
}
export const viewSettingsProps = new GraphSchema<Views>([
  'privateViewSettings',
  'sharedViewSettings',
  'publicViewSettings',
]);

export interface View {
  id: string;
  name: string;
  filterModel: string;
  selectedFields: string[];
  fieldOptions: FielOptions[];
  type: number;
  sharedUsers?: User[];
  owner: User;
  createdTime: string;
  updatedTime?: string;
}

export const viewProps = new GraphSchema<View>([
  'id',
  'name',
  'type',
  'filterModel',
  'selectedFields',
  'fieldOptions',
  'owner',
  'sharedUsers',
  'createdTime',
  'updatedTime',
]);
