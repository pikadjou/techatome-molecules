import { AdvancedFilterModel, FilterModel, IServerSideGetRowsParams } from 'ag-grid-enterprise';

import { Apollo_gql, GraphQueryPayload, graphQlTake } from '@camelot/server';
import { userProps } from '@camelot/user';

import { graphQLSortOrder, graphQlFilterToWhere } from '../helpers/queries';
import { gridMetaDataProps } from './dto/metadata';
import { fielOptionsProps, fielOptionsValueProps, viewProps, viewSettingsProps } from './dto/view';

export function GET_META_DATA(id: string): GraphQueryPayload {
  return {
    query: Apollo_gql`
        query Meta_Data {
          ${id}MetaData {
            ${gridMetaDataProps.get('name')}
            ${gridMetaDataProps.get('type')}
            ${gridMetaDataProps.get('nullable')}
            ${gridMetaDataProps.get('meSearchEnabled')}
            ${gridMetaDataProps.get('multiSearchEnabled')}
            ${gridMetaDataProps.get('shownByDefault')}
            ${gridMetaDataProps.get('enumName')}
            ${gridMetaDataProps.get('showEntireListWhenFiltering')}
            ${gridMetaDataProps.get('dateTimeKind')}            
          }
        }
      `,
    variables: {},
  };
}

export function GET_DATA(id: string, params: IServerSideGetRowsParams<any, any>): GraphQueryPayload {
  const columns = params.api.getColumns()?.map(c => c.getColId()) ?? ['id'];
  const { startRow, endRow, filterModel, sortModel } = params.request;

  const filter: AdvancedFilterModel | null = filterModel
    ? {
        filterType: 'join',
        type: 'AND',
        conditions: Object.keys(filterModel).reduce<AdvancedFilterModel[]>(
          (acc, key) => [...acc, { ...(<FilterModel>filterModel)[key], ...{ colId: key } }],
          []
        ),
      }
    : null;
  const where = filter?.conditions ? graphQlFilterToWhere(filter) : null;
  const order = sortModel ? graphQLSortOrder(sortModel) : null;
  const offset = startRow ?? 0;
  const limit = (endRow ?? 0) - (startRow ?? 0) + 1;

  return {
    query: Apollo_gql`
        query Data($where: TaskViewFilterInput, $order: [TaskViewSortInput!]) {
          ${id} (where: $where, order: $order, skip: ${offset}, ${graphQlTake(limit)}) {
            items {
              ${columns?.join(' ')}
            },
            totalCount
          }
        }
      `,
    variables: {
      where,
      order,
    },
  };
}

export function GET_FIELDS_DATA(id: string, search: string, colId: string): GraphQueryPayload {
  const where = { [colId]: { ['contains']: search } };
  return {
    query: Apollo_gql`
        query Data($where: TaskViewFilterInput, $distinct: String) {
          ${id} (distinctOn: $distinct, where: $where, ${graphQlTake()}) {
            items {
              ${colId}
            }
          }
        }
      `,
    variables: {
      where,
      distinct: colId,
    },
  };
}

export function GET_VIEWS(id: string): GraphQueryPayload {
  const content = `
    ${viewProps.get('id')}
    ${viewProps.get('name')}
    ${viewProps.get('type')}
    ${viewProps.get('filterModel')}
    ${viewProps.get('selectedFields')}
    ${viewProps.get('fieldOptions')} {
      ${fielOptionsProps.get('key')}
      ${fielOptionsProps.get('value')} {
        ${fielOptionsValueProps.get('sortOption')}
      }
    }
    ${viewProps.get('createdTime')}
    ${viewProps.get('updatedTime')}
    ${viewProps.get('owner')} {
      ${userProps.get('trigram')}
      ${userProps.get('picture')}
      ${userProps.get('firstName')}
      ${userProps.get('lastName')}
    }
    ${viewProps.get('sharedUsers')} {
      ${userProps.get('trigram')}
      ${userProps.get('picture')}
      ${userProps.get('firstName')}
      ${userProps.get('lastName')}
    }
  `;

  return {
    query: Apollo_gql`
        query DataSettings($id: String!) {
          viewSettings(viewName: $id) {
            ${viewSettingsProps.get('privateViewSettings')} {
              ${content}
            }
            ${viewSettingsProps.get('sharedViewSettings')}{
              ${content}
            }
            ${viewSettingsProps.get('publicViewSettings')}{
              ${content}
            }
          }
        }
      `,
    variables: {
      id,
    },
  };
}

// const extractDataFromRequest = (params: IServerSideGetRowsParams<any, any>) => {};
