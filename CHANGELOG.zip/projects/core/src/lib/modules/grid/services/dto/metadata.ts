import { GraphSchema } from '@camelot/server';

export enum DateTimeKind {
  Unknown = 0,
  DateTime = 1,
  Date = 2,
  TimeSpan = 3,
}
type KeyValuePair = {
  key: string;
  value: number;
};
export enum ParameterType {
  Unknown,
  String,
  Number,
  Boolean,
  DateTime,
  Guid,
  Enum,
  TimeStamp,
}

export interface GridMetaData {
  name: string;
  type: ParameterType;
  enumName?: 'Criticity' | string;
  nullable: boolean;
  multiSearchEnabled: boolean;
  meSearchEnabled: boolean;
  shownByDefault: boolean;
  showEntireListWhenFiltering: boolean;
  additionalInfo: KeyValuePair[];
  dateTimeKind?: DateTimeKind;
}

export const gridMetaDataProps = new GraphSchema<GridMetaData>([
  'name',
  'type',
  'nullable',
  'shownByDefault',
  'additionalInfo',
  'enumName',
  'meSearchEnabled',
  'multiSearchEnabled',
  'showEntireListWhenFiltering',
  'dateTimeKind',
]);
