import { Injectable } from '@angular/core';

import { filter, map, mergeMap } from 'rxjs/operators';

import { CamBaseService, GraphEndpoint, HandleSimpleRequest } from '@camelot/server';
import { isNonNullable } from '@camelot/utils';

import { UpdateViewSettingInput } from './dto/post/view';
import { View, Views } from './dto/view';
import { CREATE_VIEW, DELETE_VIEW, UPDATE_VIEW } from './mutations';
import { GET_VIEWS } from './queries';

const graphEndpoint: GraphEndpoint = {
  clientName: 'viewService',
  endpoint: 'view',
};

@Injectable({
  providedIn: 'root',
})
export class CamGridViewService extends CamBaseService {
  public views = new HandleSimpleRequest<Views>();

  constructor() {
    super();

    super.registerRoutes({ graphEndpoint: graphEndpoint });
  }

  public getViews$(dataId: string) {
    return this.views.fetch(
      this._graphService.fetchQuery<Views>(GET_VIEWS(dataId), 'viewSettings', graphEndpoint.clientName).pipe(
        filter(isNonNullable),
        map(data => data)
      )
    );
  }

  public addView$(dataId: string, view: Partial<UpdateViewSettingInput>) {
    return this._graphService
      .mutate(CREATE_VIEW(view), 'createViewSetting', graphEndpoint.clientName, ['viewSettings'])
      .pipe(
        filter(isNonNullable),
        mergeMap(() => this.getViews$(dataId))
      );
  }

  public updateView$(dataId: string, view: Partial<UpdateViewSettingInput>) {
    return this._graphService
      .mutate(UPDATE_VIEW(view), 'updateViewSetting', graphEndpoint.clientName, ['viewSettings'])
      .pipe(
        filter(isNonNullable),
        mergeMap(() => this.getViews$(dataId))
      );
  }

  public deleteView$(dataId: string, view: View) {
    return this._graphService
      .mutate(DELETE_VIEW(view.id), 'deleteViewSetting', graphEndpoint.clientName, ['viewSettings'])
      .pipe(
        filter(isNonNullable),
        mergeMap(() => this.getViews$(dataId))
      );
  }
}
