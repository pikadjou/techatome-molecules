import { Injectable, inject } from '@angular/core';

import { map, of } from 'rxjs';

import { CamGridCursor } from '../models/grid-cursor';
import { CamGridMetaDataService } from './grid-metadata.service';

@Injectable({
  providedIn: 'root',
})
export class CamGridCursorService {
  private readonly _metaDataService = inject(CamGridMetaDataService);
  constructor() {}

  public getCursor$(dataId: string, cursor: CamGridCursor) {
    const request = cursor.getRequestParams();
    if (!request) {
      return of([]);
    }

    request.request.startRow = cursor.currentRowIndex === 0 ? cursor.currentRowIndex : cursor.currentRowIndex - 1;
    request.request.endRow = cursor.currentRowIndex + 1;
    return this._metaDataService.getData$(dataId, request).pipe(map(data => data.items));
  }
}
