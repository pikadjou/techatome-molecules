import { AdvancedFilterModel, FilterModel } from 'ag-grid-enterprise';
import { BehaviorSubject } from 'rxjs';

import { ActiveFilterTag } from '../../../components/filters/types';
import { SortOption } from '../services/dto/view';
import { BaseFilterComponent } from './cols/base-col';
import { FilterModelSource, IFilterModelStorage, IForcedFilter, IGridData } from './types';
import { convertSortAgGridToSortDto, getFilterModelStorageKey, getPaginationKey, getViewKey } from './utils';

export class CamGridFilters<T> {
  public filtersChanged$ = new BehaviorSubject(Date.now());
  public forcedFilter?: IForcedFilter;

  get viewSelected() {
    return localStorage.getItem(getViewKey(this._grid.scope));
  }
  private set viewSelected(value: string | null) {
    if (!value) {
      localStorage.removeItem(getViewKey(this._grid.scope));
    } else {
      localStorage.setItem(getViewKey(this._grid.scope), value);
    }
  }

  get filterModelSource() {
    const data = localStorage.getItem(getFilterModelStorageKey(this._grid.scope));
    if (data) {
      return JSON.parse(data);
    }
    return null;
  }
  private set filterModelSource(value: IFilterModelStorage | null) {
    if (!value) {
      localStorage.removeItem(getFilterModelStorageKey(this._grid.scope));
    } else {
      localStorage.setItem(getFilterModelStorageKey(this._grid.scope), JSON.stringify(value));
    }
  }

  get paginationStorage() {
    const data = localStorage.getItem(getPaginationKey(this._grid.scope));
    if (data && Number(data)) {
      return Number(data);
    }
    return 0;
  }
  set paginationStorage(value: number | null) {
    if (value === null) {
      localStorage.removeItem(getPaginationKey(this._grid.scope));
    } else {
      localStorage.setItem(getPaginationKey(this._grid.scope), value.toString());
    }
  }
  private _applyFilterModelSource: FilterModelSource | null = null;
  private _grid: IGridData<T>;

  constructor(grid: IGridData<T>) {
    this._grid = grid;
  }

  public applyFilterModel(
    model: IFilterModelStorage | null,
    source: FilterModelSource,
    options?: { viewName?: string; selected?: boolean }
  ) {
    if (
      !this._applyFilterModelSource ||
      FilterModelSource[source] >= FilterModelSource[this._applyFilterModelSource] ||
      options?.selected
    ) {
      this._applyFilterModelSource = source;
      if (!model) {
        this._grid.api?.setFilterModel(null);
      } else {
        if (model.filterModel) {
          this._grid.api?.setFilterModel(JSON.parse(model.filterModel));
        }

        if (model.selectedFields) {
          this._grid.api?.getColumns()?.forEach(column => {
            if (model.selectedFields!.includes(column.getId())) {
              this._grid.api?.setColumnsVisible([column.getId()], true);
              this._grid.api?.moveColumns(
                [column.getId()],
                model.selectedFields?.findIndex(name => name === column.getId()) ?? 0
              );
            } else {
              this._grid.api?.setColumnsVisible([column.getId()], false);
              this._grid.api?.moveColumns([column.getId()], this._grid.api?.getColumns()?.length ?? 100);
            }
          });
        }

        if (model.fieldOptions) {
          this._grid.api?.getColumns()?.forEach(column => {
            const options = model.fieldOptions?.find(field => field.key === column.getId())?.value;
            if (options) {
              if (options.sortOption) {
                switch (options.sortOption) {
                  case SortOption.Ascending:
                    column.setSort('asc', 'api');
                    break;
                  case SortOption.Descending:
                    column.setSort('desc', 'api');
                    break;
                  default:
                    break;
                }
              }
            }
          });
        }
      }
    }
    this._grid.api?.onFilterChanged();
    this._grid.api?.onSortChanged();

    if (source === FilterModelSource.view) {
      this.viewSelected = options?.viewName ?? null;
      this.filterModelSource = null;
    } else if (source === FilterModelSource.storage) {
      this.viewSelected = null;
      this.filterModelSource = this.extractCurrentFilterModel();
    }
  }

  public extractCurrentFilterModel(): IFilterModelStorage {
    return {
      filterModel: JSON.stringify(this._grid.api?.getFilterModel()),
      selectedFields:
        this._grid.api
          ?.getAllDisplayedColumns()
          ?.filter(col => col.isVisible())
          .map(col => col.getId()) ?? [],
      fieldOptions:
        this._grid.api
          ?.getColumns()
          ?.map(col => ({
            key: col.getId(),
            value: {
              sortOption: convertSortAgGridToSortDto(col.getSort()),
            },
          }))
          .filter(option => option.value && option.value.sortOption) ?? [],
    };
  }

  public formatFilter(key: string): ActiveFilterTag[] {
    return this._grid.api?.getFilterInstance<BaseFilterComponent<AdvancedFilterModel, any>>(key)?.getTags() ?? [];
  }

  public resetFilters() {
    this.viewSelected = '';
    this.applyFilterModel(null, FilterModelSource.storage);

    this._grid.api?.onFilterChanged();
  }
  public applyFiltersForm(data: any | null) {
    if (!data) {
      this._grid.api?.setFilterModel(null);
    } else {
      const conditions = Object.keys(this._grid.cols).reduce<FilterModel>((acc, key) => {
        const filters = this._grid.cols[key].getFiltersModel(data);
        if (!filters) {
          return acc;
        }
        acc[key] = filters;
        return acc;
      }, {});
      this.applyFilterModel({ filterModel: JSON.stringify(conditions) }, FilterModelSource.storage);
    }
    this._grid.computedFiltersData();
  }

  public applySearch(search: string) {
    this._grid.api?.setGridOption('quickFilterText', search);
    this._grid.computedFiltersData();
  }
}
