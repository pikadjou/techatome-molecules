import { NgIf } from '@angular/common';
import { Component } from '@angular/core';

import {
  BooleanAdvancedFilterModel,
  ColDef,
  JoinAdvancedFilterModel,
  IFilterParams,
} from 'ag-grid-enterprise';

import { CamFormModule } from '@camelot/form-basic';
import { InputCheckBox } from '@camelot/form-model';

import { GridBoolCellComponent } from '../../components/ag-grid/template/bool.component';
import { BaseCol, BaseFilterComponent } from './base-col';

type FilterTyping = BooleanAdvancedFilterModel;

export class BoolCol extends BaseCol<FilterTyping> {
  public override getInputForm() {
    const value =
      this.filterInstance?.filterType === 'boolean'
        ? this.filterInstance.type === 'true'
          ? true
          : false
        : undefined;

    return new InputCheckBox({
      key: this.key,
      label: this.inputLabel,
      class: 'pb-2',
      toggle: true,
      value: value ?? false,
    });
  }
  public override getFiltersModel(data: any): FilterTyping | null {
    const value = data[this.key];

    if (!value) {
      return null;
    }
    return {
      filterType: 'boolean',
      colId: this.key,
      type: value ? 'true' : 'false',
    };
  }

  public override getColDef(): ColDef {
    return {
      ...super.getColDef(),
      ...{ filter: BoolFliterComponent, cellRenderer: GridBoolCellComponent },
    };
  }
}

@Component({
  standalone: true,
  imports: [CamFormModule, NgIf],
  template: `
    <ng-container *ngIf="this.input">
      <cam-form
        class="p-space-md"
        [inputs]="[this.input]"
        [buttonTitle]="'grid.floating.filter.apply'"
        (valid)="this.apply($event)"
      >
      </cam-form>
    </ng-container>
  `,
})
export class BoolFliterComponent extends BaseFilterComponent<
  JoinAdvancedFilterModel | BooleanAdvancedFilterModel,
  BoolCol
> {
  override agInit(params: IFilterParams) {
    super.agInit(params);
  }
}
