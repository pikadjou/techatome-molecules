import { NgIf } from '@angular/common';
import { Component } from '@angular/core';

import {
  AdvancedFilterModel,
  ColDef,
  IFilterParams,
  JoinAdvancedFilterModel,
  TextAdvancedFilterModel,
} from 'ag-grid-enterprise';
import { filter, map, of } from 'rxjs';

import { CamFormInputsModule } from '@camelot/form-input';
import { InputChoices, InputTextBox } from '@camelot/form-model';
import { isArray, isNonNullable } from '@camelot/utils';

import { ActiveFilterTag } from '../../../../components/filters/types';
import { BaseCol, BaseFilterComponent, operatorMap } from './base-col';

type FilterTyping = JoinAdvancedFilterModel | TextAdvancedFilterModel;
export class StringCol extends BaseCol<FilterTyping> {
  get values() {
    return this._extractFiltersByFilterType(this.filterInstance, ['contains', 'equals'])
      .filter(cond => cond.filterType === 'text')
      .map((cond: any) => cond.filter?.toString())
      .filter(isNonNullable);
  }
  public override getInputForm(fromView: boolean) {
    const value = this.values;

    if (!this.data.col.multiSearchEnabled || !this.data.options.dataSearch$) {
      return new InputTextBox({
        key: this.key,
        label: this.inputLabel,
        class: 'pb-2',
        value: value[0],
      });
    }

    if (this.data.col.showEntireListWhenFiltering) {
      return new InputChoices({
        key: this.key,
        label: this.inputLabel,
        value: value,
        multiple: this.data.col.multiSearchEnabled,
        showNullableFields: this.data.col.nullable,
        withSearch: true,
        onlyTemplate: fromView,
        options: this.data.options.dataSearch$('', this.key).pipe(
          filter(isNonNullable),
          map(list =>
            list.map(value => ({
              id: value,
              name: value,
              data: value,
            }))
          )
        ),
      });
    }
    return new InputChoices({
      key: this.key,
      label: this.inputLabel,
      value: value,
      multiple: this.data.col.multiSearchEnabled,
      showNullableFields: this.data.col.nullable,
      withSearch: true,
      onlyTemplate: fromView,
      advancedSearch$: search => {
        if (!search || !this.data.options.dataSearch$) {
          return of([]);
        }
        return this.data.options.dataSearch$(search, this.key).pipe(
          filter(isNonNullable),
          map(list =>
            list.map(value => ({
              id: value,
              name: value,
              data: value,
            }))
          )
        );
      },
    });
  }
  public override getFiltersModel(data: any): FilterTyping | null {
    const value = data[this.key];

    if (!value || value === '' || value.length === 0) {
      return null;
    }
    if (!Array.isArray(value)) {
      const val = isArray(value) ? value[0] : value;

      if (val === '') {
        return {
          filterType: 'text',
          colId: this.key,
          type: 'blank',
        };
      }

      return {
        filterType: 'text',
        colId: this.key,
        type: this.data.col.multiSearchEnabled ? 'equals' : 'contains',
        filter: isArray(value) ? value[0] : value,
      };
    }
    const filters = value.reduce<TextAdvancedFilterModel[]>((acc, val) => {
      if (val === '') {
        acc.push({
          filterType: 'text',
          colId: this.key,
          type: 'blank',
        });
      } else if (val) {
        acc.push({
          filterType: 'text',
          colId: this.key,
          type: this.data.col.multiSearchEnabled ? 'equals' : 'contains',
          filter: val,
        });
      }
      return acc;
    }, []);

    if (filters.length === 0) {
      return null;
    }
    if (filters.length === 1) {
      return filters[0];
    }
    return {
      filterType: 'join',
      type: 'OR',
      conditions: filters,
    };
  }

  public override getColDef(): ColDef {
    return { ...super.getColDef(), ...{ filter: StringFilterComponent, cellDataType: 'text' } };
  }
}

@Component({
  standalone: true,
  imports: [CamFormInputsModule, NgIf],
  template: `
    <div *ngIf="this.input" class="p-space-sm">
      <cam-input-choices *ngIf="this.isMultiSearch" [input]="$any(this.input)"></cam-input-choices>
      <cam-input-textbox *ngIf="!this.isMultiSearch" [input]="$any(this.input)"></cam-input-textbox>
    </div>
  `,
})
export class StringFilterComponent extends BaseFilterComponent<FilterTyping, StringCol> {
  get isMultiSearch() {
    return this._col?.data.col.multiSearchEnabled;
  }
  override agInit(params: IFilterParams) {
    super.agInit(params);
  }

  override getTags(model?: AdvancedFilterModel | null): ActiveFilterTag[] {
    if (!model) {
      model = this._model;
    }
    if (!model) {
      return [];
    }
    if (model.filterType === 'text') {
      if (model.filter === undefined) {
        return [];
      }

      const operator = operatorMap[model.type] || model.type;

      return [
        {
          id: model.colId,
          name: `${operator} ${model.filter}`,
        },
      ];
    }
    if (model.filterType === 'join') {
      // Transformation pour JoinAdvancedFilterModel
      return model.conditions.flatMap(condition => this.getTags(condition));
    }

    console.log('Unsupported filter type');
    return [];
  }
}
