import {
  ColDef,
  GetContextMenuItemsParams,
  GridApi,
  GridOptions,
  IServerSideDatasource,
  IServerSideGetRowsParams,
  RowClickedEvent,
} from 'ag-grid-enterprise';
import { BehaviorSubject, Subject, map, take } from 'rxjs';

import { ObjectKeys, isNonNullable } from '@camelot/utils';
import { isStrictISODateString } from '@camelot/utils';

import { ActiveFilterTag } from '../../../components/filters/types';
import { ContextMenuItemComponent } from '../components/ag-grid/template/context-menu-item.component';
import { DateTimeKind, GridMetaData, ParameterType } from '../services/dto/metadata';
import { CamGridFormService } from '../services/grid-form.service';
import { BaseCol, IColOptions } from './cols/base-col';
import { BoolCol } from './cols/bool-col';
import { DateCol } from './cols/date-col';
import { EnumCol } from './cols/enum-col';
import { GuidCol } from './cols/guid-col';
import { NumberCol } from './cols/number-col';
import { StringCol } from './cols/string-col';
import { TimeCol } from './cols/time-col';
import { CamGridCursor } from './grid-cursor';
import { CamGridFilters } from './grid-filters';
import {
  ContentMenuAction,
  FilterModelSource,
  GridViewType,
  IDataService,
  IFieldsOverrides,
  IForcedFilter,
  IGridData,
  ITreeData,
} from './types';
import { gridViewKey } from './utils';

export type GridContext = {
  grid: CamGridData<unknown>;
  cols: { [index: string]: BaseCol<any> };
};

export class CamGridData<T> implements IGridData<T> {
  public api: GridApi<T> | null = null;
  public ready$ = new BehaviorSubject(false);

  public cursor = new CamGridCursor();
  public filters = new CamGridFilters(this);

  public clickedRow$ = new Subject<RowClickedEvent<T>>();
  public selectedData$ = new Subject<T[]>();
  public contextMenuAction$ = new Subject<{ action: ContentMenuAction; item: T }>();
  public filteredData$ = new BehaviorSubject<T[]>([]);

  get filteredDataLenght$() {
    return this.filteredData$.pipe(map(list => list.length));
  }
  get isAtLeastOneNodeOpen() {
    if (!this.ready$.value) {
      return false;
    }
    let oneOpen = false;
    this.api?.forEachNode(node => {
      if (node.expanded) {
        oneOpen = true;
      }
    });
    return oneOpen;
  }

  public cols: { [index: string]: BaseCol<any> } = {};
  public displayType: GridViewType = 'grid';
  public treeMode: boolean = false;

  public isTreeData: boolean = false;

  private _rowType: 'clientSide' | 'serverSide' = 'clientSide';

  constructor(
    public scope: string,
    private _formService: CamGridFormService<T>
  ) {}

  public destroy() {
    this.api?.destroy();
    this.api = null;
  }

  public isReady() {
    return this.ready$.value;
  }

  public setApi(api: GridApi<T>) {
    this.api = api;
  }

  public setData(params: {
    data: T[];
    colsMetaData?: GridMetaData[] | null;
    fieldsOverrides?: IFieldsOverrides;
    forcedFilter?: IForcedFilter;
    options?: Omit<GridOptions, 'treeData'> & {
      treeData?: ITreeData<T> | null;
      services?: IDataService<T> | null;
      colOptions?: IColOptions;
      contextMenuItems: ContentMenuAction[];
    };
  }) {
    if (!this.api) {
      return;
    }
    this.filters.forcedFilter = params.forcedFilter;

    this.api.setGridOption('context', { grid: this, cols: this.cols });
    if (params.options?.pagination) {
      this.api.setGridOption('pagination', true);

      this.api.setGridOption('paginationPageSize', params.options?.paginationPageSize ?? 10);
      this.api.setGridOption('cacheBlockSize', params.options?.cacheBlockSize ?? 5);
      this.api.setGridOption('cacheBlockSize', params.options?.cacheBlockSize ?? 5);

      this.api.setGridOption('onPaginationChanged', page => {
        if (!this.isReady() || page.api.paginationGetTotalPages() <= 1) {
          return;
        }
        this.filters.paginationStorage = page.api.paginationGetCurrentPage();
      });
    }

    if (!params.options?.services) {
      this.api.setGridOption('rowData', params.data);
      this._rowType = 'clientSide';
    } else {
      this._rowType = 'serverSide';
      this.api.setGridOption('serverSideDatasource', this._createServerSideDatasource(params.options.services));
    }

    if (params.options?.treeData) {
      this.isTreeData = true;
      this.api.setGridOption('treeData', true);

      if (params.options.treeData.serverSide) {
        if (params.options.treeData.serverSide.isServerSideGroup) {
          this.api.setGridOption('isServerSideGroup', params.options.treeData.serverSide.isServerSideGroup);
        }
        if (params.options.treeData.serverSide.getServerSideGroupKey) {
          this.api.setGridOption('getServerSideGroupKey', params.options.treeData.serverSide.getServerSideGroupKey);
        }
      } else if (params.options.treeData.clientSide) {
        this._rowType = 'clientSide';

        this.api.setGridOption('rowData', params.data);
        this.api.setGridOption('getDataPath', params.options.treeData.clientSide.getDataPath);
      }

      if (params.options.treeData.autoGroupColumnDef) {
        this.api.setGridOption('autoGroupColumnDef', {
          headerName: params.options.treeData.autoGroupColumnDef.name,
          maxWidth: params.options.treeData.autoGroupColumnDef.size ?? 240,
          resizable: false,
          sortable: false,
          hide: params.options.treeData.autoGroupColumnDef.hide,
          cellClass: params.options.treeData.autoGroupColumnDef.cellClass,
          cellRenderer: params.options.treeData.autoGroupColumnDef.cellComponent,
          cellRendererParams: {
            checkbox: false,
            suppressCount: true,
            innerRenderer: params.options.treeData.autoGroupColumnDef.innerRenderer,
          },
        });
      }
    }

    const cols = params.colsMetaData ?? this._generateColsMetaData(params.data, params.fieldsOverrides ?? {});
    this._createColsModel(cols, params.fieldsOverrides ?? {}, {
      ...{ dataSearch$: params.options?.services?.getFieldsData$ },
      ...(params.options?.colOptions ?? {}),
    });
    this.api.setGridOption('columnDefs', this._createFields(params.fieldsOverrides));

    this.api.setGridOption('rowSelection', 'single');
    this.api.setGridOption('getRowClass', params.options?.getRowClass);

    if (!params.options || params.options.contextMenuItems.length === 0) {
      this.api.setGridOption('suppressContextMenu', true);
    } else {
      this.api.setGridOption(
        'getContextMenuItems',
        (contextParams: GetContextMenuItemsParams) =>
          params.options?.contextMenuItems.map(item => ({
            name: `grid.context-menu-item.${item}`,
            menuItem: ContextMenuItemComponent,
            action: () => this.contextMenuAction$.next({ action: item, item: contextParams.node?.data }),
            icon: 'arrow-go-forward-line',
          })) ?? []
      );
    }

    this.api.setGridOption('onRowClicked', (event: RowClickedEvent) => this._onSelectionChanged(event));
    this.api.setGridOption('onFilterChanged', () => {
      this.filters.filtersChanged$.next(Date.now());
      this.computedFiltersData();
    });

    if (params.options?.domLayout) {
      this.api.setGridOption('domLayout', params.options.domLayout);
    }

    if (params.options?.isFullWidthRow) {
      this.api.setGridOption('isFullWidthRow', params.options.isFullWidthRow);
    }
    if (params.options?.getRowHeight) {
      this.api.setGridOption('getRowHeight', params.options.getRowHeight);
    }
    if (params.options?.fullWidthCellRenderer) {
      this.api.setGridOption('fullWidthCellRenderer', params.options.fullWidthCellRenderer);
    }

    if (this.filters.filterModelSource) {
      this.filters.applyFilterModel(this.filters.filterModelSource, FilterModelSource.storage);
    }

    this.ready$.next(true);
    this.computedFiltersData();
  }

  public switchViewDefault(type: GridViewType) {
    this.switchView((localStorage.getItem(gridViewKey + this.scope) as GridViewType) ?? type, false);
  }
  public switchView(type: GridViewType, save = true) {
    this.displayType = type;
    if (save) {
      localStorage.setItem(gridViewKey + this.scope, type);
    }
  }

  public switchTreeMode(value: boolean) {
    this.treeMode = value;
  }

  public getTags(): { key: string; values: ActiveFilterTag[] }[] {
    const filters = this.api?.getFilterModel();

    if (!filters) {
      return [];
    }
    return Object.keys(filters)
      .map(key => ({
        key,
        values: this.filters.formatFilter(key),
      }))
      .filter(f => f.values.length > 0);
  }
  public removeTag(tag: ActiveFilterTag) {
    const model = this.api?.getFilterModel();
    if (!model) {
      return;
    }
    model[tag.id] = null;

    this.filters.applyFilterModel({ filterModel: JSON.stringify(model) }, FilterModelSource.storage);
    this.api?.onFilterChanged();
  }
  public getFiltersForm() {
    return this._formService.getFiltersForm(this);
  }

  public computedFiltersData() {
    if (this._rowType === 'clientSide') {
      const filteredValues: T[] = [];
      this.api?.forEachNodeAfterFilter(({ data }) => (data ? filteredValues.push(data) : null));
      this.filteredData$.next(filteredValues);
    }
  }

  private _onSelectionChanged(event: RowClickedEvent) {
    this.cursor.setCurrent(
      (event.rowIndex ?? 0) + event.api.paginationGetCurrentPage() * event.api.paginationGetPageSize(),
      event.data.id
    );
    this.clickedRow$.next(event);
    this.selectedData$.next(this.api!.getSelectedRows());
  }

  private _createColsModel(cols: GridMetaData[], fieldsOverrides: IFieldsOverrides, colOptions: IColOptions) {
    cols
      .map(field =>
        this._factoryCols(field, {
          ...colOptions,
          ...(fieldsOverrides[field.name] ? fieldsOverrides[field.name].colOptions : {}),
        })
      )
      .forEach(field => (this.cols[field.key] = field));
  }

  private _generateColsMetaData(data: T[], fieldsOverrides: IFieldsOverrides): GridMetaData[] {
    return [
      ...data
        .map(item => ObjectKeys(item))
        .reduce((set, current) => {
          current.forEach(item => set.add(<string>item));
          return set;
        }, new Set<string>()),
    ]
      .filter(item => !(<string>item).startsWith('_'))
      .map(item => this._getTypeOfField(data, <keyof T>item, fieldsOverrides[item]?.colOptions ?? {}));
  }

  private _createFields(fieldsOverrides?: { [index: string]: ColDef }): ColDef[] {
    return Object.keys(this.cols)
      .filter(key => !key.startsWith('_'))
      .map(key => {
        const override = fieldsOverrides ? fieldsOverrides[key] || {} : {};
        return { ...this.cols[key].getColDef(), ...override };
      });
  }

  private _factoryCols(col: GridMetaData, colOptions: IColOptions): BaseCol<any> {
    if (this.filters.forcedFilter && this.filters.forcedFilter[col.name]) {
      colOptions.filters = { allow: false };
    }
    switch (col.type) {
      case ParameterType.String:
        return new StringCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.Enum:
        return new EnumCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.Number:
        return new NumberCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.Guid:
        return new GuidCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.DateTime:
        return new DateCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.Boolean:
        return new BoolCol({ scope: this.scope, col: col, options: colOptions }, this);
      case ParameterType.TimeStamp:
        return new TimeCol({ scope: this.scope, col: col, options: colOptions }, this);
      default:
        return new BaseCol({ scope: this.scope, col: col, options: colOptions }, this);
    }
  }
  private _getTypeOfField(data: T[], field: keyof T, colOptions: IColOptions): GridMetaData {
    const value = data.map(entity => entity[field]).filter(isNonNullable)[0];
    if (typeof value === 'string' && isStrictISODateString(value)) {
      return {
        name: field.toString(),
        type: ParameterType.DateTime,
        nullable: false,
        multiSearchEnabled: false,
        meSearchEnabled: false,
        shownByDefault: true,
        showEntireListWhenFiltering: false,
        additionalInfo: [],
        dateTimeKind: DateTimeKind.Date,
      };
    }
    switch (typeof value) {
      case 'boolean':
        return {
          name: field.toString(),
          type: ParameterType.Boolean,
          nullable: false,
          multiSearchEnabled: false,
          meSearchEnabled: false,
          shownByDefault: true,
          showEntireListWhenFiltering: false,
          additionalInfo: [],
        };
      case 'string':
        return {
          name: field.toString(),
          type: ParameterType.String,
          nullable: false,
          multiSearchEnabled: false,
          meSearchEnabled: false,
          shownByDefault: true,
          showEntireListWhenFiltering: false,
          additionalInfo: [],
        };
      case 'number': {
        if (colOptions.enumInfo) {
          return {
            name: field.toString(),
            type: ParameterType.Enum,
            nullable: false,
            multiSearchEnabled: false,
            meSearchEnabled: false,
            shownByDefault: true,
            showEntireListWhenFiltering: false,
            additionalInfo: [],
          };
        }
        return {
          name: field.toString(),
          type: ParameterType.Number,
          nullable: false,
          multiSearchEnabled: false,
          meSearchEnabled: false,
          shownByDefault: true,
          showEntireListWhenFiltering: false,
          additionalInfo: [],
        };
      }
      default:
        return {
          name: field.toString(),
          type: ParameterType.String,
          nullable: false,
          multiSearchEnabled: false,
          meSearchEnabled: false,
          shownByDefault: true,
          showEntireListWhenFiltering: false,
          additionalInfo: [],
        };
    }
  }

  private _createServerSideDatasource(service: IDataService<T>) {
    const dataSource: IServerSideDatasource = {
      getRows: (params: IServerSideGetRowsParams) => {
        if (this.filters.forcedFilter) {
          params.request.filterModel = {
            ...params.request.filterModel,
            ...this.filters.forcedFilter,
          };
        }
        this.cursor.setRequestParams(params);
        service
          .getChildren$(params)
          .pipe(take(1))
          .subscribe(rows => {
            params.success({
              rowData: rows.items,
              rowCount: rows.totalCount,
            });
            this.api?.paginationGoToPage(this.filters.paginationStorage ?? 0);
          });
      },
    };
    return dataSource;
  }
}
