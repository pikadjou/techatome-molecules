import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';

import {
  AdvancedFilterModel,
  ColDef,
  JoinAdvancedFilterModel,
  NumberAdvancedFilterModel,
  ScalarAdvancedFilterModelType,
  IFilterParams,
} from 'ag-grid-enterprise';

import { InputLabel, InputNumber, InputPanel } from '@camelot/form-model';
import { CamFormInputsModule } from '@camelot/form-input';
import { isNonNullable } from '@camelot/utils';

import { ActiveFilterTag } from '../../../../components/filters/types';
import { BaseCol, BaseFilterComponent, operatorMap } from './base-col';

type FilterTyping = JoinAdvancedFilterModel | NumberAdvancedFilterModel;
export class NumberCol extends BaseCol<FilterTyping> {
  public override getColDef(): ColDef {
    return { ...super.getColDef(), ...{ filter: NumberFilterComponent } };
  }

  public override getInputForm(fromView: boolean) {
    const max = this._extractFiltersByFilterType(this.filterInstance, [
      'lessThan',
      'lessThanOrEqual',
    ])
      .filter((cond) => cond.filterType === 'number')
      .map((cond: any) => cond.filter)
      .filter(isNonNullable)[0];
    const min = this._extractFiltersByFilterType(this.filterInstance, [
      'greaterThan',
      'greaterThanOrEqual',
    ])
      .filter((cond) => cond.filterType === 'number')
      .map((cond: any) => cond.filter)
      .filter(isNonNullable)[0];

    return new InputPanel({
      key: 'number-panel',
      contentClass: 'row g-0',
      children: [
        new InputLabel({
          key: 'number-panel-label',
          label: this.inputLabel,
          class: 'col-12',
        }),
        new InputNumber({
          key: this.key + '#min',
          label: 'min',
          class: fromView ? 'col-12' : 'col-6 pe-1',
          value: min?.toString(),
        }),
        new InputNumber({
          key: this.key + '#max',
          label: 'max',
          class: fromView ? 'col-12' : 'col-6 ps-1',
          value: max?.toString(),
        }),
      ],
    });
  }
  public override getFiltersModel(data: any): FilterTyping | null {
    const keys = Object.keys(data).filter((key) => key.startsWith(this.key));

    if (keys.length === 0) {
      return null;
    }
    const filters = keys.reduce<NumberAdvancedFilterModel[]>((acc, key) => {
      const type = key.split('#')[1] || 'min';
      const value = Number(data[key]) ?? null;

      if (value) {
        acc.push({
          filterType: 'number',
          colId: this.key,
          type: this._getTypeOperator(type),
          filter: value,
        });
      }
      return acc;
    }, []);

    if (filters.length === 0) {
      return null;
    }
    if (filters.length === 1) {
      return filters[0];
    }
    return {
      filterType: 'join',
      type: 'AND',
      conditions: filters,
    };
  }

  private _getTypeOperator(type: string): ScalarAdvancedFilterModelType {
    if (type === 'max') {
      return 'lessThanOrEqual';
    }
    if (type === 'min') {
      return 'greaterThanOrEqual';
    }
    return 'notBlank';
  }
}

@Component({
  standalone: true,
  imports: [CamFormInputsModule, NgIf, NgFor],
  template: `
    <div *ngIf="this.input" class="p-space-sm">
      <div *ngFor="let input of this.children">
        <cam-input-textbox
          [input]="$any(this.input)"
          (valueChanged)="this.valueChanged()"
        ></cam-input-textbox>
      </div>
    </div>
  `,
})
export class NumberFilterComponent extends BaseFilterComponent<
  JoinAdvancedFilterModel | NumberAdvancedFilterModel,
  NumberCol
> {
  get children() {
    return this.input?.children.filter((i) => i.type === 'number');
  }
  override agInit(params: IFilterParams) {
    super.agInit(params);
  }
  override getTags(model?: AdvancedFilterModel | null): ActiveFilterTag[] {
    if (!model) {
      model = this._model;
    }
    if (!model) {
      return [];
    }
    if (model.filterType === 'number') {
      if (model.filter === undefined) {
        return [];
      }
      const operator = operatorMap[model.type] || model.type;
      return [
        {
          id: model.colId,
          name: `${operator} ${model.filter}`,
        },
      ];
    }
    if (model.filterType === 'join') {
      // Transformation pour JoinAdvancedFilterModel
      return model.conditions.flatMap((condition) => this.getTags(condition));
    }

    console.log('Unsupported filter type');
    return [];
  }

  public valueChanged() {
    const data = this.children
      ?.map((child) => ({ id: child.key, value: child.value }))
      .reduce<{ [index: string]: number }>((acc, child) => {
        acc[child.id] = child.value;
        return acc;
      }, {});

    this.apply(data);
  }
}
