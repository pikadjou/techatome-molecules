import { formatDate, NgIf } from '@angular/common';
import { Component } from '@angular/core';

import {
  AdvancedFilterModel,
  ColDef,
  DateAdvancedFilterModel,
  JoinAdvancedFilterModel,
  ScalarAdvancedFilterModelType,
  IFilterParams,
} from 'ag-grid-enterprise';

import { CamFormInputsModule } from '@camelot/form-input';
import { InputDatePicker } from '@camelot/form-model';
import { ObjectKeys } from '@camelot/utils';

import { ActiveFilterTag } from '../../../../components/filters/types';
import {
  GridDateCellComponent,
  GridDateTimeCellComponent,
} from '../../components/ag-grid/template/date.component';
import { BaseCol, BaseFilterComponent, operatorMap } from './base-col';
import { addDays, isDate } from 'date-fns';
import { DateTimeKind } from '../../services/dto/metadata';

type FilterTyping = JoinAdvancedFilterModel | DateAdvancedFilterModel;

export class DateCol extends BaseCol<FilterTyping> {
  public override getInputForm() {
    return new InputDatePicker({
      key: this.key,
      label: this.inputLabel,
      rangeEnabled: true,
    });
  }

  public override getFiltersModel(data: any): FilterTyping | null {
    const value = data[this.key];
    if (!value) {
      return null;
    }
    if (isDate(value)) {
      return {
        filterType: 'join',
        type: 'AND',
        conditions: [
          {
            filterType: 'date',
            colId: this.key,
            type: 'greaterThanOrEqual',
            filter: value,
          },
          {
            filterType: 'date',
            colId: this.key,
            type: 'lessThanOrEqual',
            filter: <any>addDays(value, 1),
          },
        ],
      };
    }
    const filters = ObjectKeys(value).reduce<DateAdvancedFilterModel[]>(
      (acc, key) => {
        const data = value[key] ?? null;

        if (data) {
          acc.push({
            filterType: 'date',
            colId: this.key,
            type: this._getTypeOperator(key.toString()),
            filter: data,
          });
        }
        return acc;
      },
      []
    );

    if (filters.length === 0) {
      return null;
    }
    if (filters.length === 1) {
      return filters[0];
    }
    return {
      filterType: 'join',
      type: 'AND',
      conditions: filters,
    };
  }

  public override getColDef(): ColDef {
    return {
      ...super.getColDef(),
      ...{
        type: 'date',
        filter: DateFilterComponent,
        cellRenderer:
          this.data.col.dateTimeKind === DateTimeKind.Date
            ? GridDateCellComponent
            : GridDateTimeCellComponent,
      },
    };
  }

  private _getTypeOperator(type: string): ScalarAdvancedFilterModelType {
    if (type === 'end') {
      return 'lessThanOrEqual';
    }
    if (type === 'start') {
      return 'greaterThanOrEqual';
    }
    return 'notBlank';
  }
}

@Component({
  standalone: true,
  imports: [CamFormInputsModule, NgIf],
  template: `
    <div *ngIf="this.input" class="p-space-sm">
      <cam-input-date-picker [input]="$any(this.input)"></cam-input-date-picker>
    </div>
  `,
})
export class DateFilterComponent extends BaseFilterComponent<
  JoinAdvancedFilterModel | DateAdvancedFilterModel,
  DateCol
> {
  override agInit(params: IFilterParams) {
    super.agInit(params);
  }

  override getTags(model?: AdvancedFilterModel | null): ActiveFilterTag[] {
    if (!model) {
      model = this._model;
    }
    if (!model) {
      return [];
    }
    if (model.filterType === 'date') {
      if (model.filter === undefined) {
        return [];
      }

      const operator = operatorMap[model.type] || model.type;

      return [
        {
          id: model.colId,
          name: `${operator} ${formatDate(model.filter, 'shortDate', 'fr')}`,
        },
      ];
    }
    if (model.filterType === 'join') {
      // Transformation pour JoinAdvancedFilterModel
      return model.conditions.flatMap((condition) => this.getTags(condition));
    }

    console.log('Unsupported filter type');
    return [];
  }
}
