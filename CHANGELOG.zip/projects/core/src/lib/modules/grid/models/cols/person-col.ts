import { StringCol } from './string-col';

export class PersonCol extends StringCol {}
