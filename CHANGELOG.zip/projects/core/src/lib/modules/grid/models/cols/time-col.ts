import { NgIf, formatDate } from '@angular/common';
import { Component } from '@angular/core';

import {
  AdvancedFilterModel,
  ColDef,
  DateAdvancedFilterModel,
  IFilterParams,
  JoinAdvancedFilterModel,
} from 'ag-grid-enterprise';

import { CamFormModule } from '@camelot/form-basic';
import { CamFormInputsModule } from '@camelot/form-input';

import { ActiveFilterTag } from '../../../../components/filters/types';
import { GridTimeCellComponent } from '../../components/ag-grid/template/date.component';
import { BaseFilterComponent, operatorMap } from './base-col';
import { DateCol } from './date-col';

export class TimeCol extends DateCol {
  public override getColDef(): ColDef {
    return {
      ...super.getColDef(),
      ...{
        type: 'date',
        filter: TimeFilterComponent,
        cellRenderer: GridTimeCellComponent,
      },
    };
  }
}

@Component({
  standalone: true,
  imports: [CamFormModule, NgIf, CamFormInputsModule],
  template: `
    <div *ngIf="this.input" class="p-space-sm">
      <cam-input-date-picker [input]="$any(this.input)"></cam-input-date-picker>
    </div>
  `,
})
export class TimeFilterComponent extends BaseFilterComponent<
  JoinAdvancedFilterModel | DateAdvancedFilterModel,
  TimeCol
> {
  override agInit(params: IFilterParams) {
    super.agInit(params);
  }

  override getTags(model?: AdvancedFilterModel | null): ActiveFilterTag[] {
    if (!model) {
      model = this._model;
    }
    if (!model) {
      return [];
    }
    if (model.filterType === 'date') {
      if (model.filter === undefined) {
        return [];
      }
      const operator = operatorMap[model.type] || model.type;
      return [
        {
          id: model.colId,
          name: `${operator} ${formatDate(model.filter, 'shortDate', 'fr')}`,
        },
      ];
    }
    if (model.filterType === 'join') {
      return model.conditions.flatMap(condition => this.getTags(condition));
    }

    console.log('Unsupported filter type');
    return [];
  }
}
