import { IServerSideGetRowsParams } from 'ag-grid-enterprise';

export class CamGridCursor {
  private _requestParams: IServerSideGetRowsParams | null = null;
  private _currentRowIndex = 0;
  private _currentId = '';

  get currentRowIndex() {
    return this._currentRowIndex;
  }
  get currentId() {
    return this._currentId;
  }
  constructor() {}

  public getRequestParams() {
    return this._requestParams;
  }
  public setRequestParams(params: IServerSideGetRowsParams) {
    this._requestParams = { ...params, request: JSON.parse(JSON.stringify(params.request)) };
  }

  public setCurrent(index: number, id: string) {
    this._currentId = id;
    this._currentRowIndex = index;
  }
  public next(id: string) {
    this._currentRowIndex = this._currentRowIndex + 1;
    this._currentId = id;
  }
  public previous(id: string) {
    this._currentRowIndex = this._currentRowIndex - 1;
    this._currentId = id;
  }
}
