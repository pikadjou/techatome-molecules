import { NgFor } from '@angular/common';
import { Component } from '@angular/core';

import {
  AdvancedFilterModel,
  ColDef,
  IFilterParams,
  JoinAdvancedFilterModel,
  NumberAdvancedFilterModel,
} from 'ag-grid-enterprise';
import { of } from 'rxjs';

import { InputDropdown } from '@camelot/form-model';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule, CriticityStatus, criticityLabel } from '@camelot/ui';
import { CamDirectivePipeModule, extractEnum, isNonNullable } from '@camelot/utils';

import { ActiveFilterTag } from '../../../../components/filters/types';
import { GridCriticityCellComponent } from '../../components/ag-grid/template/criticity.component';
import { BaseCol, BaseFilterComponent } from './base-col';

type FilterTyping = JoinAdvancedFilterModel | NumberAdvancedFilterModel;

export class EnumCol extends BaseCol<FilterTyping> {
  get values() {
    return this._extractFiltersByFilterType(this.filterInstance, ['equals'])
      .filter(cond => cond.filterType === 'number')
      .map((cond: any) => cond.filter?.toString())
      .filter(isNonNullable);
  }
  public override getInputForm() {
    const enumValue = this.getEnumInfo().values;

    return new InputDropdown({
      key: this.key,
      label: this.inputLabel,
      value: this.values,
      class: 'pb-2',
      options: of(enumValue),
      multiple: true,
    });
  }
  public override getFiltersModel(data: any): FilterTyping | null {
    const value = data[this.key];
    if (!value) {
      return null;
    }

    if (!Array.isArray(value)) {
      return {
        filterType: 'number',
        colId: this.key,
        type: 'equals',
        filter: Number(value),
      };
    }
    const filters = value.reduce<NumberAdvancedFilterModel[]>((acc, val) => {
      if (val) {
        acc.push({
          filterType: 'number',
          colId: this.key,
          type: 'equals',
          filter: Number(val),
        });
      }
      return acc;
    }, []);

    if (filters.length === 0) {
      return null;
    }
    if (filters.length === 1) {
      return filters[0];
    }
    return {
      filterType: 'join',
      type: 'OR',
      conditions: filters,
    };
  }

  public override getColDef(): ColDef {
    const cellRenderer = this.getEnumInfo().cellRenderer;
    return {
      ...super.getColDef(),
      ...{
        type: 'string',
        filter: EnumFilterComponent,
        cellRenderer: cellRenderer,
      },
    };
  }

  public getEnumInfo(): {
    cellRenderer: any | null;
    enum: any | null;
    values: {
      id: string;
      name: string;
    }[];
  } {
    if (this.data.options.enumInfo) {
      return this.data.options.enumInfo;
    }
    switch (this.data.col.enumName) {
      case 'Criticity':
        return {
          cellRenderer: GridCriticityCellComponent,
          enum: CriticityStatus,
          values: extractEnum(CriticityStatus, true).map(value => ({
            id: value.value.toString(),
            name: criticityLabel(value.value),
          })),
        };
      default:
        return { cellRenderer: null, enum: null, values: [] };
    }
  }
}

@Component({
  standalone: true,
  imports: [NgFor, CamDirectivePipeModule, CamUiModule, TranslatePipe],
  template: `
    <div class="p-space-sm">
      <div
        *ngFor="let value of this.values"
        class="flex-start g-space-sm align-center p-space-sm"
        (click)="this.toggle(value.id)"
      >
        <input type="checkbox" [checked]="this.isSelected(value.id)" />
        <cam-text>
          {{ value.name | translate }}
        </cam-text>
      </div>
    </div>
  `,
})
export class EnumFilterComponent extends BaseFilterComponent<
  JoinAdvancedFilterModel | NumberAdvancedFilterModel,
  EnumCol
> {
  get values() {
    return this._col?.getEnumInfo().values ?? [];
  }
  public selectedIds: string[] = [];

  override agInit(params: IFilterParams) {
    super.agInit(params);

    this.selectedIds = this._col?.values ?? [];
  }

  override isFilterActive(): boolean {
    this.selectedIds = this._col?.values ?? [];
    return true;
  }

  override getTags(model?: AdvancedFilterModel | null): ActiveFilterTag[] {
    if (!model) {
      model = this._model;
    }
    if (!model) {
      return [];
    }
    if (model.filterType === 'number') {
      if (model.filter === undefined) {
        return [];
      }
      const value = this._col?.getEnumInfo().values.find(v => v.id == (<any>model).filter?.toString())?.name;

      if (!value) {
        return [];
      }
      return [
        {
          id: model.colId,
          name: value,
        },
      ];
    }
    if (model.filterType === 'join') {
      return model.conditions.flatMap(condition => this.getTags(condition));
    }

    console.log('Unsupported filter type');
    return [];
  }

  override apply() {
    const data: any = [];
    data[this._col?.key ?? ''] = this.selectedIds;

    super.apply(data);
  }
  public toggle(id: string) {
    if (this.isSelected(id)) {
      this.selectedIds = this.selectedIds.filter(selectedId => selectedId !== id);
    } else {
      this.selectedIds.push(id);
    }

    this.apply();
  }
  public isSelected(id: string) {
    return this.selectedIds.includes(id);
  }
}
