import { SortDirection } from 'ag-grid-enterprise';

import { SortOption } from '../services/dto/view';

export const gridViewKey = 'gridViewKey-';
export const getPaginationKey = (scope: string) => `${scope}_pagination`;
export const getViewKey = (scope: string) => `${scope}_viewSelected`;
export const getFilterModelStorageKey = (scope: string) => `${scope}_filterModelStorage`;
export const convertSortAgGridToSortDto = (sort?: SortDirection | null): SortOption | null => {
  switch (sort) {
    case 'asc':
      return SortOption.Ascending;
    case 'desc':
      return SortOption.Descending;
    default:
      return null;
  }
};
