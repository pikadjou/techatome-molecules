import { StringCol } from './string-col';

export class GuidCol extends StringCol {}
