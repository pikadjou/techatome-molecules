import {
  AdvancedFilterModel,
  ColDef,
  GetDataPath,
  GridApi,
  ICellRendererParams,
  IServerSideGetRowsParams,
} from 'ag-grid-enterprise';
import { Observable } from 'rxjs';

import { FielOptions } from '../services/dto/view';
import { BaseCol, IColOptions } from './cols/base-col';

export interface IGridData<T> {
  scope: string;
  api: GridApi<T> | null;
  cols: { [index: string]: BaseCol<any> };
  computedFiltersData(): void;
}

export type ContentMenuAction = 'separator' | 'openInExternalLink';

export enum FilterModelSource {
  view = 0,
  storage = 1,
  preSelected = 2,
}
export interface IFilterModelStorage {
  filterModel?: string;
  selectedFields?: string[];
  fieldOptions?: FielOptions[];
}
export interface IFieldsOverrides {
  [index: string]: ColDef & { colOptions?: IColOptions };
}
export interface ITreeData<T> {
  clientSide?: {
    getDataPath: GetDataPath<T>;
  };
  serverSide?: {
    isServerSideGroup?: (dataItem: T) => boolean;
    getServerSideGroupKey?: (dataItem: T) => string;
  };
  autoGroupColumnDef?: ColDef & {
    name: string;
    size: number;
    innerRenderer: (params: ICellRendererParams) => any;
    cellComponent?: any;
  };
}
export interface IDataService<T> {
  getChildren$: (params: IServerSideGetRowsParams<T>) => Observable<{ items: T[]; totalCount: number }>;
  getFieldsData$?: (search: string, colId: string) => Observable<string[]>;
}

export interface IForcedFilter {
  [colId: string]: AdvancedFilterModel;
}
export type GridViewType = 'grid' | 'card';
