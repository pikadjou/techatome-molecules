import { ICellRendererAngularComp, IHeaderAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, IHeaderParams } from 'ag-grid-community';

export class AbstractHeaderComponent<TData, TValue>
  implements IHeaderAngularComp
{
  public params!: IHeaderParams;

  agInit(params: IHeaderParams): void {
    this.params = params;
  }

  refresh(params: IHeaderParams) {
    return false;
  }
}

export class AbstractCellComponent<TData, TValue, TRow = any>
  implements ICellRendererAngularComp
{
  public params!: ICellRendererParams;
  public value: TValue | null = null;

  protected _data: TRow | null = null;
  protected _item: TData | null = null;

  agInit(params: ICellRendererParams<TRow & { _brutContent: TData }, TValue>) {
    this.params = params;
    this.value = params.value ?? null;

    this._item = params.data?._brutContent ?? null;
    this._data = params.node.data ?? null;
  }

  refresh(params: ICellRendererParams) {
    return true;
  }
}
