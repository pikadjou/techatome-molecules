import { Component } from '@angular/core';

import { AbstractCellComponent } from '../../abstract';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  template: `{{
    (this.value === true ? 'grid.common.true' : 'grid.common.false') | translate
  }}`,
})
export class GridBoolCellComponent extends AbstractCellComponent<
  any,
  boolean
> {}
