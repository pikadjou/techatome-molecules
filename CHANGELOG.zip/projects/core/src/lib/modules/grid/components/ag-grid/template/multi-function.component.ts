import { Component } from '@angular/core';

import { AbstractCellComponent } from '../../abstract';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  template: `
    <div class="flex-start align-center g-space-xs" style="height: 100%;">
      <cam-label *ngFor="let value of this.value" size="sm" class="d-flex">
        {{ value.name }}
      </cam-label>
    </div>
  `,
})
export class GridMultiFunctionCellComponent extends AbstractCellComponent<any, Function[]> {}
