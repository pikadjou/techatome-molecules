import { Component } from '@angular/core';

import { ILoadingCellRendererAngularComp } from 'ag-grid-angular';
import { ILoadingCellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'cam-ag-grid-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss'],
})
export class LoadingComponent implements ILoadingCellRendererAngularComp {
  public params!: ILoadingCellRendererParams;

  agInit(params: ILoadingCellRendererParams): void {
    this.params = params;
  }
}
