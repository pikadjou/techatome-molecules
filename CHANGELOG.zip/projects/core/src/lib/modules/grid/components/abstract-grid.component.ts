import { Component, Input, OnInit, inject } from '@angular/core';

import { GridApi, GridReadyEvent } from 'ag-grid-enterprise';

import { CamBaseComponent } from '@camelot/utils';

import { CamGridData } from '../models/grid-data';
import { CamGridDataService } from '../services/grid-data.service';

@Component({ template: '' })
export abstract class AbstractGridComponent<T> extends CamBaseComponent implements OnInit {
  @Input()
  gridId!: string;

  get filteredData$() {
    return this._grid.filteredData$;
  }
  protected _grid!: CamGridData<T>;
  protected _createGrid = true;

  private _dataService = inject(CamGridDataService);

  constructor() {
    super();
  }

  ngOnInit() {
    this._grid = this._dataService.get(this.gridId, this._createGrid);
  }

  public onGridReady(event: GridReadyEvent<unknown>) {
    this._grid.setApi(event.api as unknown as GridApi<T>);
  }
}
