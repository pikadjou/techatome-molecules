import { Component } from '@angular/core';

import { IMenuItemAngularComp } from 'ag-grid-angular';
import { IMenuItemParams } from 'ag-grid-community';

import { CamIconsModule } from '@camelot/icons';
import { TranslatePipe } from '@camelot/translation';
import { CamUiModule } from '@camelot/ui';

export interface CustomMenuItemParams extends IMenuItemParams {
  action: () => void;
  icon: string;
}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  template: `<div class="p-space-md flex-start g-space-sm align-center" (click)="this.select()">
    @if (this.params && this.params.icon) {
      <cam-font-icon [name]="this.params.icon" type="sm"></cam-font-icon>
    }
    <cam-text size="sm"> {{ this.params?.name ?? '' | translate }}</cam-text>
  </div>`,
  standalone: true,
  imports: [TranslatePipe, CamUiModule, CamIconsModule],
})
export class ContextMenuItemComponent implements IMenuItemAngularComp {
  public params: CustomMenuItemParams | null = null;

  agInit(params: CustomMenuItemParams) {
    this.params = params;
  }
  public select() {
    if (!this.params || !this.params.action) {
      return;
    }
    this.params.action();
  }
}
