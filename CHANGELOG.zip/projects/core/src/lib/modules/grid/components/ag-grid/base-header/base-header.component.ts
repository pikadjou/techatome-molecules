import { Component, Input } from '@angular/core';

import { IHeaderParams } from 'ag-grid-community';

import { GridContext } from '../../../models/grid-data';
import { FilterModelSource } from '../../../models/types';

@Component({
  selector: 'cam-ag-grid-base-header',
  templateUrl: './base-header.component.html',
  styleUrls: ['./base-header.component.scss'],
})
export class BaseHeaderComponent {
  @Input()
  params!: IHeaderParams<unknown, GridContext>;

  get filterEnabled() {
    return this.params.column.getColDef().menuTabs?.length ?? 0 > 0;
  }
  get haveFilterActivate() {
    return this.params.column.isFilterActive();
  }
  get sortEnabled() {
    return this.params.enableSorting ?? true;
  }
  get sortAscending() {
    return this.params.column.isSortAscending();
  }
  get sortDescending() {
    return this.params.column.isSortDescending();
  }

  showFilter(div: HTMLDivElement) {
    if (div) {
      this.params.showColumnMenu(div);
    }
  }
  toggleSort() {
    if (!this.sortEnabled) {
      return;
    }
    const order = this.params.column.isSortAscending() ? 'desc' : 'asc';
    this.params.setSort(order);

    this.params.context.grid.filters.applyFilterModel({}, FilterModelSource.storage);
  }

  refresh(params: IHeaderParams) {
    return false;
  }
}
