import { Component, TemplateRef, ViewChild } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';

import {
  BottomSheetTemplateGenericComponent,
  BottomSheetTemplateGenericParams,
} from '@camelot/menu';

import { AbstractGridComponent } from '../../../abstract-grid.component';

@Component({
  selector: 'cam-fields-selection-displayer',
  templateUrl: './fields-selection-displayer.component.html',
  styleUrls: ['./fields-selection-displayer.component.scss'],
})
export class FieldsSelectionDisplayerComponent extends AbstractGridComponent<any> {
  @ViewChild('template', { read: TemplateRef })
  template!: TemplateRef<void>;

  get mobileDetection() {
    return this.breakpoints.isMobile;
  }

  private _isOpen = false;
  get isOpen() {
    return this._isOpen;
  }
  set isOpen(value: boolean) {
    this._isOpen = value;

    if (this.mobileDetection) {
      if (value) {
        this._bottomSheet.open<
          BottomSheetTemplateGenericComponent,
          BottomSheetTemplateGenericParams<null>
        >(BottomSheetTemplateGenericComponent, {
          panelClass: 'no-padding',
          data: {
            template: this.template,
            context: null,
          },
        });
      } else {
        this._bottomSheet.dismiss();
      }
    }
  }

  constructor(private _bottomSheet: MatBottomSheet) {
    super();
  }

  public selected(filters: any) {
    this.close();
  }

  public open() {
    this.isOpen = true;
  }
  public close() {
    this.isOpen = false;
  }
}
