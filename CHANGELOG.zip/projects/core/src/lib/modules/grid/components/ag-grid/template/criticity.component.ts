import { Component } from '@angular/core';

import { CamUiModule, CriticityStatus } from '@camelot/ui';

import { AbstractCellComponent } from '../../abstract';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  standalone: true,
  imports: [CamUiModule],
  template: `<div class="align-center" style="height: 100%">
    <cam-criticity [criticity]="this.criticity"></cam-criticity>
  </div>`,
})
export class GridCriticityCellComponent extends AbstractCellComponent<
  any,
  CriticityStatus
> {
  get criticity() {
    return this.value ?? CriticityStatus.Unknown;
  }
}
