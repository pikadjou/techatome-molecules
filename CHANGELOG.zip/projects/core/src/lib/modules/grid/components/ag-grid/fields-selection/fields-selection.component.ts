import { Component } from '@angular/core';

import { Column } from 'ag-grid-enterprise';

import { FilterModelSource } from '../../../models/types';
import { AbstractGridComponent } from '../../abstract-grid.component';

@Component({
  selector: 'cam-fields-selection',
  templateUrl: './fields-selection.component.html',
  styleUrls: ['./fields-selection.component.scss'],
})
export class FieldsSelectionComponent extends AbstractGridComponent<any> {
  get grid() {
    return this._grid;
  }

  public getColumns(): Column[] {
    return (
      this.grid.api?.getColumns()?.sort((a, b) => {
        if (a.isVisible() && b.isVisible()) {
          return (a.getSortIndex() ?? 0) - (b.getSortIndex() ?? 0);
        }
        return a.isVisible() && !b.isVisible() ? -1 : 1;
      }) ?? []
    );
  }
  public toggle(col: Column) {
    this.grid.api?.setColumnsVisible([col], !col.isVisible());
    const extract = this.grid.filters.extractCurrentFilterModel();
    this.grid.filters.applyFilterModel({ selectedFields: extract.selectedFields }, FilterModelSource.storage);
  }
}
