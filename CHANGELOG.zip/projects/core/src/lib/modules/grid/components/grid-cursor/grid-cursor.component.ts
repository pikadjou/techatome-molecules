import { Component, Input, inject, signal } from '@angular/core';

import { CamIconsModule } from '@camelot/icons';
import { TranslatePipe } from '@camelot/translation';
import { CamContainerModule, CamUiModule } from '@camelot/ui';

import { CamGridCursorService } from '../../services/grid-cursor.service';
import { AbstractGridComponent } from '../abstract-grid.component';

type Type = 'next' | 'previous';

@Component({
  selector: 'cam-grid-cursor',
  standalone: true,
  imports: [CamUiModule, CamContainerModule, CamIconsModule, TranslatePipe],
  templateUrl: './grid-cursor.component.html',
  styleUrl: './grid-cursor.component.scss',
})
export class GridCursorComponent extends AbstractGridComponent<unknown> {
  @Input()
  navigation!: (id: string) => void;

  get grid() {
    return this._grid;
  }

  public readonly cursorList = signal<{ id: string }[]>([]);
  private readonly _cursorServices = inject(CamGridCursorService);

  protected override _createGrid = false;

  constructor() {
    super();
  }
  override ngOnInit() {
    super.ngOnInit();
    this._fetch();
  }

  public have(type: Type) {
    return !!this._getId(type);
  }
  public next() {
    if (!this._grid || !this.have('next')) {
      return;
    }
    this._goTo('next');
  }

  public previous() {
    if (!this._grid || !this.have('previous')) {
      return;
    }

    this._goTo('previous');
  }

  private _fetch() {
    this.requestState.asked();
    if (!this._grid) {
      return;
    }
    this._cursorServices.getCursor$(this.gridId, this._grid.cursor).subscribe({
      next: data => {
        this.cursorList.set(data);
        this.requestState.completed();
      },
    });
  }

  private _goTo(type: Type) {
    const id = this._getId(type);

    if (!id) {
      return;
    }
    if (type === 'next') {
      this._grid.cursor.next(id ?? '');
    } else {
      this._grid.cursor.previous(id ?? '');
    }
    this.navigation(id);
  }

  private _getId(type: Type): string | null {
    const list = this.cursorList();
    const currentIndex = list.findIndex(entity => entity.id === this._grid.cursor.currentId);

    if (currentIndex === -1) {
      return null;
    }

    if (type === 'next' && currentIndex < list.length - 1) {
      return list[currentIndex + 1]?.id ?? null;
    }

    if (type === 'previous' && currentIndex > 0) {
      return list[currentIndex - 1]?.id ?? null;
    }

    return null;
  }
}
