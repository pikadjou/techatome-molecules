import { Component } from '@angular/core';

import { ActiveFilterTag } from '../../../../components/filters/types';
import { AbstractGridComponent } from '../abstract-grid.component';

@Component({
  selector: 'cam-grid-tag',
  templateUrl: './grid-tag.component.html',
  styleUrls: ['./grid-tag.component.scss'],
})
export class GridTagComponent extends AbstractGridComponent<any> {
  public tagsList: {
    key: string;
    values: ActiveFilterTag[];
  }[] = [];

  override ngOnInit() {
    super.ngOnInit();
    this._registerSubscription(
      this._grid.filters.filtersChanged$.subscribe(() => (this.tagsList = this._grid.getTags()))
    );
    this.tagsList = this._grid.getTags();
  }
  public getTotalRow() {
    return this._grid.api?.getModel()?.getRowCount() ?? 0;
  }

  public searchTerm(): string | null {
    return this._grid.api?.getQuickFilter() ?? null;
  }

  public removeSearch() {
    this._grid.filters.applySearch('');
  }
  public removedFilter = (value: ActiveFilterTag) => {
    this._grid.removeTag(value);
  };

  public reset() {
    this._grid.filters.resetFilters();
  }
}
