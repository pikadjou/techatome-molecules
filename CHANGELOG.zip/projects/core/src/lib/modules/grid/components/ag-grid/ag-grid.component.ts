import { Component, Input, OnInit, TemplateRef } from '@angular/core';

import { GridReadyEvent } from 'ag-grid-community';
import { GridOptions, GridReadyEvent as PGridReadyEvent } from 'ag-grid-enterprise';

import { IColOptions } from '../../models/cols/base-col';
import {
  ContentMenuAction,
  GridViewType,
  IDataService,
  IFieldsOverrides,
  IForcedFilter,
  ITreeData,
} from '../../models/types';
import { GridMetaData } from '../../services/dto/metadata';
import { AbstractGridComponent } from '../abstract-grid.component';
import { CustomHeaderComponent } from '../custom-header/custom-header.component';
import { LoadingComponent } from './loading/loading.component';

const breakpointsMap = {
  1500: 18,
  1200: 15,
  1000: 13,
  800: 10,
  600: 8,
  400: 6,
  200: 4,
};
@Component({
  selector: 'cam-ag-grid',
  templateUrl: './ag-grid.component.html',
  styleUrls: ['./ag-grid.component.scss'],
})
export class AgGridComponent<T = any> extends AbstractGridComponent<T> implements OnInit {
  @Input()
  cardTemplate!: TemplateRef<{ items: T[] }>;

  @Input()
  data!: T[];

  @Input()
  defaultDisplay: GridViewType = 'card';

  @Input()
  colsMetaData: GridMetaData[] | null = null;

  @Input()
  forcedFilter: IForcedFilter = {};

  @Input()
  fieldsOverrides: IFieldsOverrides = {};

  @Input()
  colOptions: IColOptions = {};

  @Input()
  clientTreeData: ITreeData<T> | null = null;

  @Input()
  services: IDataService<T> | null = null;

  @Input()
  treeData: ITreeData<T> | null = null;

  @Input()
  contextMenuItems: ContentMenuAction[] = [];

  @Input()
  autoSizeAllColumns = true;

  @Input()
  gridOptions: Pick<
    GridOptions,
    | 'domLayout'
    | 'getRowClass'
    | 'getRowHeight'
    | 'isFullWidthRow'
    | 'fullWidthCellRenderer'
    | 'suppressDragLeaveHidesColumns'
    | 'cacheBlockSize'
    | 'pagination'
    | 'paginationPageSize'
  > = {};

  public readonly loadingCellRenderer = LoadingComponent;

  get gridHeight() {
    if (this.displayType === 'card') {
      return '0px';
    }
    return this.gridOptions.domLayout === 'autoHeight' ? 'auto' : '800px';
  }

  get displayType() {
    return this._grid.displayType;
  }

  public components: {
    [p: string]: any;
  } = {
    agColumnHeader: CustomHeaderComponent,
  };
  constructor() {
    super();
  }

  override ngOnInit() {
    super.ngOnInit();

    if (this.services) {
      this._grid.switchView('grid', false);
    } else {
      this._grid.switchViewDefault(this.defaultDisplay);
    }

    this.overrideGridOptions();
  }

  override ngOnDestroy() {
    super.ngOnDestroy();
    this._grid.destroy();
  }

  public isReady(event: GridReadyEvent<unknown>) {
    super.onGridReady(event as unknown as PGridReadyEvent);

    this._grid.setData({
      data: this.data,
      colsMetaData: this.colsMetaData,
      fieldsOverrides: this.fieldsOverrides,
      forcedFilter: this.forcedFilter,
      options: {
        ...this.gridOptions,
        ...{
          clientTreeData: this.clientTreeData,
          treeData: this.treeData,
          services: this.services,
          autoSizeAllColumns: this.autoSizeAllColumns,
          colOptions: this.colOptions,
          contextMenuItems: this.contextMenuItems,
        },
      },
    });
  }

  public getRowModelType() {
    return this.services ? 'serverSide' : 'clientSide';
  }

  private overrideGridOptions() {
    this.gridOptions = {
      ...this.gridOptions,
      suppressDragLeaveHidesColumns: true,
      paginationPageSize: this.gridOptions.paginationPageSize
        ? this.gridOptions.paginationPageSize
        : this._getNbShowElements(),
    };
  }

  private _getNbShowElements() {
    const currentHeight = window.innerHeight;

    return (
      Object.entries(breakpointsMap)
        .map(([key, value]) => ({ key: Number(key), value }))
        .filter(item => item.key <= currentHeight)
        .sort((a, b) => b.key - a.key)[0]?.value ?? 1
    );
  }
}
