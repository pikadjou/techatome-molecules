import { Component } from '@angular/core';

import { AbstractGridComponent } from '../../abstract-grid.component';

type PageNumber = {
  number: number;
  icon?: string;
};
@Component({
  selector: 'cam-grid-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
})
export class PaginationComponent extends AbstractGridComponent<any> {
  readonly PageNumber!: { pagenumber: PageNumber };
  readonly maxPageNumber = 10;
  get grid() {
    return this._grid;
  }
  get show() {
    return (this.grid.api?.paginationGetTotalPages() ?? 0) > 1;
  }

  constructor() {
    super();
  }

  public getListPage() {
    if (!this.grid || !this.grid.api) {
      return [];
    }
    const last = this.grid.api.paginationGetTotalPages();

    if (last < this.maxPageNumber) {
      return this._computedPageNumbers(2, last);
    }

    const current = this.grid.api.paginationGetCurrentPage() + 1;
    const rangeStart = Math.floor(current / 10) * 10;
    const rangeEnd = rangeStart + 10;

    return [
      ...(rangeStart <= 1 ? [] : [{ number: rangeStart - 1, icon: 'more-line' }]),
      ...this._computedPageNumbers(rangeStart > 1 ? rangeStart : 2, rangeEnd < last ? rangeEnd : last),
      ...(rangeEnd > last ? [] : [{ number: rangeEnd, icon: 'more-line' }]),
    ];
  }

  public track(_: any, item: PageNumber) {
    return item.number;
  }

  private _computedPageNumbers(start: number, end: number): PageNumber[] {
    const pageNumbers = [];
    for (let i = start; i < end; i++) {
      pageNumbers.push({ number: i });
    }
    return pageNumbers;
  }
}
