import { DatePipe, NgIf } from '@angular/common';
import { Component } from '@angular/core';

import { CamUiModule } from '@camelot/ui';

import { AbstractCellComponent } from '../../abstract';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  template: `<ng-container *ngIf="this.value">
    {{ this.value | date : 'shortDate' }}
  </ng-container>`,
  standalone: true,
  imports: [DatePipe, NgIf],
})
export class GridDateCellComponent extends AbstractCellComponent<any, string> {}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  template: `<ng-container *ngIf="this.value">
    {{ this.value | date : 'short' }}
  </ng-container>`,
  standalone: true,
  imports: [DatePipe, NgIf],
})
export class GridDateTimeCellComponent extends AbstractCellComponent<
  any,
  string
> {}

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: '',
  standalone: true,
  imports: [CamUiModule, NgIf],
  template: `<div class="align-center" style="height: 100%" *ngIf="this.time">
    <cam-duration [startDate]="this.time"></cam-duration>
  </div>`,
})
export class GridTimeCellComponent extends AbstractCellComponent<any, string> {
  get time() {
    return this.value;
  }
}
