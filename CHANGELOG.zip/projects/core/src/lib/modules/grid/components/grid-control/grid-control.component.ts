import { Component, Input, OnInit } from '@angular/core';

import { InputBase } from '@camelot/form-model';

import { GridViewType } from '../../models/types';
import { AbstractGridComponent } from '../abstract-grid.component';

@Component({
  selector: 'cam-grid-control',
  templateUrl: './grid-control.component.html',
  styleUrls: ['./grid-control.component.scss'],
})
export class GridControlComponent extends AbstractGridComponent<any> implements OnInit {
  @Input()
  show: {
    search?: boolean;
    searchPlaceholder?: string;
    views?: boolean;
    fields?: boolean;
    filters?: boolean;
    treeMode?: boolean;
    switchView?: boolean;
  } = {
    filters: false,
    search: true,
    switchView: true,
  };

  public filtersForm!: InputBase<any>[];

  get isReady() {
    return this._grid.isReady();
  }
  get isOneExpand() {
    return this._grid.isAtLeastOneNodeOpen;
  }
  get isTreeData() {
    return this._grid.isTreeData;
  }
  get treeMode() {
    return this._grid.treeMode;
  }
  get displayType() {
    return this._grid.displayType;
  }
  constructor() {
    super();
  }

  public override ngOnInit() {
    super.ngOnInit();
    if (this._grid.isReady()) {
      this.setFiltersForm();
    } else {
      this._registerSubscription(this._grid.ready$.subscribe(() => this.setFiltersForm()));
    }
    this._registerSubscription(this._grid.filters.filtersChanged$.subscribe(() => this.setFiltersForm()));
    if (this.breakpoints.isMobile && this.show.switchView) {
      this.switchView('card');
    }
  }

  public setFiltersForm() {
    this.filtersForm = this._grid.getFiltersForm();
  }
  public filtersSelected(data: any) {
    this._grid.filters.applyFiltersForm(data);
    this.setFiltersForm();
  }

  public searchSelected(search: string) {
    this._grid.filters.applySearch(search);
  }

  public switchView(type: GridViewType, save = true) {
    this._grid.switchView(type, save);
  }

  public toogleTreeMode() {
    this._grid.switchTreeMode(!this.treeMode);
  }

  public expandAll() {
    this._grid.api?.expandAll();
  }
  public collapseAll() {
    this._grid.api?.collapseAll();
  }
}
