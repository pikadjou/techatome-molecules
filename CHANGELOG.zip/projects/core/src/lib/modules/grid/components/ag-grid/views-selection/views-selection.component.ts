import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, TemplateRef, ViewChild, inject } from '@angular/core';

import { Subject, map } from 'rxjs';

import { FilterHelper, Menu } from '@camelot/menu';
import { ENotificationCode, LAZY_SERVICE_TOKEN } from '@camelot/notification';
import { removeObjectKeys } from '@camelot/utils';

import { getTypeTranslationKey } from '../../../helpers/type';
import { FilterModelSource } from '../../../models/types';
import { View, ViewType, Views } from '../../../services/dto/view';
import { CamGridFormService } from '../../../services/grid-form.service';
import { CamGridViewService } from '../../../services/grid-view.service';
import { AbstractGridComponent } from '../../abstract-grid.component';

@Component({
  selector: 'cam-views-selection',
  templateUrl: './views-selection.component.html',
  styleUrls: ['./views-selection.component.scss'],
})
export class ViewsSelectionComponent extends AbstractGridComponent<any> implements OnInit {
  @Output()
  OSselected = new EventEmitter();

  @ViewChild('choicesTemplate', { read: TemplateRef })
  choicesTemplate!: TemplateRef<void>;

  readonly askValidation$ = new Subject<null>();
  readonly typeToken!: { view: View };
  readonly getTypeTranslationKey = getTypeTranslationKey;

  readonly viewService = inject(CamGridViewService);

  get viewSelectedId() {
    return this._grid.filters.viewSelected;
  }

  private readonly _formService = inject(CamGridFormService<any>);
  private readonly _notificationService = inject(LAZY_SERVICE_TOKEN);

  get list$() {
    return this.viewService.views.get$().pipe(
      map(views => {
        switch (this.filterHelper.filter) {
          case ViewType[ViewType.private]:
            return views?.privateViewSettings;
          case ViewType[ViewType.shared]:
            return views?.sharedViewSettings;
          case ViewType[ViewType.public]:
            return views?.publicViewSettings;
          default:
            return views?.privateViewSettings;
        }
      })
    );
  }

  public showForm: 'view' | 'add' | 'edit' | 'copy' = 'view';
  public form = this._formService.getViewForm(null, this.choicesTemplate);

  public filterHelper = new FilterHelper([
    { label: this.getTypeTranslationKey(ViewType.private), defaultOpen: true },
    { label: this.getTypeTranslationKey(ViewType.shared), defaultOpen: false },
    { label: this.getTypeTranslationKey(ViewType.public), defaultOpen: false },
  ]);
  public menu: Menu = this.filterHelper.getMenu();

  get grid() {
    return this._grid;
  }

  override ngOnInit() {
    super.ngOnInit();

    this._fetch();

    this._registerSubscription(
      this.grid.ready$.subscribe({
        next: () => {
          const list = this.viewService.views.get();
          if (list) {
            this._defaultSelected(list);
          }
        },
      })
    );
  }

  public selected(view: View) {
    this.grid.filters.applyFilterModel(view, FilterModelSource.view, {
      selected: true,
      viewName: view.id,
    });

    this.OSselected.emit(null);
  }
  public new() {
    this.form = this._formService.getViewForm(null, this.choicesTemplate);
    this.showForm = 'add';
  }

  public validation() {
    this.askValidation$.next(null);
  }

  public edit(view: View) {
    this.form = this._formService.getViewForm(view, this.choicesTemplate);
    this.showForm = 'edit';
  }

  public copy(view: View) {
    this.form = this._formService.getViewForm({ ...view, ...{ name: view.name + '(1)' } }, this.choicesTemplate);
    this.showForm = 'copy';
  }

  public save(data: any) {
    const { filterModel, selectedFields, fieldOptions } = this.grid.filters.extractCurrentFilterModel();
    const view = this._formService.formatView(
      data,
      this.gridId,
      filterModel ?? '',
      selectedFields ?? [],
      fieldOptions ?? []
    );
    this.requestState.asked();
    const request$ =
      this.showForm === 'edit'
        ? this.viewService.updateView$(this.gridId, { id: view.id, name: view.name, type: view.type })
        : this.viewService.addView$(this.gridId, removeObjectKeys(view, ['id']));
    request$.subscribe({
      complete: () => {
        this.requestState.completed();
        this._notificationService.addNotification('notification.common.success', ENotificationCode.success);
      },
      error: () => {
        this.requestState.completed();
        this._notificationService.addNotification('notification.common.error', ENotificationCode.error);
      },
    });
    this.showForm = 'view';
  }

  public update(view: View) {
    const { filterModel, selectedFields, fieldOptions } = this.grid.filters.extractCurrentFilterModel();

    this.viewService
      .updateView$(this.gridId, {
        id: view.id,
        filterModel,
        selectedFields,
        fieldOptions,
      })
      .subscribe({
        complete: () => {
          this.requestState.completed();
          this._notificationService.addNotification('notification.common.success', ENotificationCode.success);
        },
        error: () => {
          this.requestState.completed();
          this._notificationService.addNotification('notification.common.error', ENotificationCode.error);
        },
      });
  }

  public delete(view: View) {
    this.viewService.deleteView$(this.gridId, view).subscribe({
      complete: () => {
        this.requestState.completed();
        this._notificationService.addNotification('notification.common.success', ENotificationCode.success);
      },
      error: () => {
        this.requestState.completed();
        this._notificationService.addNotification('notification.common.error', ENotificationCode.error);
      },
    });
  }

  private _fetch() {
    this.requestState.asked();
    this.viewService.getViews$(this.gridId).subscribe({
      next: list => {
        this._defaultSelected(list);
      },
      complete: () => this.requestState.completed(),
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }

  private _defaultSelected(list: Views) {
    const selected = [...list.privateViewSettings, ...list.sharedViewSettings, ...list.publicViewSettings].find(
      item => item.id === this.grid.filters.viewSelected
    );

    if (selected) {
      this.selected(selected);
    }
  }
}
