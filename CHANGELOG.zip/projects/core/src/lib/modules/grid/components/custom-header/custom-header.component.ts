import { Component } from '@angular/core';

import { AbstractHeaderComponent } from '../abstract';

@Component({
  selector: 'cam-custom-header',
  templateUrl: './custom-header.component.html',
  styleUrls: ['./custom-header.component.scss'],
})
export class CustomHeaderComponent extends AbstractHeaderComponent<any, any> {}
