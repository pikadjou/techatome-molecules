import { ViewType } from '../services/dto/view';

export const getTypeTranslationKey = (type: ViewType) =>
  `grid.view.${ViewType[type].toLowerCase()}`;
