import {
  AdvancedFilterModel,
  ColumnAdvancedFilterModel,
  JoinAdvancedFilterModel,
  SortModelItem,
} from 'ag-grid-enterprise';

import { isNonNullable } from '@camelot/utils';

type WhereType = {
  [index: string]: WhereType[] | { [op: string]: string | number | boolean | null };
};

export const graphQlFilterToWhere = (filterModel: AdvancedFilterModel): WhereType | null => {
  if (!filterModel) return null;

  // Gestion des filtres imbriqués (JoinAdvancedFilterModel)
  if (filterModel.filterType === 'join') {
    const joinFilter = <JoinAdvancedFilterModel>filterModel;

    if (joinFilter.conditions.length === 0) {
      return null;
    }
    const joinedConditions = joinFilter.conditions.map(graphQlFilterToWhere).filter(isNonNullable);

    return {
      [joinFilter.type.toLocaleLowerCase()]: joinedConditions,
    };
  }

  const getFilter = (filterModel: ColumnAdvancedFilterModel) => {
    if (filterModel.filterType === 'boolean') {
      return filterModel.type === 'true' ? true : false;
    }
    return filterModel.filter;
  };
  // Gestion des filtres simples (ColumnAdvancedFilterModel)
  const columnFilter = <ColumnAdvancedFilterModel>filterModel;
  const { colId, type } = columnFilter;
  const filter = getFilter(filterModel);

  // Mapping des types de filtres avancés vers des opérateurs GraphQL
  const operatorMapping: Record<string, string> = {
    equals: 'eq',
    notEqual: 'neq',
    contains: 'contains',
    notContains: 'ncontains',
    startsWith: 'startsWith',
    endsWith: 'endsWith',
    lessThan: 'lt',
    lessThanOrEqual: 'lte',
    greaterThan: 'gt',
    greaterThanOrEqual: 'gte',
    blank: 'eq', // Null pour les colonnes vides
    notBlank: 'neq',
    true: 'eq',
    false: 'eq',
  };

  const graphqlOperator = operatorMapping[type];
  if (!graphqlOperator) {
    return null;
  }

  if (!filter) {
    // Gérer les cas particuliers comme "blank" et "notBlank"
    if (type === 'blank') {
      return { [colId]: { [graphqlOperator]: null } };
    } else if (type === 'notBlank') {
      return { [colId]: { [graphqlOperator]: null } };
    } else {
      return null;
    }
  }

  return { [colId]: { [graphqlOperator]: filter } };
};

type OrderType = {
  [index: string]: 'ASC' | 'DESC';
};

export const graphQLSortOrder = (sortModel: SortModelItem[]): OrderType[] => {
  if (!sortModel || sortModel.length === 0) {
    return [];
  }

  return sortModel.map(item => ({
    [item.colId]: item.sort === 'asc' ? 'ASC' : 'DESC',
  }));
};
