import { GridMetaData } from '../services/dto/metadata';

export const __gridMetaData: GridMetaData[] = [];
// export const __gridMetaData: GridMetaData[] = [
//   {
//     name: 'ProjectName',
//     type: ParameterType.String,
//     domain: Domain.Project,
//     domainSearchPath: 'projects/details',
//     shownByDefault: true,
//   },
//   {
//     name: 'StartDate',
//     type: ParameterType.DateTime,
//     domain: Domain.Project,
//     domainSearchPath: 'projects/dates',
//     shownByDefault: true,
//   },
//   {
//     name: 'EndDate',
//     type: ParameterType.DateTime,
//     shownByDefault: false,
//   },
//   {
//     name: 'IsCompleted',
//     type: ParameterType.Boolean,
//     shownByDefault: true,
//   },
//   {
//     name: 'AssignedUser',
//     type: ParameterType.Guid,
//     shownByDefault: true,
//   },
//   {
//     name: 'PriorityLevel',
//     type: ParameterType.Enum,
//     shownByDefault: true,
//     enumName: 'Criticity',
//   },
//   {
//     name: 'ContactEmail',
//     type: ParameterType.String,
//     shownByDefault: false,
//   },
//   {
//     name: 'Budget',
//     type: ParameterType.Number,
//     shownByDefault: true,
//   },
// ];
