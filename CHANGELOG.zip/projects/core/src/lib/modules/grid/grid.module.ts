import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';

import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from 'ag-grid-enterprise';

import { CamFormModule } from '@camelot/form-basic';
import { CamIconsModule } from '@camelot/icons';
import { CamMenuModule } from '@camelot/menu';
import { TranslatePipe } from '@camelot/translation';
import { CamContainerModule, CamLayoutModule, CamUiModule } from '@camelot/ui';
import { CamListModule } from '@camelot/ui';
import { CamDirectivePipeModule } from '@camelot/utils';

import { CamCoreModule } from '../../core.module';
import { AgGridComponent } from './components/ag-grid/ag-grid.component';
import { BaseHeaderComponent } from './components/ag-grid/base-header/base-header.component';
import { FieldsSelectionDisplayerComponent } from './components/ag-grid/fields-selection/fields-selection-displayer/fields-selection-displayer.component';
import { FieldsSelectionComponent } from './components/ag-grid/fields-selection/fields-selection.component';
import { LoadingComponent } from './components/ag-grid/loading/loading.component';
import { PaginationComponent } from './components/ag-grid/pagination/pagination.component';
import { GridBoolCellComponent } from './components/ag-grid/template/bool.component';
import { GridCriticityCellComponent } from './components/ag-grid/template/criticity.component';
import { GridMultiFunctionCellComponent } from './components/ag-grid/template/multi-function.component';
import { GridMultiRoleCellComponent } from './components/ag-grid/template/multi-role.component';
import { ViewSelectionDisplayerComponent } from './components/ag-grid/views-selection/views-selection-displayer/views-selection-displayer.component';
import { ViewsSelectionComponent } from './components/ag-grid/views-selection/views-selection.component';
import { CustomHeaderComponent } from './components/custom-header/custom-header.component';
import { GridControlComponent } from './components/grid-control/grid-control.component';
import { GridTagComponent } from './components/grid-tag/grid-tag.component';
import { CamTranslationGrid } from './translation.service';

export {
  RowHeightParams as AgGrid_RowHeightParams,
  IsFullWidthRowParams as AgGrid_IsFullWidthRowParams,
  ColDef as AgGrid_ColDef,
} from 'ag-grid-enterprise';

LicenseManager.setLicenseKey(
  'Using_this_AG_Grid_Enterprise_key_( AG-047512 )_in_excess_of_the_licence_granted_is_not_permitted___Please_report_misuse_to_( legal@ag-grid.com )___For_help_with_changing_this_key_please_contact_( info@ag-grid.com )___( Merlin Software )_is_granted_a_( Multiple Applications )_Developer_License_for_( 1 ))_Front-End_JavaScript_developer___All_Front-End_JavaScript_developers_need_to_be_licensed_in_addition_to_the_ones_working_with_AG_Grid_Enterprise___This_key_has_been_granted_a_Deployment_License_Add-on_for_( 1 )_Production_Environment___This_key_works_with_AG_Grid_Enterprise_versions_released_before_( 10 September 2024 )____[v2]_MTcyNTkyMjgwMDAwMA==dbc38a2a5c87693d4f32ae25d2116e49'
);

@NgModule({
  declarations: [
    AgGridComponent,
    GridControlComponent,
    CustomHeaderComponent,
    GridTagComponent,
    BaseHeaderComponent,
    LoadingComponent,
    GridBoolCellComponent,
    PaginationComponent,
    FieldsSelectionComponent,
    FieldsSelectionDisplayerComponent,
    ViewsSelectionComponent,
    ViewSelectionDisplayerComponent,
    GridMultiRoleCellComponent,
    GridMultiFunctionCellComponent,
  ],
  imports: [
    CommonModule,
    AgGridModule,
    CamCoreModule,
    CamIconsModule,
    CamUiModule,
    CamDirectivePipeModule,
    CamContainerModule,
    GridCriticityCellComponent,
    CamLayoutModule,
    CamFormModule,
    CamListModule,
    MatMenuModule,
    CamMenuModule,
    TranslatePipe,
  ],
  exports: [
    AgGridComponent,
    GridControlComponent,
    GridTagComponent,
    BaseHeaderComponent,
    GridBoolCellComponent,
    GridCriticityCellComponent,
    GridMultiRoleCellComponent,
    GridMultiFunctionCellComponent,
  ],
})
export class CamGridModule {
  constructor() {
    CamTranslationGrid.getInstance();
  }
}
