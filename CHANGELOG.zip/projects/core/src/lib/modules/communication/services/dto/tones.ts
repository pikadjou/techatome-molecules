export enum Tones {
  Unknown = 0,
  Concise = 1,
  Formal = 2,
  Casual = 3,
}
