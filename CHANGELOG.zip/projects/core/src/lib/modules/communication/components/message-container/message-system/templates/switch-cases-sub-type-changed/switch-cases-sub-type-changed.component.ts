import { Component } from '@angular/core';

import { SwitchCasesSubTypeChanged } from '../../../../../services/dto/switch-cases';
import { SwitchCaseBaseComponent } from '../switch-case-base/switch-case-base.component';

@Component({
  selector: 'cam-switch-cases-sub-type-changed',
  templateUrl: './switch-cases-sub-type-changed.component.html',
  styleUrls: ['./switch-cases-sub-type-changed.component.scss'],
})
export class SwitchCasesSubTypeChangedComponent extends SwitchCaseBaseComponent<SwitchCasesSubTypeChanged> {}
