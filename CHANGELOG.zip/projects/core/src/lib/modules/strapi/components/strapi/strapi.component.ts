import { Component } from '@angular/core';

@Component({
  selector: 'cam-strapi-cms',
  templateUrl: './strapi.component.html',
  styleUrls: ['./strapi.component.scss'],
})
export class StrapiComponent {}
