export type ActiveFilterTag = {
  id: string;
  name: string;
};
