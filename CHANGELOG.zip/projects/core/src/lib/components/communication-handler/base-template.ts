import { Component, Input, OnInit } from '@angular/core';

import { Subject } from 'rxjs';

import { InputBase } from '@camelot/form-model';
import { CamBaseComponent } from '@camelot/utils';

interface Department {
  id: number;
  name: string | null;
  iconPath: string | null;
}

@Component({ template: '' })
export abstract class BaseTemplateComponent
  extends CamBaseComponent
  implements OnInit
{
  @Input()
  items!: {
    id: number;
    department?: Department;
    professions?: string[];
  }[];

  @Input()
  formSubmit$?: Subject<null>;

  public askValidation$ = new Subject<null>();

  public form: InputBase<any>[] = [];

  get currentItem() {
    return this.items[this._itemIndex];
  }

  get haveMore() {
    return !!this.items[this._itemIndex + 1];
  }

  private _itemIndex: number = 0;

  public isValidForm: boolean = false;

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.setForm();
  }

  public next() {
    if (!this.haveMore) {
      this._close();
      return;
    }
    this._itemIndex++;

    this.setForm();
  }

  public askValidation(): void {
    this.askValidation$.next(null);
  }

  public cancel(): void {
    this._close();
  }

  public formValid(value: boolean) {
    this.isValidForm = value;
  }

  private _close() {
    if (this.formSubmit$) {
      this.formSubmit$?.next(null);
    }
  }

  abstract send(data?: any): void;
  abstract setForm(): void;
}
