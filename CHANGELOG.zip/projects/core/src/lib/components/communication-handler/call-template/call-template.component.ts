import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { Validators } from '@angular/forms';

import { of } from 'rxjs';

import { InputRadio } from '@camelot/form-model';
import { CamIconType } from '@camelot/icons';

import { BaseTemplateComponent } from '../base-template';

@Component({
  selector: 'cam-call-template',
  templateUrl: './call-template.component.html',
  styleUrls: ['./call-template.component.scss'],
})
export class CallTemplateComponent extends BaseTemplateComponent {
  @Input()
  ctaService!: {
    callBack: (id: number, request: { isSuccess: boolean }) => any;
  };

  @Input()
  formService!: {
    getCallForm: () => any;
    formatCallResult: (data: any) => { isSuccess: boolean };
  };

  public reachInput: InputRadio<boolean> = new InputRadio<boolean>({
    key: 'reached',
    label: 'form.communication-handler.cta.call.reachclient.label',
    validators: [Validators.required],
    options: of([
      {
        id: true,
        name: 'radio.yes',
        icon: CamIconType.CheckLight,
      },
      {
        id: false,
        name: 'radio.no',
        icon: CamIconType.CancelLight,
      },
    ]),
    value: false,
  });

  constructor() {
    super();
    this.reachInput.createFormControl();

    this._registerSubscription(
      this.reachInput.changeValue$.subscribe((x) => {
        if (!x) this.form = [];
        else this.setForm();
      })
    );
  }

  public setForm() {
    this.form = this.formService.getCallForm();
  }

  public override askValidation(): void {
    if (!this.reachInput.value) {
      this._sendAll();
      return;
    }
    super.askValidation();
  }

  public override send(data: any) {
    const request = this.reachInput.value
      ? this.formService.formatCallResult(data)
      : { isSuccess: this.reachInput.value };

    this.requestState.asked();
    this.ctaService.callBack(this.currentItem.id, request).subscribe({
      complete: () => {
        this.requestState.completed();
        this.next();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }

  private _sendAll() {
    for (let item of this.items) {
      this.requestState.asked();
      this.ctaService.callBack(item.id, { isSuccess: false }).subscribe({
        complete: () => {
          this.next();
        },
      });
    }
  }
}
