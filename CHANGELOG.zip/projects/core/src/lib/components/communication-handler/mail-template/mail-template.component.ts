import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input } from '@angular/core';

import { BaseTemplateComponent } from '../base-template';

@Component({
  selector: 'cam-mail-template',
  templateUrl: './mail-template.component.html',
  styleUrls: ['./mail-template.component.scss'],
})
export class MailTemplateComponent extends BaseTemplateComponent {
  @Input()
  ctaService!: {
    mail: (id: number) => any;
  };

  constructor() {
    super();
  }

  public override setForm() {}
  public override send() {
    const prospection = this.currentItem;
    this.requestState.asked();
    this.ctaService.mail(prospection.id).subscribe({
      complete: () => {
        this.requestState.completed();
        this.next();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
