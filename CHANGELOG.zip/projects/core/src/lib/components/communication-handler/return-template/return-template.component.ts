import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input } from '@angular/core';

import { BaseTemplateComponent } from '../base-template';

@Component({
  selector: 'cam-return-template',
  templateUrl: './return-template.component.html',
  styleUrls: ['./return-template.component.scss'],
})
export class ReturnTemplateComponent extends BaseTemplateComponent {
  @Input()
  ctaService!: {
    returnBack: (id: number, request: { isSuccess: boolean }) => any;
  };

  @Input()
  formService!: {
    getReturnForm: () => any;
    formatReturnResult: (data: any) => { isSuccess: boolean };
  };

  constructor() {
    super();
  }

  public setForm() {
    this.form = this.formService.getReturnForm();
  }

  public override send(data: any) {
    const request = this.formService.formatReturnResult(data);

    this.requestState.asked();
    this.ctaService.returnBack(this.currentItem.id, request).subscribe({
      complete: () => {
        this.requestState.completed();
        this.next();
      },
      error: (error: HttpErrorResponse) => {
        this.requestState.onError(error.status, error.statusText);
      },
    });
  }
}
