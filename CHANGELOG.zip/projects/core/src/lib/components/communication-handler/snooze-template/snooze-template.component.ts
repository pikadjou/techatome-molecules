import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input } from '@angular/core';

import { addBusinessDays } from 'date-fns';
import { Observable } from 'rxjs';

import { InputBase } from '@camelot/form-model';
import { toUtcDate } from '@camelot/utils';

import { BaseTemplateComponent } from '../base-template';

export enum EFormSnoozeField {
  SnoozeType = 'snoozeType',
  NewDate = 'newDate',
}

export enum ESnoozeDuration {
  SnoozeOneDay,
  SnoozeTwoDays,
  SnoozeFiveDays,
  NewDate,
}

@Component({
  selector: 'cam-snooze-template',
  templateUrl: './snooze-template.component.html',
  styleUrls: ['./snooze-template.component.scss'],
})
export class SnoozeTemplateComponent extends BaseTemplateComponent {
  @Input()
  ctaService!: {
    getSnoozeForm: () => InputBase<any>[];
    snooze: (id: number, data: { date: Date }) => Observable<any>;
  };

  public setForm() {
    this.form = this.ctaService.getSnoozeForm();
  }

  public override send(data: any) {
    const snoozeType = Number(
      data[EFormSnoozeField.SnoozeType]
    ) as ESnoozeDuration;

    let finalDate = new Date(Date.now());

    switch (snoozeType) {
      case ESnoozeDuration.SnoozeOneDay:
        finalDate = addBusinessDays(finalDate, 1);
        break;
      case ESnoozeDuration.SnoozeTwoDays:
        finalDate = addBusinessDays(finalDate, 2);
        break;
      case ESnoozeDuration.SnoozeFiveDays:
        finalDate = addBusinessDays(finalDate, 5);
        break;
      case ESnoozeDuration.NewDate:
        finalDate = new Date(data['newDate']);
        break;
    }
    this.requestState.asked();
    this.ctaService
      .snooze(this.currentItem.id, {
        date: toUtcDate(finalDate),
      })
      .subscribe({
        complete: () => {
          this.requestState.completed();
          this.next();
        },
        error: (error: HttpErrorResponse) => {
          this.requestState.onError(error.status, error.statusText);
        },
      });
  }
}
