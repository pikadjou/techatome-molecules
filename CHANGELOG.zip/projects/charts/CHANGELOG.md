# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [3.16.0-beta.4](https://dev.azure.com/compare/v3.16.0-beta.3...v3.16.0-beta.4) (2025-06-10)

**Note:** Version bump only for package @camelot/charts





# [3.16.0-beta.3](https://dev.azure.com/compare/v3.16.0-beta.2...v3.16.0-beta.3) (2025-06-05)

**Note:** Version bump only for package @camelot/charts





# [3.16.0-beta.2](https://dev.azure.com/compare/v3.16.0-beta.1...v3.16.0-beta.2) (2025-06-04)

**Note:** Version bump only for package @camelot/charts





# [3.16.0-beta.1](https://dev.azure.com/compare/v3.16.0-beta.0...v3.16.0-beta.1) (2025-06-04)

**Note:** Version bump only for package @camelot/charts





# [3.16.0-beta.0](https://dev.azure.com/compare/v3.15.1-beta.1...v3.16.0-beta.0) (2025-06-04)


### Features

* charts update ([cbf47a6](https://dev.azure.com/commits/cbf47a6be1a1f524250a9a5b47fb6780e517d725))
* fix comments ([b186d79](https://dev.azure.com/commits/b186d79498a9af062e0642a2b08a3ea80860aa46))





## [3.15.1-beta.1](https://dev.azure.com/compare/v3.15.1-beta.0...v3.15.1-beta.1) (2025-05-27)

**Note:** Version bump only for package @camelot/charts





## [3.15.1-beta.0](https://dev.azure.com/compare/v3.15.0...v3.15.1-beta.0) (2025-05-26)

**Note:** Version bump only for package @camelot/charts





# [3.15.0](https://dev.azure.com/compare/v3.15.0-beta.7...v3.15.0) (2025-05-22)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.7](https://dev.azure.com/compare/v3.15.0-beta.6...v3.15.0-beta.7) (2025-05-22)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.6](https://dev.azure.com/compare/v3.15.0-beta.5...v3.15.0-beta.6) (2025-05-22)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.5](https://dev.azure.com/compare/v3.15.0-beta.4...v3.15.0-beta.5) (2025-05-21)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.4](https://dev.azure.com/compare/v3.15.0-beta.3...v3.15.0-beta.4) (2025-05-21)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.3](https://dev.azure.com/compare/v3.15.0-beta.2...v3.15.0-beta.3) (2025-05-21)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.2](https://dev.azure.com/compare/v3.15.0-beta.1...v3.15.0-beta.2) (2025-05-21)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.1](https://dev.azure.com/compare/v3.15.0-beta.0...v3.15.0-beta.1) (2025-05-15)

**Note:** Version bump only for package @camelot/charts





# [3.15.0-beta.0](https://dev.azure.com/compare/v3.14.0...v3.15.0-beta.0) (2025-05-07)

**Note:** Version bump only for package @camelot/charts





# [3.14.0](https://dev.azure.com/compare/v3.14.0-beta.10...v3.14.0) (2025-05-06)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.10](https://dev.azure.com/compare/v3.14.0-beta.9...v3.14.0-beta.10) (2025-04-29)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.9](https://dev.azure.com/compare/v3.14.0-beta.8...v3.14.0-beta.9) (2025-04-28)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.8](https://dev.azure.com/compare/v3.14.0-beta.7...v3.14.0-beta.8) (2025-04-25)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.7](https://dev.azure.com/compare/v3.14.0-beta.6...v3.14.0-beta.7) (2025-04-25)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.6](https://dev.azure.com/compare/v3.14.0-beta.5...v3.14.0-beta.6) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.5](https://dev.azure.com/compare/v3.14.0-beta.4...v3.14.0-beta.5) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.4](https://dev.azure.com/compare/v3.14.0-beta.3...v3.14.0-beta.4) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.3](https://dev.azure.com/compare/v3.14.0-beta.2...v3.14.0-beta.3) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.2](https://dev.azure.com/compare/v3.14.0-beta.1...v3.14.0-beta.2) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.1](https://dev.azure.com/compare/v3.14.0-beta.0...v3.14.0-beta.1) (2025-04-24)

**Note:** Version bump only for package @camelot/charts





# [3.14.0-beta.0](https://dev.azure.com/compare/v3.13.1-beta.2...v3.14.0-beta.0) (2025-04-17)

**Note:** Version bump only for package @camelot/charts





## [3.13.1-beta.2](https://dev.azure.com/compare/v3.13.1-beta.1...v3.13.1-beta.2) (2025-04-16)

**Note:** Version bump only for package @camelot/charts





## [3.13.1-beta.1](https://dev.azure.com/compare/v3.13.1-beta.0...v3.13.1-beta.1) (2025-04-16)

**Note:** Version bump only for package @camelot/charts





## [3.13.1-beta.0](https://dev.azure.com/compare/v3.13.0...v3.13.1-beta.0) (2025-04-11)

**Note:** Version bump only for package @camelot/charts





# [3.13.0](https://dev.azure.com/compare/v3.13.0-beta.5...v3.13.0) (2025-04-11)



## [3.12.4](https://dev.azure.com/compare/v3.12.3-beta.0...v3.12.4) (2025-04-08)



## [3.12.3](https://dev.azure.com/compare/v3.12.1...v3.12.3) (2025-04-04)

**Note:** Version bump only for package @camelot/charts





# [3.13.0-beta.5](https://dev.azure.com/compare/v3.13.0-beta.4...v3.13.0-beta.5) (2025-04-11)

**Note:** Version bump only for package @camelot/charts

# [3.13.0-beta.4](https://dev.azure.com/compare/v3.13.0-beta.3...v3.13.0-beta.4) (2025-04-11)

**Note:** Version bump only for package @camelot/charts

# [3.13.0-beta.3](https://dev.azure.com/compare/v3.13.0-beta.2...v3.13.0-beta.3) (2025-04-11)

**Note:** Version bump only for package @camelot/charts

# [3.13.0-beta.2](https://dev.azure.com/compare/v3.13.0-beta.1...v3.13.0-beta.2) (2025-04-11)

**Note:** Version bump only for package @camelot/charts

# [3.13.0-beta.1](https://dev.azure.com/compare/v3.13.0-beta.0...v3.13.0-beta.1) (2025-04-11)

**Note:** Version bump only for package @camelot/charts

# [3.13.0-beta.0](https://dev.azure.com/compare/v3.12.3-beta.0...v3.13.0-beta.0) (2025-04-09)

**Note:** Version bump only for package @camelot/charts

## [3.12.3-beta.0](https://dev.azure.com/compare/v3.12.1...v3.12.3-beta.0) (2025-04-04)

## [3.12.1-beta.0](https://dev.azure.com/compare/v3.12.0...v3.12.1-beta.0) (2025-04-03)

**Note:** Version bump only for package @camelot/charts

## [3.12.2](https://dev.azure.com/compare/v3.12.1...v3.12.2) (2025-04-04)

**Note:** Version bump only for package @camelot/charts

# [3.12.0](https://dev.azure.com/compare/v3.12.0-beta.3...v3.12.0) (2025-04-03)

**Note:** Version bump only for package @camelot/charts

# [3.12.0-beta.3](https://dev.azure.com/compare/v3.12.0-beta.2...v3.12.0-beta.3) (2025-04-03)

**Note:** Version bump only for package @camelot/charts

# [3.12.0-beta.2](https://dev.azure.com/compare/v3.12.0-beta.1...v3.12.0-beta.2) (2025-04-03)

**Note:** Version bump only for package @camelot/charts

# [3.12.0-beta.1](https://dev.azure.com/compare/v3.12.0-beta.0...v3.12.0-beta.1) (2025-04-03)

**Note:** Version bump only for package @camelot/charts

# [3.12.0-beta.0](https://dev.azure.com/compare/v3.11.1-beta.0...v3.12.0-beta.0) (2025-04-02)

**Note:** Version bump only for package @camelot/charts

## [3.11.1-beta.0](https://dev.azure.com/compare/v3.11.0...v3.11.1-beta.0) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0](https://dev.azure.com/compare/v3.11.0-beta.8...v3.11.0) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.8](https://dev.azure.com/compare/v3.11.0-beta.7...v3.11.0-beta.8) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.7](https://dev.azure.com/compare/v3.11.0-beta.6...v3.11.0-beta.7) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.6](https://dev.azure.com/compare/v3.11.0-beta.5...v3.11.0-beta.6) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.5](https://dev.azure.com/compare/v3.11.0-beta.4...v3.11.0-beta.5) (2025-04-01)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.4](https://dev.azure.com/compare/v3.11.0-beta.3...v3.11.0-beta.4) (2025-03-27)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.3](https://dev.azure.com/compare/v3.11.0-beta.2...v3.11.0-beta.3) (2025-03-26)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.2](https://dev.azure.com/compare/v3.11.0-beta.1...v3.11.0-beta.2) (2025-03-26)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.1](https://dev.azure.com/compare/v3.11.0-beta.0...v3.11.0-beta.1) (2025-03-25)

**Note:** Version bump only for package @camelot/charts

# [3.11.0-beta.0](https://dev.azure.com/compare/v3.10.2-beta.0...v3.11.0-beta.0) (2025-03-24)

**Note:** Version bump only for package @camelot/charts

## [3.10.2-beta.0](https://dev.azure.com/compare/v3.10.1-beta.1...v3.10.2-beta.0) (2025-03-20)

**Note:** Version bump only for package @camelot/charts

## [3.10.1-beta.1](https://dev.azure.com/compare/v3.10.1-beta.0...v3.10.1-beta.1) (2025-03-20)

**Note:** Version bump only for package @camelot/charts

## [3.10.1-beta.0](https://dev.azure.com/compare/v3.10.0-beta.3...v3.10.1-beta.0) (2025-03-17)

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.10.0](https://dev.azure.com/compare/v3.10.0-beta.2...v3.10.0) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.10.0-beta.2](https://dev.azure.com/compare/v3.10.0-beta.1...v3.10.0-beta.2) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.10.0-beta.1](https://dev.azure.com/compare/v3.10.0-beta.0...v3.10.0-beta.1) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.10.0-beta.0](https://dev.azure.com/compare/v3.9.1-beta.0...v3.10.0-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

## [3.9.1-beta.0](https://dev.azure.com/compare/v3.9.0...v3.9.1-beta.0) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.9.0](https://dev.azure.com/compare/v3.9.0-beta.2...v3.9.0) (2025-03-05)

**Note:** Version bump only for package @camelot/charts

# [3.9.0-beta.2](https://dev.azure.com/compare/v3.9.0-beta.1...v3.9.0-beta.2) (2025-03-04)

**Note:** Version bump only for package @camelot/charts

# [3.9.0-beta.1](https://dev.azure.com/compare/v3.9.0-beta.0...v3.9.0-beta.1) (2025-03-04)

**Note:** Version bump only for package @camelot/charts

# [3.9.0-beta.0](https://dev.azure.com/compare/v3.8.1-beta.0...v3.9.0-beta.0) (2025-03-04)

**Note:** Version bump only for package @camelot/charts

## [3.8.1-beta.0](https://dev.azure.com/compare/v3.8.0...v3.8.1-beta.0) (2025-03-03)

**Note:** Version bump only for package @camelot/charts

# [3.8.0](https://dev.azure.com/compare/v3.8.0-beta.6...v3.8.0) (2025-03-01)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.6](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.6) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.5](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.5) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.4](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.4) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.3](https://dev.azure.com/compare/v3.8.0-beta.2...v3.8.0-beta.3) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.2](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.2) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.1](https://dev.azure.com/compare/v3.8.0-beta.0...v3.8.0-beta.1) (2025-02-28)

**Note:** Version bump only for package @camelot/charts

# [3.8.0-beta.0](https://dev.azure.com/compare/v3.7.1-beta.6...v3.8.0-beta.0) (2025-02-27)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.10](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.10) (2025-02-26)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.9](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.9) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.8](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.8) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.7](https://dev.azure.com/compare/v3.7.1-beta.6...v3.7.1-beta.7) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.6](https://dev.azure.com/compare/v3.7.1-beta.5...v3.7.1-beta.6) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.5](https://dev.azure.com/compare/v3.7.1-beta.4...v3.7.1-beta.5) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.4](https://dev.azure.com/compare/v3.7.1-beta.3...v3.7.1-beta.4) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.3](https://dev.azure.com/compare/v3.7.1-beta.2...v3.7.1-beta.3) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.2](https://dev.azure.com/compare/v3.7.1-beta.1...v3.7.1-beta.2) (2025-02-25)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.1](https://dev.azure.com/compare/v3.7.1-beta.0...v3.7.1-beta.1) (2025-02-24)

**Note:** Version bump only for package @camelot/charts

## [3.7.1-beta.0](https://dev.azure.com/compare/v3.7.0...v3.7.1-beta.0) (2025-02-24)

**Note:** Version bump only for package @camelot/charts

# [3.7.0](https://dev.azure.com/compare/v3.5.0-beta.4...v3.7.0) (2025-02-24)

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0-beta.1](https://dev.azure.com/compare/v3.5.0-beta.0...v3.5.0-beta.1) (2025-02-20)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/charts

# [3.6.0](https://dev.azure.com/compare/v3.5.0-beta.1...v3.6.0) (2025-02-21)

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/charts

# [3.5.0](https://dev.azure.com/compare/v3.3.0...v3.5.0) (2025-02-20)

**Note:** Version bump only for package @camelot/charts

# [3.4.0](https://dev.azure.com/compare/v3.3.0...v3.4.0) (2025-02-19)

**Note:** Version bump only for package @camelot/charts

# [3.3.0](https://dev.azure.com/compare/v3.3.0-beta.2...v3.3.0) (2025-02-18)

**Note:** Version bump only for package @camelot/charts

# [3.3.0-beta.2](https://dev.azure.com/compare/v3.3.0-beta.1...v3.3.0-beta.2) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/charts

## [3.2.5-beta.0](https://dev.azure.com/compare/v3.3.0-beta.1...v3.2.5-beta.0) (2025-02-18)

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/charts

## [3.2.4](https://dev.azure.com/compare/v3.2.1...v3.2.4) (2025-02-17)

**Note:** Version bump only for package @camelot/charts

## [3.2.3](https://dev.azure.com/compare/v3.2.1...v3.2.3) (2025-02-17)

**Note:** Version bump only for package @camelot/charts

# [3.3.0-beta.0](https://dev.azure.com/compare/v3.2.4-beta.0...v3.3.0-beta.0) (2025-02-17)

# [3.2.0-beta.0](https://dev.azure.com/compare/v3.1.1-beta.4...v3.2.0-beta.0) (2025-02-13)

**Note:** Version bump only for package @camelot/charts

## [3.2.4-beta.0](https://dev.azure.com/compare/v3.2.1...v3.2.4-beta.0) (2025-02-17)

## [3.2.1-beta.0](https://dev.azure.com/compare/v3.2.0...v3.2.1-beta.0) (2025-02-17)

**Note:** Version bump only for package @camelot/charts

# [3.2.0-beta.1](https://dev.azure.com/compare/v3.1.1-beta.7...v3.2.0-beta.1) (2025-02-14)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.7](https://dev.azure.com/compare/v3.1.1-beta.6...v3.1.1-beta.7) (2025-02-14)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.6](https://dev.azure.com/compare/v3.1.1-beta.5...v3.1.1-beta.6) (2025-02-13)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.5](https://dev.azure.com/compare/v3.1.1-beta.4...v3.1.1-beta.5) (2025-02-13)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.4](https://dev.azure.com/compare/v3.1.1-beta.3...v3.1.1-beta.4) (2025-02-12)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.3](https://dev.azure.com/compare/v3.1.1-beta.2...v3.1.1-beta.3) (2025-02-11)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.2](https://dev.azure.com/compare/v3.1.1...v3.1.1-beta.2) (2025-02-06)

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.1](https://dev.azure.com/compare/v3.1.1-beta.0...v3.1.1-beta.1) (2025-02-06)

**Note:** Version bump only for package @camelot/charts

## [3.1.1-beta.0](https://dev.azure.com/compare/v3.1.0...v3.1.1-beta.0) (2025-02-06)

**Note:** Version bump only for package @camelot/charts

# [3.1.0](https://dev.azure.com/compare/v3.1.0-beta.12...v3.1.0) (2025-02-06)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.12](https://dev.azure.com/compare/v2.14.0-beta.1...v3.1.0-beta.12) (2025-02-06)

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

## [3.0.2](https://dev.azure.com/compare/v3.0.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.11](https://dev.azure.com/compare/v3.1.0-beta.10...v3.1.0-beta.11) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.10](https://dev.azure.com/compare/v3.1.0-beta.9...v3.1.0-beta.10) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.9](https://dev.azure.com/compare/v3.1.0-beta.8...v3.1.0-beta.9) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.8](https://dev.azure.com/compare/v3.1.0-beta.7...v3.1.0-beta.8) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.7](https://dev.azure.com/compare/v3.1.0-beta.6...v3.1.0-beta.7) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.6](https://dev.azure.com/compare/v3.1.0-beta.5...v3.1.0-beta.6) (2025-02-05)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.5](https://dev.azure.com/compare/v3.1.0-beta.4...v3.1.0-beta.5) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.4](https://dev.azure.com/compare/v3.1.0-beta.3...v3.1.0-beta.4) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.3](https://dev.azure.com/compare/v3.1.0-beta.2...v3.1.0-beta.3) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.2](https://dev.azure.com/compare/v3.1.0-beta.1...v3.1.0-beta.2) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.1](https://dev.azure.com/compare/v3.1.0-beta.0...v3.1.0-beta.1) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

# [3.1.0-beta.0](https://dev.azure.com/compare/v3.0.2...v3.1.0-beta.0) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

## [3.0.3](https://dev.azure.com/compare/v3.0.2...v3.0.3) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

## [3.0.2](https://dev.azure.com/compare/v2.13.1...v3.0.2) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

## [3.0.1](https://dev.azure.com/compare/v2.13.1...v3.0.1) (2025-02-04)

**Note:** Version bump only for package @camelot/charts

## [2.13.1](https://dev.azure.com/compare/v2.13.1-beta.10...v2.13.1) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.10](https://dev.azure.com/compare/v2.13.1-beta.9...v2.13.1-beta.10) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.9](https://dev.azure.com/compare/v2.13.1-beta.8...v2.13.1-beta.9) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.8](https://dev.azure.com/compare/v2.13.1-beta.7...v2.13.1-beta.8) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.7](https://dev.azure.com/compare/v2.13.1-beta.6...v2.13.1-beta.7) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.6](https://dev.azure.com/compare/v2.13.1-beta.5...v2.13.1-beta.6) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.5](https://dev.azure.com/compare/v2.13.1-beta.4...v2.13.1-beta.5) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.4](https://dev.azure.com/compare/v2.13.1-beta.3...v2.13.1-beta.4) (2025-01-28)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.3](https://dev.azure.com/compare/v2.13.1-beta.2...v2.13.1-beta.3) (2025-01-27)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.2](https://dev.azure.com/compare/v2.13.1-beta.1...v2.13.1-beta.2) (2025-01-27)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.1](https://dev.azure.com/compare/v2.13.1-beta.0...v2.13.1-beta.1) (2025-01-27)

**Note:** Version bump only for package @camelot/charts

## [2.13.1-beta.0](https://dev.azure.com/compare/v2.13.0...v2.13.1-beta.0) (2025-01-23)

**Note:** Version bump only for package @camelot/charts

# [2.13.0](https://dev.azure.com/compare/v2.12.9-beta.4...v2.13.0) (2025-01-23)

### Features

- add pie chart ([bcbb689](https://dev.azure.com/commits/bcbb689c48c4f5676709d71d8f8a0d22cfab019b))

## [2.12.9-beta.4](https://dev.azure.com/compare/v2.12.9-beta.3...v2.12.9-beta.4) (2025-01-23)

**Note:** Version bump only for package @camelot/charts

## [2.12.9-beta.3](https://dev.azure.com/compare/v2.12.9-beta.2...v2.12.9-beta.3) (2025-01-23)

**Note:** Version bump only for package @camelot/charts

## [2.12.9-beta.2](https://dev.azure.com/compare/v2.12.9-beta.1...v2.12.9-beta.2) (2025-01-23)

**Note:** Version bump only for package @camelot/charts

## [2.12.9-beta.1](https://dev.azure.com/compare/v2.12.9-beta.0...v2.12.9-beta.1) (2025-01-21)

**Note:** Version bump only for package @camelot/charts

## [2.12.9-beta.0](https://dev.azure.com/compare/v2.12.8...v2.12.9-beta.0) (2025-01-21)

**Note:** Version bump only for package @camelot/charts

## [2.12.8](https://dev.azure.com/compare/v2.12.8-beta.1...v2.12.8) (2025-01-21)

**Note:** Version bump only for package @camelot/charts

## [2.12.8-beta.1](https://dev.azure.com/compare/v2.12.8-beta.0...v2.12.8-beta.1) (2025-01-20)

**Note:** Version bump only for package @camelot/charts

## [2.12.8-beta.0](https://dev.azure.com/compare/v2.13.0-beta.0...v2.12.8-beta.0) (2025-01-20)

## [2.12.7](https://dev.azure.com/compare/v2.12.5...v2.12.7) (2025-01-17)

## [2.12.5](https://dev.azure.com/compare/v2.12.4...v2.12.5) (2025-01-17)

## [2.12.4](https://dev.azure.com/compare/v2.12.4-beta.0...v2.12.4) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.7](https://dev.azure.com/compare/v2.12.5...v2.12.7) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.6](https://dev.azure.com/compare/v2.12.5...v2.12.6) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.5](https://dev.azure.com/compare/v2.12.4...v2.12.5) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.4](https://dev.azure.com/compare/v2.12.3...v2.12.4) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.3](https://dev.azure.com/compare/v2.12.1...v2.12.3) (2025-01-17)

**Note:** Version bump only for package @camelot/charts

## [2.12.2](https://dev.azure.com/compare/v2.12.0...v2.12.2) (2025-01-16)

**Note:** Version bump only for package @camelot/charts

## [2.12.1](https://dev.azure.com/compare/v2.12.0...v2.12.1) (2025-01-16)

**Note:** Version bump only for package @camelot/charts

# [2.12.0](https://dev.azure.com/compare/v2.12.0-beta.5...v2.12.0) (2025-01-16)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.5](https://dev.azure.com/compare/v2.12.0-beta.4...v2.12.0-beta.5) (2025-01-16)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.4](https://dev.azure.com/compare/v2.12.0-beta.3...v2.12.0-beta.4) (2025-01-16)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.3](https://dev.azure.com/compare/v2.12.0-beta.2...v2.12.0-beta.3) (2025-01-15)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.2](https://dev.azure.com/compare/v2.12.0-beta.1...v2.12.0-beta.2) (2025-01-15)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.1](https://dev.azure.com/compare/v2.12.0-beta.0...v2.12.0-beta.1) (2025-01-15)

**Note:** Version bump only for package @camelot/charts

# [2.12.0-beta.0](https://dev.azure.com/compare/v2.11.1-beta.0...v2.12.0-beta.0) (2025-01-10)

### Features

- charts upgrade ([44efd9f](https://dev.azure.com/commits/44efd9f6fdc648f08f2c13cac745e332ed3a5003))

## [2.11.1-beta.0](https://dev.azure.com/compare/v2.11.0-beta.3...v2.11.1-beta.0) (2025-01-10)

# [2.11.0](https://dev.azure.com/compare/v2.11.0-beta.0...v2.11.0) (2025-01-09)

**Note:** Version bump only for package @camelot/charts

# [2.11.0](https://dev.azure.com/compare/v2.11.0-beta.0...v2.11.0) (2025-01-09)

**Note:** Version bump only for package @camelot/charts

# [2.11.0-beta.0](https://dev.azure.com/compare/v2.10.2-beta.2...v2.11.0-beta.0) (2025-01-07)

**Note:** Version bump only for package @camelot/charts

## [2.10.2-beta.2](https://dev.azure.com/compare/v2.10.2-beta.1...v2.10.2-beta.2) (2024-12-13)

**Note:** Version bump only for package @camelot/charts

## [2.10.2-beta.1](https://dev.azure.com/compare/v2.10.2-beta.0...v2.10.2-beta.1) (2024-12-12)

**Note:** Version bump only for package @camelot/charts

## [2.10.2-beta.0](https://dev.azure.com/compare/v2.10.0-beta.13...v2.10.2-beta.0) (2024-12-11)

## [2.10.1](https://dev.azure.com/compare/v2.10.0-beta.12...v2.10.1) (2024-12-10)

**Note:** Version bump only for package @camelot/charts

## [2.10.1](https://dev.azure.com/compare/v2.10.0-beta.11...v2.10.1) (2024-12-10)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.11](https://dev.azure.com/compare/v2.10.0-beta.10...v2.10.0-beta.11) (2024-12-10)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.10](https://dev.azure.com/compare/v2.10.0-beta.9...v2.10.0-beta.10) (2024-12-10)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.9](https://dev.azure.com/compare/v2.10.0-beta.8...v2.10.0-beta.9) (2024-12-04)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.8](https://dev.azure.com/compare/v2.10.0-beta.7...v2.10.0-beta.8) (2024-12-04)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.7](https://dev.azure.com/compare/v2.10.0-beta.6...v2.10.0-beta.7) (2024-12-04)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.6](https://dev.azure.com/compare/v2.10.0-beta.5...v2.10.0-beta.6) (2024-12-04)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.5](https://dev.azure.com/compare/v2.10.0-beta.4...v2.10.0-beta.5) (2024-11-29)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.4](https://dev.azure.com/compare/v2.10.0-beta.3...v2.10.0-beta.4) (2024-11-28)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.3](https://dev.azure.com/compare/v2.10.0-beta.2...v2.10.0-beta.3) (2024-11-27)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.2](https://dev.azure.com/compare/v2.10.0-beta.1...v2.10.0-beta.2) (2024-11-26)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.1](https://dev.azure.com/compare/v2.10.0-beta.0...v2.10.0-beta.1) (2024-11-26)

**Note:** Version bump only for package @camelot/charts

# [2.10.0-beta.0](https://dev.azure.com/compare/v2.9.1-beta.1...v2.10.0-beta.0) (2024-11-22)

**Note:** Version bump only for package @camelot/charts

## [2.9.1-beta.1](https://dev.azure.com/compare/v2.9.1-beta.0...v2.9.1-beta.1) (2024-11-22)

**Note:** Version bump only for package @camelot/charts

## [2.9.1-beta.0](https://dev.azure.com/compare/v2.9.0...v2.9.1-beta.0) (2024-11-21)

**Note:** Version bump only for package @camelot/charts

# [2.9.0](https://dev.azure.com/compare/v2.9.0-beta.7...v2.9.0) (2024-11-21)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.7](https://dev.azure.com/compare/v2.9.0-beta.6...v2.9.0-beta.7) (2024-11-21)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.6](https://dev.azure.com/compare/v2.9.0-beta.5...v2.9.0-beta.6) (2024-11-21)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.5](https://dev.azure.com/compare/v2.9.0-beta.4...v2.9.0-beta.5) (2024-11-21)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.4](https://dev.azure.com/compare/v2.9.0-beta.3...v2.9.0-beta.4) (2024-11-20)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.3](https://dev.azure.com/compare/v2.9.0-beta.2...v2.9.0-beta.3) (2024-11-19)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.2](https://dev.azure.com/compare/v2.9.0-beta.1...v2.9.0-beta.2) (2024-11-19)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.1](https://dev.azure.com/compare/v2.9.0-beta.0...v2.9.0-beta.1) (2024-11-15)

**Note:** Version bump only for package @camelot/charts

# [2.9.0-beta.0](https://dev.azure.com/compare/v2.8.7-beta.0...v2.9.0-beta.0) (2024-11-14)

**Note:** Version bump only for package @camelot/charts

## [2.8.7-beta.0](https://dev.azure.com/compare/v2.8.6...v2.8.7-beta.0) (2024-11-13)

**Note:** Version bump only for package @camelot/charts

## [2.8.6](https://dev.azure.com/compare/v2.8.4...v2.8.6) (2024-11-13)

**Note:** Version bump only for package @camelot/charts

## [2.8.5](https://dev.azure.com/compare/v2.8.4...v2.8.5) (2024-11-13)

**Note:** Version bump only for package @camelot/charts

## [2.8.3](https://dev.azure.com/compare/v2.8.1...v2.8.3) (2024-11-13)

**Note:** Version bump only for package @camelot/charts

## [2.8.2](https://dev.azure.com/compare/v2.8.1...v2.8.2) (2024-11-13)

**Note:** Version bump only for package @camelot/charts

# [2.8.0](https://dev.azure.com/compare/v2.8.0-beta.16...v2.8.0) (2024-11-12)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.16](https://dev.azure.com/compare/v2.8.0-beta.15...v2.8.0-beta.16) (2024-11-12)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.15](https://dev.azure.com/compare/v2.8.0-beta.14...v2.8.0-beta.15) (2024-11-08)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.14](https://dev.azure.com/compare/v2.8.0-beta.13...v2.8.0-beta.14) (2024-11-08)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.13](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.13) (2024-11-07)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.12](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.12) (2024-11-07)

**Note:** Version bump only for package @camelot/charts

# [2.8.0-beta.11](https://dev.azure.com/compare/v2.8.0-beta.10...v2.8.0-beta.11) (2024-11-07)

**Note:** Version bump only for package @camelot/charts
