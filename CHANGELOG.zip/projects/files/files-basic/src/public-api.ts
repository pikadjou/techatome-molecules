/*
 * Public API Surface of files-basic
 */

export * from './lib/components/public-api';

export * from './lib/files-basic.module';
