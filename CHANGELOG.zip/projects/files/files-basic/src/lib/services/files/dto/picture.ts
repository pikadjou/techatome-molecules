export interface Picture {
  url: string;
}
