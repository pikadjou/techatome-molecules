export * from './list/files-list.component';
export * from './edit/files-edit.component';

export * from './documents/list/list.component';
