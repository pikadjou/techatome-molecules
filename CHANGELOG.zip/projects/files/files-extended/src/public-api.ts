/*
 * Public API Surface of files
 */

export * from './lib/components/public-api';

export * from './lib/services/public-api';

export * from './lib/files-extended.module';
