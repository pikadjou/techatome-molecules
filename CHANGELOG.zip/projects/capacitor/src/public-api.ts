/*
 * Public API Surface of capacitor
 */

export * from './lib/services/public-api';

export * from './lib/capacitor.module';
