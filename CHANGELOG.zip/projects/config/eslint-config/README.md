# `@mathias5r/eslint-config`

> TODO: description

## Usage

```
const eslintConfig = require('@mathias5r/eslint-config');

// TODO: DEMONSTRATE API
```
