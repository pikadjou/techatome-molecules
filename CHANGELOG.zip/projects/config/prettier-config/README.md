# `@mathias5r/prettier-config`

> TODO: description

## Usage

```
const prettierConfig = require('@mathias5r/prettier-config');

// TODO: DEMONSTRATE API
```
