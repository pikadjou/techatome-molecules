import eslintConfig from "./projects/config/eslint-config/index.mjs";

export default eslintConfig;
