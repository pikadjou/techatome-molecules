import prettierConfig from "./projects/config/prettier-config/index.mjs";

export default prettierConfig;
